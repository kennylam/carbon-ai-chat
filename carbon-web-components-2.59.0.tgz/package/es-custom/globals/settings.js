/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/globals/settings.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const prefix = "cds-custom";
/**
* A selector selecting tabbable nodes.
* Borrowed from `carbon-angular`. tabbable === focusable.
*/
const selectorTabbable = `
  a[href]:not(#start-sentinel, #end-sentinel), area[href], input:not([disabled]):not([tabindex='-1']),
  button:not([disabled]):not([tabindex='-1']),select:not([disabled]):not([tabindex='-1']),
  textarea:not([disabled]):not([tabindex='-1']),
  iframe, object, embed, *[tabindex]:not([tabindex='-1']), *[contenteditable=true],
  cds-custom-accordion-item,
  cds-custom-actionable-notification-button,
  cds-custom-ai-label,
  cds-custom-button,
  cds-custom-breadcrumb-link,
  cds-custom-checkbox,
  cds-custom-code-snippet,
  cds-custom-combo-box,
  cds-custom-content-switcher-item,
  cds-custom-copy-button,
  cds-custom-table-header-row,
  cds-custom-table-row,
  cds-custom-table-toolbar-search,
  cds-custom-date-picker-input,
  cds-custom-dropdown,
  cds-custom-icon-button,
  cds-custom-input,
  cds-custom-link,
  cds-custom-number-input,
  cds-custom-modal,
  cds-custom-modal-close-button,
  cds-custom-modal-footer-button,
  cds-custom-multi-select,
  cds-custom-inline-notification,
  cds-custom-toast-notification,
  cds-custom-overflow-menu,
  cds-custom-overflow-menu-item,
  cds-custom-page-sizes-select,
  cds-custom-pages-select,
  cds-custom-progress-step,
  cds-custom-radio-button,
  cds-custom-search,
  cds-custom-slider,
  cds-custom-slider-input,
  cds-custom-structured-list,
  cds-custom-tab,
  cds-custom-filter-tag,
  cds-custom-textarea,
  cds-custom-text-input,
  cds-custom-clickable-tile,
  cds-custom-expandable-tile,
  cds-custom-radio-tile,
  cds-custom-selectable-tile,
  cds-custom-toggle,
  cds-custom-tooltip,
  cds-custom-tooltip-definition,
  cds-custom-tooltip-icon,
  cds-custom-header-menu,
  cds-custom-header-menu-button,
  cds-custom-header-menu-item,
  cds-custom-header-name,
  cds-custom-header-nav-item,
  cds-custom-side-nav-link,
  cds-custom-side-nav-menu,
  cds-custom-side-nav-menu-item,
  cds-custom-slug
`;
//#endregion
export { prefix, selectorTabbable };

//# sourceMappingURL=settings.js.map