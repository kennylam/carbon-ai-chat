/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/globals/register.ts
/**
* Register a custom element class, under `options.name` (or its static `is` by
* default) in `options.registry` (or the global `customElements` by default).
* Called by the registering barrels so importing a class stays pure.
*
* Re-registering the same class under the same tag is an idempotent no-op (barrels
* rely on this). If the tag is already claimed by a different class, i.e. two
* copies of Carbon on the page, the first definition wins and a warning is
* emitted in development.
*
* A class may only be registered once per registry, so if the tag is free but
* `clazz` is already registered under another name (a custom-name call after the
* default tag was defined), a fresh subclass is registered under the new name
* instead. Elements of that tag remain `instanceof clazz` (a subclass is-a its
* base), and the returned class is the one that upgrades.
*
* @param clazz The custom element class to register
* @param options Registration options
* @returns The registered class, for convenient re-export. This is `clazz`
*   itself, except in the subclass case above, where it is the subclass that was
*   actually registered under `options.name`.
*/
const defineCustomElement = (clazz, options = {}) => {
	const registry = options.registry ?? customElements;
	const name = options.name ?? clazz.is;
	if (!name) return clazz;
	const existing = registry.get(name);
	if (existing) {
		if (existing !== clazz && true) globalThis.console?.warn(`[@carbon/web-components] <${name}> is already defined by a different class. This usually means more than one copy of @carbon/web-components is on the page; the first definition wins and components may mix versions. Deduplicate the dependency, or register into a scoped registry.`);
		return clazz;
	}
	try {
		registry.define(name, clazz);
	} catch (error) {
		if (error == null || error.name !== "NotSupportedError") throw error;
		const ScopedElement = class extends clazz {};
		Object.defineProperty(ScopedElement, "is", { value: name });
		registry.define(name, ScopedElement);
		return ScopedElement;
	}
	return clazz;
};
//#endregion
export { defineCustomElement as default, defineCustomElement };

//# sourceMappingURL=register.js.map
// @deprecated The `es-custom` build is deprecated and will be removed in v3.0.0.
if (typeof console !== "undefined" && !globalThis.__CDS_ES_CUSTOM_DEPRECATED__) {
  globalThis.__CDS_ES_CUSTOM_DEPRECATED__ = true;
  console.warn(
    "[@carbon/web-components] The \"es-custom\" build (cds-custom-* elements) is deprecated and will be removed in v3.0.0. " +
    "Register Carbon elements under your own tag name instead, e.g. " +
    "defineCustomElement(CDSButton, { name: \"cds-custom-button\" }) using the pure class import."
  );
}
