/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/globals/mixins/on.ts
/**
* Copyright IBM Corp. 2016, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
function on(element, ...args) {
	element.addEventListener(...args);
	return { release() {
		element.removeEventListener(...args);
		return null;
	} };
}
//#endregion
export { on as default };

//# sourceMappingURL=on.js.map