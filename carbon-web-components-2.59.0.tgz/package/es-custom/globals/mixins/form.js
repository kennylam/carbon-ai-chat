/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import on from "./on.js";
//#region src/globals/mixins/form.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @param Base The base class.
* @returns A mix-in to handle `formdata` event on the containing form.
*/
const FormMixin = (Base) => {
	/**
	* A mix-in class to handle `formdata` event on the containing form.
	*/
	class FormMixinImpl extends Base {
		constructor(..._args) {
			super(..._args);
			this._hFormdata = null;
		}
		connectedCallback() {
			super.connectedCallback();
			const form = this.closest("form");
			if (form) this._hFormdata = on(form, "formdata", this._handleFormdata.bind(this));
		}
		disconnectedCallback() {
			if (this._hFormdata) this._hFormdata = this._hFormdata.release();
			super.disconnectedCallback();
		}
	}
	return FormMixinImpl;
};
//#endregion
export { FormMixin as default };

//# sourceMappingURL=form.js.map