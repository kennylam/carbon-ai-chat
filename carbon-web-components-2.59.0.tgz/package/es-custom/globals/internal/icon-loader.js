/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { createIconTemplate } from "./icon-loader-utils.js";
import { unsafeSVG } from "lit/directives/unsafe-svg.js";
//#region src/globals/internal/icon-loader.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Icon utility function that returns pure SVG content without any wrapper element.
* This preserves all existing CSS selectors and provides a unified way to render icons.
*
* For Carbon icons, import directly in your component:
* import ChevronRight16 from '@carbon/icons/es/chevron--right/16.js';
*
* Usage:
*   Icon import: ${iconLoader(ChevronRight16)}
*   With attributes: ${iconLoader(ChevronRight16, { class: 'my-class', slot: 'icon' })}
*   SVG string: ${iconLoader(null, {}, '<svg>...</svg>')}
*
* @param icon - Icon descriptor from import, Lit template, or null for custom SVG
* @param attributes - Additional attributes to apply to the SVG
* @param customSvg - Custom SVG string (used when icon is null)
* @returns Lit template with pure SVG content
*/
function iconLoader(icon, attributes = {}, customSvg) {
	if (customSvg) return unsafeSVG(customSvg);
	if (icon) {
		if ("default" in icon || "attrs" in icon && "content" in icon) return createIconTemplate(icon)(attributes);
		return icon;
	}
	return null;
}
//#endregion
export { iconLoader as default, iconLoader };

//# sourceMappingURL=icon-loader.js.map