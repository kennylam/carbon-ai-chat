/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/globals/internal/feature-flags.ts
/**
* Copyright IBM Corp. 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* This file contains the list of the default values of compile-time feature flags.
*/
/**
* This flag will determine if all feature flags should be enabled
*
* @type {boolean}
*/
const CDS_FLAGS_ALL = process.env.CDS_FLAGS_ALL === "true" || false;
/**
* Enables experimental component
*
* @type {boolean}
*/
const CDS_EXPERIEMENTAL_COMPONENT_NAME = process.env.CDS_EXPERIEMENTAL_COMPONENT_NAME === "true" || CDS_FLAGS_ALL || false;
//#endregion
export { CDS_EXPERIEMENTAL_COMPONENT_NAME, CDS_FLAGS_ALL };

//# sourceMappingURL=feature-flags.js.map