/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { unsafeSVG } from "lit/directives/unsafe-svg.js";
import { formatAttributes, getAttributes } from "@carbon/icon-helpers";
//#region src/globals/internal/icon-loader-utils.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
function getIconDescriptor(descriptor) {
	return "default" in descriptor && descriptor.default ? descriptor.default : descriptor;
}
/**
* Convert an imported icon descriptor to an SVG string, e.g.
* import ChevronRight16 from '@carbon/icons/es/chevron--right/16.js';
*/
function carbonIconToSVG(descriptor, attributes = {}) {
	const iconDescriptor = getIconDescriptor(descriptor);
	if (!iconDescriptor.attrs) iconDescriptor.attrs = {};
	return `<svg ${formatAttributes(getAttributes({
		...iconDescriptor.attrs,
		...attributes
	}))}>${(iconDescriptor.content || []).map((child) => {
		if (typeof child === "string") return child;
		return elementToSVG(child);
	}).join("")}</svg>`;
}
/**
* Convert an element to SVG string
*/
function elementToSVG(element) {
	if (typeof element === "string") return element;
	const { elem = "svg", attrs = {}, content = [] } = element;
	const children = content.map(elementToSVG).join("");
	return `<${elem} ${formatAttributes(attrs)}>${children}</${elem}>`;
}
/**
* Create an icon function that returns a Lit template with unsafeSVG
*/
function createIconTemplate(descriptor) {
	return (attributes = {}) => {
		return unsafeSVG(carbonIconToSVG(descriptor, attributes));
	};
}
//#endregion
export { carbonIconToSVG, createIconTemplate };

//# sourceMappingURL=icon-loader-utils.js.map