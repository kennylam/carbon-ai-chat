/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { Directive } from "lit/directive.js";
import { directive } from "lit/async-directive.js";
//#region src/globals/directives/spread.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Stores the ClassInfo object applied to a given AttributePart.
* Used to unset existing values when a new ClassInfo object is applied.
*/
const attributesMapCache = /* @__PURE__ */ new WeakMap();
/**
* A directive that applies attributes from a key-value pairs.
* This must be used in the `...` name and must be the only part used in the attribute.
* It applies the key-value pairs in the `attributesInfo` argument
* and sets them as attribute name/value pairs.
*
*/
var SpreadDirective = class extends Directive {
	/**
	* The update function that handles the attribute setting.
	*
	* @param part an object with an API to manage the element's DOM
	* @returns the render function
	*/
	update(part, [attributesInfo]) {
		const { element } = part;
		const oldAttributesInfo = attributesMapCache.get(part);
		if (oldAttributesInfo) Object.keys(oldAttributesInfo).forEach((name) => {
			if (!(name in attributesInfo)) element.removeAttribute(name);
		});
		Object.keys(attributesInfo).forEach((name) => {
			const value = attributesInfo[name];
			if ((!oldAttributesInfo || !Object.is(value, oldAttributesInfo[name])) && typeof value !== "undefined") element.setAttribute(name, value);
		});
		attributesMapCache.set(part, attributesInfo);
		return this.render(attributesInfo);
	}
	/**
	* The rendering function that simply takes in the arguments to be used
	* in the update() function.
	*
	* @param attributesInfo The key-value pair to be set as the attribute name/value pairs.
	* @returns the attributes info
	*/
	render(attributesInfo) {
		return attributesInfo;
	}
};
const spread = directive(SpreadDirective);
//#endregion
export { spread as default };

//# sourceMappingURL=spread.js.map