/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { ifDefined } from "lit/directives/if-defined.js";
//#region src/globals/directives/if-non-empty.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A variant of `if-non-null` which stops rendering if the given value is an emptry string in addition to `null`/`undefined`.
*
* @param value The value.
*/
var if_non_empty_default = (value) => ifDefined(value === "" ? void 0 : value ?? void 0);
//#endregion
export { if_non_empty_default as default };

//# sourceMappingURL=if-non-empty.js.map