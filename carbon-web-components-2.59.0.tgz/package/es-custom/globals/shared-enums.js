/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/globals/shared-enums.ts
/**
* Copyright IBM Corp. 2020, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Color scheme for form elements.
*/
let FORM_ELEMENT_COLOR_SCHEME = /* @__PURE__ */ function(FORM_ELEMENT_COLOR_SCHEME) {
	/**
	* Regular color scheme.
	*/
	FORM_ELEMENT_COLOR_SCHEME["REGULAR"] = "";
	/**
	* Light color scheme.
	*/
	FORM_ELEMENT_COLOR_SCHEME["LIGHT"] = "light";
	return FORM_ELEMENT_COLOR_SCHEME;
}({});
//#endregion
export { FORM_ELEMENT_COLOR_SCHEME };

//# sourceMappingURL=shared-enums.js.map