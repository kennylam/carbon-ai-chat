/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { FORM_ELEMENT_COLOR_SCHEME } from "../../globals/shared-enums.js";
//#region src/components/password-input/defs.ts
/**
* Input size.
*/
let INPUT_SIZE = /* @__PURE__ */ function(INPUT_SIZE) {
	/**
	* Extra small size.
	*/
	INPUT_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	INPUT_SIZE["SMALL"] = "sm";
	/**
	* Regular size, same as medium size.
	*/
	INPUT_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	INPUT_SIZE["LARGE"] = "lg";
	return INPUT_SIZE;
}({});
/**
* Input tooltop alignment
*/
let INPUT_TOOLTIP_ALIGNMENT = /* @__PURE__ */ function(INPUT_TOOLTIP_ALIGNMENT) {
	INPUT_TOOLTIP_ALIGNMENT["START"] = "start";
	INPUT_TOOLTIP_ALIGNMENT["CENTER"] = "center";
	INPUT_TOOLTIP_ALIGNMENT["END"] = "end";
	return INPUT_TOOLTIP_ALIGNMENT;
}({});
/**
* Input tooltop direction
*/
let INPUT_TOOLTIP_DIRECTION = /* @__PURE__ */ function(INPUT_TOOLTIP_DIRECTION) {
	INPUT_TOOLTIP_DIRECTION["TOP"] = "top";
	INPUT_TOOLTIP_DIRECTION["RIGHT"] = "right";
	INPUT_TOOLTIP_DIRECTION["BOTTOM"] = "bottom";
	INPUT_TOOLTIP_DIRECTION["LEFT"] = "left";
	return INPUT_TOOLTIP_DIRECTION;
}({});
/**
* Supported input types.
*
* For this component we only support password and text
*/
let INPUT_TYPE = /* @__PURE__ */ function(INPUT_TYPE) {
	INPUT_TYPE["PASSWORD"] = "password";
	INPUT_TYPE["TEXT"] = "text";
	return INPUT_TYPE;
}({});
//#endregion
export { FORM_ELEMENT_COLOR_SCHEME as INPUT_COLOR_SCHEME, INPUT_SIZE, INPUT_TOOLTIP_ALIGNMENT, INPUT_TOOLTIP_DIRECTION, INPUT_TYPE };

//# sourceMappingURL=defs.js.map