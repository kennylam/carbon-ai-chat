/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import CDSPasswordInput from "./password-input.js";
import CDSPasswordInputSkeleton from "./password-input-skeleton.js";
//#region src/components/password-input/index.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSPasswordInput);
defineCustomElement(CDSPasswordInputSkeleton);
//#endregion
export { CDSPasswordInput, CDSPasswordInputSkeleton };

//# sourceMappingURL=index.js.map