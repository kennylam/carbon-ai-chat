/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import password_input_default from "./password-input.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/password-input/password-input-skeleton.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @element cds-custom-password-input-skeleton
*
* Skeleton of password input.
*/
var CDSPasswordInputSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hideLabel = false;
	}
	static {
		this.is = `cds-custom-password-input-skeleton`;
	}
	render() {
		const { hideLabel } = this;
		return html`
      ${!hideLabel && html` <span class="${"cds-custom"}--label ${"cds-custom"}--skeleton"></span> `}
      <div class="${"cds-custom"}--text-input ${"cds-custom"}--skeleton"></div>
    `;
	}
	static {
		this.styles = password_input_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-label"
})], CDSPasswordInputSkeleton.prototype, "hideLabel", void 0);
//#endregion
export { CDSPasswordInputSkeleton as default };

//# sourceMappingURL=password-input-skeleton.js.map