/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import search_default from "./search.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/search/search-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of search.
*/
var CDSSearchSkeleton = class extends LitElement {
	static {
		this.is = `cds-custom-search-skeleton`;
	}
	render() {
		const { size } = this;
		return html`
      <div class="${classMap({
			[`cds-custom--skeleton`]: true,
			[`cds-custom--layout--size-${size}`]: size !== void 0
		})}">
        <div class="${"cds-custom"}--search-input"></div>
      </div>
    `;
	}
	static {
		this.styles = search_default;
	}
};
__decorate([property({ reflect: true })], CDSSearchSkeleton.prototype, "size", void 0);
//#endregion
export { CDSSearchSkeleton as default };

//# sourceMappingURL=search-skeleton.js.map