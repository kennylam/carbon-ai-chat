/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/search/defs.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Search size.
*/
let SEARCH_SIZE = /* @__PURE__ */ function(SEARCH_SIZE) {
	/**
	* Extra small size.
	*/
	SEARCH_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	SEARCH_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	SEARCH_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	SEARCH_SIZE["LARGE"] = "lg";
	return SEARCH_SIZE;
}({});
//#endregion
export { SEARCH_SIZE };

//# sourceMappingURL=defs.js.map