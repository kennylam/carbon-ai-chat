/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import "./defs.js";
import code_snippet_default from "./code-snippet.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/code-snippet/code-snippet-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of code snippet.
*/
var CDSCodeSnippetSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.type = "single";
	}
	static {
		this.is = `cds-custom-code-snippet-skeleton`;
	}
	render() {
		return html`
      <div class="${"cds-custom"}--snippet-container">
        ${this.type !== "multi" ? html` <span></span> ` : html` <span></span><span></span><span></span> `}
      </div>
    `;
	}
	static {
		this.styles = code_snippet_default;
	}
};
__decorate([property({ reflect: true })], CDSCodeSnippetSkeleton.prototype, "type", void 0);
//#endregion
export { CDSCodeSnippetSkeleton as default };

//# sourceMappingURL=code-snippet-skeleton.js.map