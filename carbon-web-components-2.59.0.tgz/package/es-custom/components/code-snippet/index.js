/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../button/index.js";
import "../icon-button/index.js";
import "../copy/index.js";
import CDSCodeSnippet from "./code-snippet.js";
import CDSCodeSnippetSkeleton from "./code-snippet-skeleton.js";
//#region src/components/code-snippet/index.ts
/**
* Copyright IBM Corp. 2021, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSCodeSnippet);
defineCustomElement(CDSCodeSnippetSkeleton);
//#endregion
export { CDSCodeSnippet, CDSCodeSnippetSkeleton };

//# sourceMappingURL=index.js.map