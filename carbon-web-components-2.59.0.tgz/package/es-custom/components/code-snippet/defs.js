/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { FORM_ELEMENT_COLOR_SCHEME } from "../../globals/shared-enums.js";
//#region src/components/code-snippet/defs.ts
/**
* Code snippet types.
*/
let CODE_SNIPPET_TYPE = /* @__PURE__ */ function(CODE_SNIPPET_TYPE) {
	/**
	* Single variant.
	*/
	CODE_SNIPPET_TYPE["SINGLE"] = "single";
	/**
	* Inline variant.
	*/
	CODE_SNIPPET_TYPE["INLINE"] = "inline";
	/**
	* Multi-line variant.
	*/
	CODE_SNIPPET_TYPE["MULTI"] = "multi";
	return CODE_SNIPPET_TYPE;
}({});
//#endregion
export { FORM_ELEMENT_COLOR_SCHEME as CODE_SNIPPET_COLOR_SCHEME, CODE_SNIPPET_TYPE };

//# sourceMappingURL=defs.js.map