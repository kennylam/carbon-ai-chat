/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import FocusMixin from "../../globals/mixins/focus.js";
import "../popover/defs.js";
import copy_button_default from "./copy-button.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import Copy16 from "@carbon/icons/es/copy/16.js";
//#region src/components/copy-button/copy-button.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Copy button.
*
* @element cds-custom-copy-button
*/
var CDSCopyButton = class extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.disabled = false;
		this.feedback = "Copied!";
		this.align = "bottom";
		this.autoAlign = false;
		this.feedbackTimeout = 2e3;
	}
	static {
		this.is = `cds-custom-copy-button`;
	}
	render() {
		const { buttonClassName, disabled, feedback, feedbackTimeout, align, autoAlign } = this;
		let classes = `cds-custom--copy-btn`;
		if (buttonClassName) classes += ` ${buttonClassName}`;
		return html`
      <cds-custom-copy
        ?disabled=${disabled}
        ?autoalign=${autoAlign}
        feedback=${feedback}
        feedback-timeout=${feedbackTimeout}
        button-class-name=${classes}
        exportparts="button"
        align=${align}>
        ${iconLoader(Copy16, {
			slot: "icon",
			class: `cds-custom--snippet__icon`
		})}
        <slot slot="tooltip-content"></slot>
      </cds-custom-copy>
    `;
	}
	static {
		this.styles = copy_button_default;
	}
};
__decorate([property({
	reflect: true,
	attribute: "button-class-name"
})], CDSCopyButton.prototype, "buttonClassName", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCopyButton.prototype, "disabled", void 0);
__decorate([property()], CDSCopyButton.prototype, "feedback", void 0);
__decorate([property({ reflect: true })], CDSCopyButton.prototype, "align", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCopyButton.prototype, "autoAlign", void 0);
__decorate([property({
	type: Number,
	attribute: "feedback-timeout"
})], CDSCopyButton.prototype, "feedbackTimeout", void 0);
//#endregion
export { CDSCopyButton as default };

//# sourceMappingURL=copy-button.js.map