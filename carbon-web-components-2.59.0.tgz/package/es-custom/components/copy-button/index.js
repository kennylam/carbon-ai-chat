/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../icon-button/index.js";
import "../copy/index.js";
import CDSCopyButton from "./copy-button.js";
//#region src/components/copy-button/index.ts
/**
* Copyright IBM Corp. 2021, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSCopyButton);
//#endregion
export { CDSCopyButton };

//# sourceMappingURL=index.js.map