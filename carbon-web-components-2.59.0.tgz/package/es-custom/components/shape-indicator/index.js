/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../tooltip/index.js";
import CDSShapeIndicator from "./shape-indicator.js";
//#region src/components/shape-indicator/index.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSShapeIndicator);
//#endregion
export { CDSShapeIndicator };

//# sourceMappingURL=index.js.map