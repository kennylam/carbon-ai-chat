/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "../popover/defs.js";
import shape_indicator_default from "./shape-indicator.scss.js";
import "./defs.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import Critical from "@carbon/icons/es/critical/index.js";
import CriticalSeverity from "@carbon/icons/es/critical-severity/index.js";
import DiamondFill from "@carbon/icons/es/diamond-fill/index.js";
import LowSeverity from "@carbon/icons/es/low-severity/index.js";
import Caution from "@carbon/icons/es/caution/index.js";
import CircleFill from "@carbon/icons/es/circle-fill/index.js";
import CircleStroke from "@carbon/icons/es/circle-stroke/index.js";
//#region src/components/shape-indicator/shape-indicator.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Custom incomplete icon implementation.
* TODO: update to import '@carbon/icons' https://github.com/carbon-design-system/carbon/issues/18630
*/
const IncompleteIcon = `<svg
  xmlns="http://www.w3.org/2000/svg"
  width="16"
  height="16"
  fill="none"
  aria-hidden="true">
  <path
    fill="#fff"
    fillOpacity="0.01"
    d="M0 0h16v16H0z"
    style="mix-blend-mode: multiply;" />
  <path
    fill="#161616"
    d="M8 2a6 6 0 1 0 0 12A6 6 0 0 0 8 2Zm0 2a4.004 4.004 0 0 1 4 4H4a4.004 4.004 0 0 1 4-4Z" />
</svg>`;
/**
* Map of shape indicators to their corresponding icons
*/
const shapeMap = {
	["failed"]: Critical,
	["critical"]: CriticalSeverity,
	["high"]: Caution,
	["medium"]: DiamondFill,
	["low"]: LowSeverity,
	["cautious"]: Caution,
	["undefined"]: DiamondFill,
	["stable"]: CircleFill,
	["informative"]: LowSeverity,
	["incomplete"]: IncompleteIcon,
	["draft"]: CircleStroke
};
/**
* Shape Indicator.
* @element cds-custom-shape-indicator
*/
var CDSShapeIndicator = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.align = "right";
		this.autoalign = false;
		this.compact = false;
		this.textSize = 12;
	}
	static {
		this.is = `cds-custom-shape-indicator`;
	}
	render() {
		const shape = shapeMap[this.kind];
		if (!shape) return null;
		const shapeElement = typeof shape === "string" ? iconLoader(null, {}, shape) : iconLoader(shape);
		if (this.compact) return html`
        <cds-custom-definition-tooltip
          align=${this.align}
          ?autoalign=${this.autoalign}
          open-on-hover>
          ${shapeElement}
          <span class="${"cds-custom"}--visually-hidden"
            >${this.shapeDescription ?? this.label}</span
          >
          <span slot="definition">${this.label}</span>
        </cds-custom-definition-tooltip>
      `;
		return html`${shapeElement}${this.label}`;
	}
	static {
		this.styles = shape_indicator_default;
	}
};
__decorate([property({ reflect: true })], CDSShapeIndicator.prototype, "align", void 0);
__decorate([property({
	type: Boolean,
	reflect: false
})], CDSShapeIndicator.prototype, "autoalign", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSShapeIndicator.prototype, "compact", void 0);
__decorate([property({ attribute: "shape-description" })], CDSShapeIndicator.prototype, "shapeDescription", void 0);
__decorate([property({ attribute: "text-size" })], CDSShapeIndicator.prototype, "textSize", void 0);
__decorate([property()], CDSShapeIndicator.prototype, "label", void 0);
__decorate([property()], CDSShapeIndicator.prototype, "kind", void 0);
//#endregion
export { CDSShapeIndicator as default };

//# sourceMappingURL=shape-indicator.js.map