/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/shape-indicator/defs.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Shape indicator kinds.
*/
let SHAPE_INDICATOR_KIND = /* @__PURE__ */ function(SHAPE_INDICATOR_KIND) {
	/**
	* Failed status
	*/
	SHAPE_INDICATOR_KIND["FAILED"] = "failed";
	/**
	* Critical status
	*/
	SHAPE_INDICATOR_KIND["CRITICAL"] = "critical";
	/**
	* High severity
	*/
	SHAPE_INDICATOR_KIND["HIGH"] = "high";
	/**
	* Medium severity
	*/
	SHAPE_INDICATOR_KIND["MEDIUM"] = "medium";
	/**
	* Low severity
	*/
	SHAPE_INDICATOR_KIND["LOW"] = "low";
	/**
	* Cautious status
	*/
	SHAPE_INDICATOR_KIND["CAUTIOUS"] = "cautious";
	/**
	* Undefined status
	*/
	SHAPE_INDICATOR_KIND["UNDEFINED"] = "undefined";
	/**
	* Stable status
	*/
	SHAPE_INDICATOR_KIND["STABLE"] = "stable";
	/**
	* Informative status
	*/
	SHAPE_INDICATOR_KIND["INFORMATIVE"] = "informative";
	/**
	* Incomplete status
	*/
	SHAPE_INDICATOR_KIND["INCOMPLETE"] = "incomplete";
	/**
	* Draft status
	*/
	SHAPE_INDICATOR_KIND["DRAFT"] = "draft";
	return SHAPE_INDICATOR_KIND;
}({});
//#endregion
export { SHAPE_INDICATOR_KIND };

//# sourceMappingURL=defs.js.map