/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import CDSNumberInput from "./number-input.js";
import CDSNumberInputSkeleton from "./number-input-skeleton.js";
//#region src/components/number-input/index.ts
/**
* Copyright IBM Corp. 2021, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSNumberInput);
defineCustomElement(CDSNumberInputSkeleton);
//#endregion
export { CDSNumberInput, CDSNumberInputSkeleton };

//# sourceMappingURL=index.js.map