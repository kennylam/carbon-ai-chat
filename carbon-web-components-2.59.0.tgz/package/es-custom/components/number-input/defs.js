/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { FORM_ELEMENT_COLOR_SCHEME } from "../../globals/shared-enums.js";
//#region src/components/number-input/defs.ts
/**
* Works in conjunction with VALIDATION_STATUS
*/
let NUMBER_INPUT_VALIDATION_STATUS = /* @__PURE__ */ function(NUMBER_INPUT_VALIDATION_STATUS) {
	NUMBER_INPUT_VALIDATION_STATUS["EXCEEDED_MAXIMUM"] = "exceeded_maximum";
	NUMBER_INPUT_VALIDATION_STATUS["EXCEEDED_MINIMUM"] = "exceeded_minimum";
	return NUMBER_INPUT_VALIDATION_STATUS;
}({});
//#endregion
export { FORM_ELEMENT_COLOR_SCHEME as NUMBER_INPUT_COLOR_SCHEME, NUMBER_INPUT_VALIDATION_STATUS };

//# sourceMappingURL=defs.js.map