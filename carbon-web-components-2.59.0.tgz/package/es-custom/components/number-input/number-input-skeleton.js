/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import "../text-input/defs.js";
import number_input_default from "./number-input.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/number-input/number-input-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of number input.
*/
var CDSNumberInputSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hideLabel = false;
		this.size = "md";
	}
	static {
		this.is = `cds-custom-number-input-skeleton`;
	}
	render() {
		const { hideLabel, size } = this;
		return html`
      ${hideLabel ? "" : html` <span class="${"cds-custom"}--label ${"cds-custom"}--skeleton"></span> `}
      <div
        class="${"cds-custom"}--number ${"cds-custom"}--skeleton ${"cds-custom"}--number--${size}"></div>
    `;
	}
	static {
		this.styles = number_input_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-label"
})], CDSNumberInputSkeleton.prototype, "hideLabel", void 0);
__decorate([property({ reflect: true })], CDSNumberInputSkeleton.prototype, "size", void 0);
//#endregion
export { CDSNumberInputSkeleton as default };

//# sourceMappingURL=number-input-skeleton.js.map