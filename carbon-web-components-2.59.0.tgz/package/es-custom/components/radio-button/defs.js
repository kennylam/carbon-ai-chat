/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/radio-button/defs.ts
/**
* Copyright IBM Corp. 2020
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The label position of radio button.
*/
let RADIO_BUTTON_LABEL_POSITION = /* @__PURE__ */ function(RADIO_BUTTON_LABEL_POSITION) {
	/**
	* Placed at left.
	*/
	RADIO_BUTTON_LABEL_POSITION["LEFT"] = "left";
	/**
	* Placed at right.
	*/
	RADIO_BUTTON_LABEL_POSITION["RIGHT"] = "right";
	return RADIO_BUTTON_LABEL_POSITION;
}({});
/**
* How to lay out radio buttons.
*/
let RADIO_BUTTON_ORIENTATION = /* @__PURE__ */ function(RADIO_BUTTON_ORIENTATION) {
	/**
	* Laying out radio buttons horizontally.
	*/
	RADIO_BUTTON_ORIENTATION["HORIZONTAL"] = "horizontal";
	/**
	* Laying out radio buttons vertically.
	*/
	RADIO_BUTTON_ORIENTATION["VERTICAL"] = "vertical";
	return RADIO_BUTTON_ORIENTATION;
}({});
//#endregion
export { RADIO_BUTTON_LABEL_POSITION, RADIO_BUTTON_ORIENTATION };

//# sourceMappingURL=defs.js.map