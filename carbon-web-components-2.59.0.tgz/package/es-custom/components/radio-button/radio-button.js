/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import RadioGroupManager from "../../globals/internal/radio-group-manager.js";
import { RADIO_BUTTON_LABEL_POSITION } from "./defs.js";
import radio_button_default from "./radio-button.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/radio-button/radio-button.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Map of navigation direction by key for horizontal alignment.
*/
const navigationDirectionForKeyHorizontal = {
	ArrowLeft: -1,
	Left: -1,
	ArrowRight: 1,
	Right: 1
};
/**
* Map of navigation direction by key for vertical alignment.
*/
const navigationDirectionForKeyVertical = {
	ArrowUp: -1,
	Up: -1,
	ArrowDown: 1,
	Down: 1
};
/**
* The interface for `RadioGroupManager` for radio button.
*/
var RadioButtonDelegate = class {
	constructor(radio) {
		this._radio = radio;
	}
	get checked() {
		return this._radio.checked;
	}
	set checked(checked) {
		const { host } = this._radio.getRootNode();
		const { eventChange } = host.constructor;
		host.checked = checked;
		this._radio.tabIndex = checked ? 0 : -1;
		host.dispatchEvent(new CustomEvent(eventChange, {
			bubbles: true,
			composed: true,
			detail: {
				checked,
				value: this._radio.value,
				name: this._radio.name
			}
		}));
	}
	get tabIndex() {
		return this._radio.tabIndex;
	}
	set tabIndex(tabIndex) {
		this._radio.tabIndex = tabIndex;
	}
	get name() {
		return this._radio.name;
	}
	get disabled() {
		return this._radio.disabled;
	}
	compareDocumentPosition(other) {
		return this._radio.compareDocumentPosition(other._radio);
	}
	focus() {
		this._radio.focus();
	}
};
/**
* Radio button.
*
* @element cds-custom-radio-button
* @fires cds-custom-radio-button-changed - The custom event fired after this radio button changes its checked state.
*/
var CDSRadioButton = class extends HostListenerMixin(FocusMixin(LitElement)) {
	constructor(..._args) {
		super(..._args);
		this._manager = null;
		this._handleClick = (event) => {
			if (!event.target.matches(this.constructor?.aiLabelItem) && !event.target.matches(this.constructor?.slugItem)) {
				const { disabled, _radioButtonDelegate: radioButtonDelegate, readOnly } = this;
				if (readOnly) {
					event.preventDefault();
					return;
				}
				if (radioButtonDelegate && !disabled && !this.disabledItem) {
					this.checked = true;
					if (this._manager) this._manager.select(radioButtonDelegate, this.readOnly);
					this.dispatchEvent(new CustomEvent(this.constructor.eventChange, {
						bubbles: true,
						composed: true,
						detail: {
							checked: this.checked,
							value: this.value,
							name: this.name,
							event
						}
					}));
				}
				this.dispatchEvent(new CustomEvent(this.constructor.eventChange, {
					bubbles: true,
					composed: true,
					detail: {
						checked: this.checked,
						value: this.value,
						name: this.name,
						event
					}
				}));
			}
		};
		this._handleKeydown = (event) => {
			if (!event.target.matches(this.constructor?.aiLabelItem) && !event.target.matches(this.constructor?.slugItem)) {
				const { orientation, _radioButtonDelegate: radioButtonDelegate, disabled, disabledItem, readOnly } = this;
				const manager = this._manager;
				if (readOnly) {
					event.preventDefault();
					return;
				}
				if (radioButtonDelegate && manager && !disabled && !disabledItem) {
					const navigationDirection = (orientation === "horizontal" ? navigationDirectionForKeyHorizontal : navigationDirectionForKeyVertical)[event.key];
					if (navigationDirection) manager.select(manager.navigate(radioButtonDelegate, navigationDirection), this.readOnly);
					if (event.key === " " || event.key === "Enter") manager.select(radioButtonDelegate, this.readOnly);
				}
			}
		};
		this._hasAILabel = false;
		this.checked = false;
		this.dataTable = false;
		this.defaultChecked = false;
		this.disabledItem = false;
		this.disabled = false;
		this.hideLabel = false;
		this.invalid = false;
		this.warn = false;
		this.warnText = "";
		this.labelPosition = "right";
		this.labelText = "";
		this.orientation = "horizontal";
		this.readOnly = false;
		this.required = false;
	}
	static {
		this.is = `cds-custom-radio-button`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		const hasContent = target.assignedNodes().filter((elem) => elem.matches !== void 0 ? elem.matches(this.constructor.aiLabelItem) || elem.matches(this.constructor.slugItem) : false);
		this._hasAILabel = Boolean(hasContent);
		const type = hasContent[0].getAttribute("kind");
		hasContent[0].setAttribute("size", type === "inline" ? "md" : "mini");
		this.requestUpdate();
	}
	disconnectedCallback() {
		if (this._manager) this._manager.delete(this._radioButtonDelegate);
		super.disconnectedCallback();
	}
	firstUpdated() {
		this._radioButtonDelegate = new RadioButtonDelegate(this._inputNode);
		if (this.defaultChecked && this.checked === false) this.checked = true;
	}
	updated(changedProperties) {
		const { _hasAILabel: hasAILabel, _inputNode: inputNode, _radioButtonDelegate: radioButtonDelegate, name, disabled, disabledItem, readOnly, invalid, warn } = this;
		const normalizedProps = {
			disabled: !readOnly && (disabled || disabledItem),
			invalid: !readOnly && !disabled && !disabledItem && invalid,
			warn: !readOnly && !disabled && !disabledItem && !invalid && warn
		};
		if (changedProperties.has("checked") || changedProperties.has("name")) {
			if (!this._manager) this._manager = RadioGroupManager.get(this.getRootNode({ composed: true }));
			const { _manager: manager } = this;
			if (changedProperties.has("name")) {
				manager.delete(radioButtonDelegate, changedProperties.get("name"));
				if (name) manager.add(radioButtonDelegate);
			}
			inputNode.setAttribute("tabindex", !name || !manager || this.disabled || this.disabledItem || !manager.shouldBeFocusable(radioButtonDelegate) ? "-1" : "0");
		}
		if (changedProperties.has("invalid") || changedProperties.has("warn") || changedProperties.has("disabled") || changedProperties.has("disabledItem") || changedProperties.has("readOnly")) if (normalizedProps.invalid) {
			this.setAttribute("invalid", "");
			this.removeAttribute("warn");
		} else if (normalizedProps.warn) {
			this.setAttribute("warn", "");
			this.removeAttribute("invalid");
		} else {
			this.removeAttribute("invalid");
			this.removeAttribute("warn");
		}
		if (hasAILabel) this.setAttribute("ai-label", "");
		else this.removeAttribute("ai-label");
	}
	render() {
		const { checked, hideLabel, labelText, name, value, disabled, disabledItem, readOnly, invalid, warn } = this;
		const normalizedProps = {
			disabled: !readOnly && (disabled || disabledItem),
			invalid: !readOnly && !disabled && !disabledItem && invalid,
			warn: !readOnly && !disabled && !disabledItem && !invalid && warn
		};
		const innerLabelClasses = classMap({
			[`cds-custom--radio-button__label-text`]: true,
			[`cds-custom--visually-hidden`]: hideLabel
		});
		return html`
      <input
        id="radio"
        type="radio"
        class="${"cds-custom"}--radio-button"
        .checked=${checked}
        ?disabled="${disabledItem || disabled}"
        ?required=${this.required}
        aria-readonly="${String(readOnly)}"
        name=${ifDefined(name)}
        value=${ifDefined(value)} />
      <label
        for="input"
        class="${"cds-custom"}--radio-button__label ${normalizedProps.invalid ? `cds-custom--radio-button__label--invalid` : ""} ${normalizedProps.warn ? `cds-custom--radio-button__label--warn` : ""}">
        <span class="${"cds-custom"}--radio-button__appearance"></span>
        <span class="${innerLabelClasses}">
          <slot> ${labelText} </slot>
          <slot name="ai-label" @slotchange="${this._handleSlotChange}"></slot>
          <slot name="slug" @slotchange="${this._handleSlotChange}"></slot
        ></span>
      </label>
    `;
	}
	/**
	* A selector that will return the slug item.
	*
	* remove in v12
	*/
	static get slugItem() {
		return `cds-custom-slug`;
	}
	/**
	* A selector that will return the AI Label item.
	*/
	static get aiLabelItem() {
		return `cds-custom-ai-label`;
	}
	/**
	* The name of the custom event fired after this radio button changes its checked state.
	*/
	static get eventChange() {
		return `cds-custom-radio-button-changed`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = radio_button_default;
	}
};
__decorate([query("input")], CDSRadioButton.prototype, "_inputNode", void 0);
__decorate([HostListener("click")], CDSRadioButton.prototype, "_handleClick", void 0);
__decorate([HostListener("keydown")], CDSRadioButton.prototype, "_handleKeydown", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButton.prototype, "checked", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "data-table"
})], CDSRadioButton.prototype, "dataTable", void 0);
__decorate([property({
	type: Boolean,
	attribute: "default-checked"
})], CDSRadioButton.prototype, "defaultChecked", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButton.prototype, "disabledItem", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButton.prototype, "disabled", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-label"
})], CDSRadioButton.prototype, "hideLabel", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButton.prototype, "invalid", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButton.prototype, "warn", void 0);
__decorate([property({ attribute: "warn-text" })], CDSRadioButton.prototype, "warnText", void 0);
__decorate([property({
	reflect: true,
	attribute: "label-position"
})], CDSRadioButton.prototype, "labelPosition", void 0);
__decorate([property({ attribute: "label-text" })], CDSRadioButton.prototype, "labelText", void 0);
__decorate([property()], CDSRadioButton.prototype, "name", void 0);
__decorate([property({ reflect: true })], CDSRadioButton.prototype, "orientation", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButton.prototype, "readOnly", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButton.prototype, "required", void 0);
__decorate([property()], CDSRadioButton.prototype, "value", void 0);
//#endregion
export { RADIO_BUTTON_LABEL_POSITION, CDSRadioButton as default };

//# sourceMappingURL=radio-button.js.map