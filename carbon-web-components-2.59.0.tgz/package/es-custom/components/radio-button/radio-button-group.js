/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { find, forEach } from "../../globals/internal/collection-helpers.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import FormMixin from "../../globals/mixins/form.js";
import { RADIO_BUTTON_ORIENTATION } from "./defs.js";
import radio_button_default from "./radio-button.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
import WarningFilled16 from "@carbon/icons/es/warning--filled/16.js";
import WarningAltFilled16 from "@carbon/icons/es/warning--alt--filled/16.js";
//#region src/components/radio-button/radio-button-group.ts
/**
* Copyright IBM Corp. 2019, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Radio button group.
*
* @element cds-custom-radio-button-group
* @fires cds-custom-radio-button-group-changed - The custom event fired after this radio button group changes its selected item.
* @fires cds-custom-radio-button-changed
*   The name of the custom event fired after a radio button changes its checked state.
*/
var CDSRadioButtonGroup = class extends FormMixin(HostListenerMixin(LitElement)) {
	constructor(..._args) {
		super(..._args);
		this._handleAfterChangeRadioButton = (event) => {
			if (this.readOnly) return;
			const { selectorRadioButton } = this.constructor;
			const selected = find(this.querySelectorAll(selectorRadioButton), (elem) => elem.checked);
			const oldValue = this.value;
			this.value = selected && selected.value;
			if (oldValue !== this.value) {
				const { eventChange } = this.constructor;
				this.dispatchEvent(new CustomEvent(eventChange, {
					bubbles: true,
					composed: true,
					detail: {
						value: this.value,
						name: this.name,
						event
					}
				}));
			}
		};
		this._hasAILabel = false;
		this._helperTextId = `cds-custom--radio-button-group-helper-text-${Math.random().toString(16).slice(2)}`;
		this._invalidTextId = `cds-custom--radio-button-group-invalid-text-${Math.random().toString(16).slice(2)}`;
		this._warnTextId = `cds-custom--radio-button-group-warn-text-${Math.random().toString(16).slice(2)}`;
		this.disabled = false;
		this.labelPosition = "right";
		this.legendText = "";
		this.warn = false;
		this.warnText = "";
		this.invalid = false;
		this.invalidText = "";
		this.orientation = "horizontal";
		this.readOnly = false;
		this.required = false;
	}
	static {
		this.is = `cds-custom-radio-button-group`;
	}
	_handleFormdata(event) {
		const { formData } = event;
		const { disabled, name, value } = this;
		if (!disabled && typeof name !== "undefined" && typeof value !== "undefined") formData.append(name, value);
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		const hasContent = target.assignedNodes().filter((elem) => elem.matches !== void 0 ? elem.matches(this.constructor.aiLabelItem) || elem.matches(this.constructor.slugItem) : false);
		this._hasAILabel = Boolean(hasContent);
		hasContent[0].setAttribute("size", "mini");
		this.requestUpdate();
	}
	updated(changedProperties) {
		const { selectorRadioButton } = this.constructor;
		[
			"disabled",
			"labelPosition",
			"orientation",
			"readOnly",
			"name",
			"required"
		].forEach((name) => {
			if (changedProperties.has(name)) {
				const { [name]: value } = this;
				forEach(this.querySelectorAll(selectorRadioButton), (elem) => {
					elem[name] = value;
				});
			}
		});
		if (changedProperties.has("value")) {
			const { value } = this;
			forEach(this.querySelectorAll(selectorRadioButton), (elem) => {
				elem.checked = value === elem.value;
			});
		}
		if (changedProperties.has("invalid")) forEach(this.querySelectorAll(selectorRadioButton), (elem) => {
			elem.invalid = this.invalid;
		});
	}
	render() {
		const { readOnly, invalid, invalidText, warn, warnText, disabled, orientation, legendText, helperText, _hasAILabel: hasAILabel, _handleSlotChange: handleSlotChange } = this;
		const showWarning = !readOnly && !disabled && !invalid && warn;
		const showInvalid = !readOnly && !disabled && invalid;
		const showHelper = !invalid && !disabled && !warn;
		const describedBy = showInvalid ? this._invalidTextId : showWarning ? this._warnTextId : showHelper && helperText ? this._helperTextId : void 0;
		const invalidIcon = iconLoader(WarningFilled16, { class: `cds-custom--radio-button__invalid-icon` });
		const warnIcon = iconLoader(WarningAltFilled16, { class: `cds-custom--radio-button__invalid-icon cds-custom--radio-button__invalid-icon--warning` });
		const helper = helperText ? html`<div
          id="${this._helperTextId}"
          class="${"cds-custom"}--form__helper-text">
          ${helperText}
        </div>` : null;
		return html` <fieldset
        class="${classMap({
			[`cds-custom--radio-button-group`]: true,
			[`cds-custom--radio-button-group--readonly`]: readOnly,
			[`cds-custom--radio-button-group--${orientation}`]: orientation === "vertical",
			[`cds-custom--radio-button-group--invalid`]: !readOnly && !disabled && invalid,
			[`cds-custom--radio-button-group--warning`]: showWarning,
			[`cds-custom--radio-button-group--slug`]: hasAILabel
		})}"
        ?disabled="${disabled}"
        aria-describedby="${ifDefined(describedBy)}"
        aria-readonly="${readOnly}">
        ${legendText ? html` <legend class="${"cds-custom"}--label">
              ${legendText}
              <slot name="ai-label" @slotchange="${handleSlotChange}"></slot>
              <slot name="slug" @slotchange="${handleSlotChange}"></slot>
            </legend>` : ``}
        <slot></slot>
      </fieldset>
      <div class="${"cds-custom"}--radio-button__validation-msg">
        ${showInvalid ? html`
              ${invalidIcon}
              <div
                id="${this._invalidTextId}"
                class="${"cds-custom"}--form-requirement">
                ${invalidText}
              </div>
            ` : null}
        ${showWarning ? html`${warnIcon}
              <div id="${this._warnTextId}" class="${"cds-custom"}--form-requirement">
                ${warnText}
              </div>` : null}
      </div>
      ${showHelper ? helper : null}`;
	}
	/**
	* A selector that will return the radio buttons.
	*/
	static get selectorRadioButton() {
		return `cds-custom-radio-button`;
	}
	/**
	* A selector that will return the slug item.
	*
	* remove in v12
	*/
	static get slugItem() {
		return `cds-custom-slug`;
	}
	/**
	* A selector that will return the AI Label item.
	*/
	static get aiLabelItem() {
		return `cds-custom-ai-label`;
	}
	/**
	* The name of the custom event fired after this radio button group changes its selected item.
	*/
	static get eventChange() {
		return `cds-custom-radio-button-group-changed`;
	}
	/**
	* The name of the custom event fired after a radio button changes its checked state.
	*/
	static get eventChangeRadioButton() {
		return `cds-custom-radio-button-changed`;
	}
	static {
		this.styles = radio_button_default;
	}
};
__decorate([HostListener("eventChangeRadioButton")], CDSRadioButtonGroup.prototype, "_handleAfterChangeRadioButton", void 0);
__decorate([property()], CDSRadioButtonGroup.prototype, "defaultSelected", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButtonGroup.prototype, "disabled", void 0);
__decorate([property({
	reflect: true,
	attribute: "label-position"
})], CDSRadioButtonGroup.prototype, "labelPosition", void 0);
__decorate([property({
	reflect: true,
	attribute: "legend-text"
})], CDSRadioButtonGroup.prototype, "legendText", void 0);
__decorate([property({ attribute: "helper-text" })], CDSRadioButtonGroup.prototype, "helperText", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButtonGroup.prototype, "warn", void 0);
__decorate([property({ attribute: "warn-text" })], CDSRadioButtonGroup.prototype, "warnText", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButtonGroup.prototype, "invalid", void 0);
__decorate([property({ attribute: "invalid-text" })], CDSRadioButtonGroup.prototype, "invalidText", void 0);
__decorate([property()], CDSRadioButtonGroup.prototype, "name", void 0);
__decorate([property({ reflect: true })], CDSRadioButtonGroup.prototype, "orientation", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButtonGroup.prototype, "readOnly", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSRadioButtonGroup.prototype, "required", void 0);
__decorate([property()], CDSRadioButtonGroup.prototype, "value", void 0);
//#endregion
export { RADIO_BUTTON_ORIENTATION, CDSRadioButtonGroup as default };

//# sourceMappingURL=radio-button-group.js.map