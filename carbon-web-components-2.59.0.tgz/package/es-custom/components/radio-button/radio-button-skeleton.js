/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import radio_button_default from "./radio-button.scss.js";
import { LitElement, html } from "lit";
//#region src/components/radio-button/radio-button-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of radio button.
*/
var CDSRadioButtonSkeleton = class extends LitElement {
	static {
		this.is = `cds-custom-radio-button-skeleton`;
	}
	render() {
		return html`
      <div class="${"cds-custom"}--radio-button ${"cds-custom"}--skeleton"></div>
      <span class="${"cds-custom"}--radio-button__label ${"cds-custom"}--skeleton"></span>
    `;
	}
	static {
		this.styles = radio_button_default;
	}
};
//#endregion
export { CDSRadioButtonSkeleton as default };

//# sourceMappingURL=radio-button-skeleton.js.map