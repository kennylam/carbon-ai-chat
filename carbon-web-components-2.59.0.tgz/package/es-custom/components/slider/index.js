/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSSlider from "./slider.js";
import CDSSliderInput from "./slider-input.js";
import CDSSliderSkeleton from "./slider-skeleton.js";
//#region src/components/slider/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSSlider);
defineCustomElement(CDSSliderInput);
defineCustomElement(CDSSliderSkeleton);
//#endregion
export { CDSSlider, CDSSliderInput, CDSSliderSkeleton };

//# sourceMappingURL=index.js.map