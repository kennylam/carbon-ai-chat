/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSSkeletonPlaceholder from "./skeleton-placeholder.js";
//#region src/components/skeleton-placeholder/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSSkeletonPlaceholder);
//#endregion
export { CDSSkeletonPlaceholder };

//# sourceMappingURL=index.js.map