/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import skeleton_placeholder_default from "./skeleton-placeholder.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/skeleton-placeholder/skeleton-placeholder.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton placeholder.
*
* @element cds-custom-skeleton-placeholder
*/
var CDSSkeletonPlaceholder = class extends LitElement {
	static {
		this.is = `cds-custom-skeleton-placeholder`;
	}
	render() {
		let defaultClasses = { [`cds-custom--skeleton__placeholder`]: true };
		if (this.optionalClasses) {
			const outputObject = {};
			this.optionalClasses?.split(" ").forEach((element) => {
				outputObject[element] = true;
			});
			defaultClasses = {
				...defaultClasses,
				...outputObject
			};
		}
		return html` <div part="placeholder" class="${classMap(defaultClasses)}"></div> `;
	}
	static {
		this.styles = skeleton_placeholder_default;
	}
};
__decorate([property({
	reflect: true,
	attribute: "optional-classes"
})], CDSSkeletonPlaceholder.prototype, "optionalClasses", void 0);
//#endregion
export { CDSSkeletonPlaceholder as default };

//# sourceMappingURL=skeleton-placeholder.js.map