/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { html } from "lit";
//#region src/components/loading/loading-icon.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @param Object options The options.
* @param [Object.assistiveText] The assistive text for the spinner icon.
* @param [Object.type] The spinner type.
* @returns The spinner icon.
*/
var loading_icon_default = ({ description, small }) => {
	const radius = small ? "42" : "44";
	return html`
    <svg class="${"cds-custom"}--loading__svg" viewBox="0 0 100 100">
      ${!description ? void 0 : html` <title>${description}</title> `}
      <circle
        ?hidden="${!small}"
        class="${"cds-custom"}--loading__background"
        cx="50%"
        cy="50%"
        r="${radius}" />
      <circle
        class="${"cds-custom"}--loading__stroke"
        cx="50%"
        cy="50%"
        r="${radius}" />
    </svg>
  `;
};
//#endregion
export { loading_icon_default as default };

//# sourceMappingURL=loading-icon.js.map