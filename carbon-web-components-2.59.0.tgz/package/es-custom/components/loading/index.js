/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSLoading from "./loading.js";
//#region src/components/loading/index.ts
/**
* Copyright IBM Corp. 2021, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSLoading);
//#endregion
export { CDSLoading };

//# sourceMappingURL=index.js.map