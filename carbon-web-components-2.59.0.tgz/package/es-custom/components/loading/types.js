/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { LOADING_TYPE } from "./defs.js";
//#region src/components/loading/types.ts
/**
* Copyright IBM Corp. 2019, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @deprecated Use `defs.ts`
*/
var types_default = LOADING_TYPE;
//#endregion
export { types_default as default };

//# sourceMappingURL=types.js.map