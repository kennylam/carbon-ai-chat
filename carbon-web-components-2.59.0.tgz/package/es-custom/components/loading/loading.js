/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import loading_icon_default from "./loading-icon.js";
import { LOADING_TYPE } from "./defs.js";
import loading_default from "./loading.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/loading/loading.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Spinner indicating loading state.
*
* @element cds-custom-loading
*/
var CDSLoading = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.description = "Loading";
		this.small = false;
		this.overlay = false;
		this.active = false;
	}
	static {
		this.is = `cds-custom-loading`;
	}
	/**
	* @deprecated
	* The 'assistive-text' property will be deprecated in the next major release. Please use `description` instead.
	*/
	get assistiveText() {
		return this.description;
	}
	set assistiveText(value) {
		this.description = value;
	}
	/**
	*
	* @deprecated The 'type' property will be deprecated in the next major release. Please use `small` instead.
	*/
	get type() {
		return this.small ? "small" : "regular";
	}
	set type(value) {
		this.small = value == "small";
	}
	/**
	*
	* @deprecated
	* The 'inactive' property will be deprecated in the next major release. Please use `active` instead.
	*/
	get inactive() {
		return !this.active;
	}
	set inactive(value) {
		this.active = !value;
	}
	render() {
		const { active, description, small, overlay } = this;
		const innerClasses = classMap({
			[`cds-custom--loading`]: true,
			[`cds-custom--loading--stop`]: !active,
			[`cds-custom--loading--small`]: small
		});
		const icon = loading_icon_default({
			description,
			small
		});
		return overlay ? html`<div class="${innerClasses}">${icon}</div>` : icon;
	}
	static {
		this.styles = loading_default;
	}
};
__decorate([property({ attribute: "assistive-text" })], CDSLoading.prototype, "assistiveText", null);
__decorate([property({ reflect: true })], CDSLoading.prototype, "description", void 0);
__decorate([property()], CDSLoading.prototype, "type", null);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSLoading.prototype, "small", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSLoading.prototype, "overlay", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSLoading.prototype, "inactive", null);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSLoading.prototype, "active", void 0);
//#endregion
export { LOADING_TYPE, CDSLoading as default };

//# sourceMappingURL=loading.js.map