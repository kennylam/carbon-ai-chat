/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/loading/defs.ts
/**
* Copyright IBM Corp. 2020, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Spinner types.
*/
let LOADING_TYPE = /* @__PURE__ */ function(LOADING_TYPE) {
	/**
	* Regular spinner.
	*/
	LOADING_TYPE["REGULAR"] = "regular";
	/**
	* Small spinner.
	*/
	LOADING_TYPE["SMALL"] = "small";
	return LOADING_TYPE;
}({});
//#endregion
export { LOADING_TYPE };

//# sourceMappingURL=defs.js.map