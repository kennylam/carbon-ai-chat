/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSTag from "./tag.js";
import CDSDismissibleTag from "./dismissible-tag.js";
import CDSTagSkeleton from "./tag-skeleton.js";
import CDSSelectableTag from "./selectable-tag.js";
import CDSOperationalTag from "./operational-tag.js";
//#region src/components/tag/index.ts
/**
* Copyright IBM Corp. 2021, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSTag);
defineCustomElement(CDSDismissibleTag);
defineCustomElement(CDSTagSkeleton);
defineCustomElement(CDSSelectableTag);
defineCustomElement(CDSOperationalTag);
//#endregion
export { CDSDismissibleTag, CDSOperationalTag, CDSSelectableTag, CDSTag, CDSTagSkeleton };

//# sourceMappingURL=index.js.map