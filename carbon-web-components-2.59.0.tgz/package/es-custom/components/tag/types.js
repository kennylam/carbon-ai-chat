/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { TAG_TYPE } from "./defs.js";
//#region src/components/tag/types.ts
/**
* Copyright IBM Corp. 2019, 2020
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @deprecated Use `defs.ts`
*/
var types_default = TAG_TYPE;
//#endregion
export { types_default as default };

//# sourceMappingURL=types.js.map