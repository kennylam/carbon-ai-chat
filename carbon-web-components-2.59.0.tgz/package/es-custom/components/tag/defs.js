/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/tag/defs.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Tag size.
*/
let TAG_SIZE = /* @__PURE__ */ function(TAG_SIZE) {
	/**
	* Large size.
	*/
	TAG_SIZE["LARGE"] = "lg";
	/**
	* Medium size (default).
	*/
	TAG_SIZE["MEDIUM"] = "md";
	/**
	* Small size.
	*/
	TAG_SIZE["SMALL"] = "sm";
	return TAG_SIZE;
}({});
let TAG_TYPE = /* @__PURE__ */ function(TAG_TYPE) {
	/**
	* Red color.
	*/
	TAG_TYPE["RED"] = "red";
	/**
	* Magenta color.
	*/
	TAG_TYPE["MAGENTA"] = "magenta";
	/**
	* Purple color.
	*/
	TAG_TYPE["PURPLE"] = "purple";
	/**
	* Blue color.
	*/
	TAG_TYPE["BLUE"] = "blue";
	/**
	* Cyan color.
	*/
	TAG_TYPE["CYAN"] = "cyan";
	/**
	* Teal color.
	*/
	TAG_TYPE["TEAL"] = "teal";
	/**
	* Green color.
	*/
	TAG_TYPE["GREEN"] = "green";
	/**
	* Gray color.
	*/
	TAG_TYPE["GRAY"] = "gray";
	/**
	* Cool gray color.
	*/
	TAG_TYPE["COOL-GRAY"] = "cool-gray";
	/**
	* Warn gray color.
	*/
	TAG_TYPE["WARM-GRAY"] = "warm-gray";
	return TAG_TYPE;
}({});
//#endregion
export { TAG_SIZE, TAG_TYPE };

//# sourceMappingURL=defs.js.map