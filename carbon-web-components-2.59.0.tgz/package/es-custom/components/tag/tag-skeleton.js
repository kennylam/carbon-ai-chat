/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import "./defs.js";
import tag_default from "./tag.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/tag/tag-skeleton.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of tag.
*
* @element cds-custom-tag-skeleton
*/
var CDSTagSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.size = "sm";
	}
	static {
		this.is = `cds-custom-tag-skeleton`;
	}
	render() {
		return html` <span class="${classMap({
			[`cds-custom--tag`]: true,
			[`cds-custom--skeleton`]: true,
			[`cds-custom--layout--size-${this.size}`]: this.size
		})}"></span> `;
	}
	static {
		this.styles = tag_default;
	}
};
__decorate([property({
	reflect: true,
	type: String
})], CDSTagSkeleton.prototype, "size", void 0);
//#endregion
export { CDSTagSkeleton as default };

//# sourceMappingURL=tag-skeleton.js.map