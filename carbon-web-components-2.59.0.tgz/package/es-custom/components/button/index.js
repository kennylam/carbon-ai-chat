/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSButton from "./button.js";
import CDSButtonSetBase from "./button-set-base.js";
import CDSButtonSet from "./button-set.js";
import CDSButtonSkeleton from "./button-skeleton.js";
//#region src/components/button/index.ts
/**
* Copyright IBM Corp. 2021, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSButton);
defineCustomElement(CDSButtonSetBase);
defineCustomElement(CDSButtonSet);
defineCustomElement(CDSButtonSkeleton);
//#endregion
export { CDSButton, CDSButtonSet, CDSButtonSetBase, CDSButtonSkeleton };

//# sourceMappingURL=index.js.map