/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import button_default from "./button.scss.js";
import { LitElement, html } from "lit";
//#region src/components/button/button-set-base.ts
/**
* Copyright IBM Corp. 2020, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Button set without button checks
*
* @element cds-custom-button-set-base
*/
var CDSButtonSetBase = class extends LitElement {
	static {
		this.is = `cds-custom-button-set-base`;
	}
	render() {
		return html`<slot></slot>`;
	}
	connectedCallback() {
		super.connectedCallback();
		this.setAttribute("role", "list");
	}
	static {
		this.styles = button_default;
	}
};
//#endregion
export { CDSButtonSetBase as default };

//# sourceMappingURL=button-set-base.js.map