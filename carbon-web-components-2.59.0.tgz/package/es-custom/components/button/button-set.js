/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import "./defs.js";
import button_default from "./button.scss.js";
import CDSButtonSetBase from "./button-set-base.js";
import { html } from "lit";
import { property, query } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/button/button-set.ts
/**
* Copyright IBM Corp. 2020, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Button set.
*
* @element cds-custom-button-set
*/
var CDSButtonSet = class extends CDSButtonSetBase {
	constructor(..._args) {
		super(..._args);
		this.stacked = false;
		this._hideSiblingMargin = () => {
			if (!this._slotElement) return;
			const items = this._slotElement.assignedElements().filter((el) => el.tagName.toLowerCase() === `cds-custom-button`);
			const focusedIndex = items.findIndex((el) => el.matches(":focus-within"));
			items.forEach((el, idx) => {
				const shouldHide = focusedIndex >= 0 && (idx === focusedIndex || idx === focusedIndex + 1);
				el.toggleAttribute("hide-margin", shouldHide);
			});
		};
	}
	static {
		this.is = `cds-custom-button-set`;
	}
	/**
	* Handler for @slotchange, set the first cds-custom-button to kind secondary and primary for the remaining ones
	*
	* @private
	*/
	_handleSlotChange(event) {
		event.target.assignedNodes().filter((elem) => elem.matches !== void 0 ? elem.matches(this.constructor.selectorItem) : false).forEach((elem, index) => {
			elem.setAttribute("kind", index === 0 ? "secondary" : "primary");
		});
		const update = new CustomEvent(`cds-custom-btn-set-update`, {
			bubbles: true,
			cancelable: true,
			composed: true
		});
		this.dispatchEvent(update);
	}
	connectedCallback() {
		super.connectedCallback?.();
		this.addEventListener("focusin", this._hideSiblingMargin);
		this.addEventListener("focusout", this._hideSiblingMargin);
	}
	render() {
		const { stacked } = this;
		return html`<slot
      class="${classMap({
			[`cds-custom--btn-set--stacked`]: stacked,
			[`cds-custom--btn-set`]: true
		})}"
      part="button-set"
      @slotchange="${this._handleSlotChange}"></slot>`;
	}
	/**
	* A selector that will return the child items.
	*/
	static get selectorItem() {
		return `cds-custom-button`;
	}
	static {
		this.styles = button_default;
	}
};
__decorate([query("slot")], CDSButtonSet.prototype, "_slotElement", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSButtonSet.prototype, "stacked", void 0);
//#endregion
export { CDSButtonSet as default };

//# sourceMappingURL=button-set.js.map