/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSFormItem from "./form-item.js";
import CDSForm from "./form.js";
//#region src/components/form/index.ts
/**
* Copyright IBM Corp. 2021, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFormItem);
defineCustomElement(CDSForm);
//#endregion
export { CDSForm, CDSFormItem };

//# sourceMappingURL=index.js.map