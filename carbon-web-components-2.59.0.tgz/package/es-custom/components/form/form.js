/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import form_default from "./form.scss.js";
import { LitElement, html } from "lit";
//#region src/components/form/form.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Presentational element for form
*
* @element cds-custom-form
*/
var CDSForm = class extends LitElement {
	static {
		this.is = `cds-custom-form`;
	}
	render() {
		return html`<form class="${"cds-custom"}--form">
      <slot></slot>
    </form>`;
	}
	static {
		this.styles = form_default;
	}
};
//#endregion
export { CDSForm as default };

//# sourceMappingURL=form.js.map