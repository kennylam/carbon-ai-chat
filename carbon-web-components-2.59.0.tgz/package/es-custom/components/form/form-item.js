/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import form_item_default from "./form-item.scss.js";
import { LitElement, html } from "lit";
//#region src/components/form/form-item.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Presentational element for form items
*
* @element cds-custom-form-item
*/
var CDSFormItem = class extends LitElement {
	static {
		this.is = `cds-custom-form-item`;
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = form_item_default;
	}
};
//#endregion
export { CDSFormItem as default };

//# sourceMappingURL=form-item.js.map