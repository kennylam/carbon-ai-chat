/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import layer_default from "./layer.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/layer/layer.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Layer level constants
*/
const MIN_LEVEL = 0;
const MAX_LEVEL = 2;
const levels = [
	"zero",
	"one",
	"two"
];
/**
* Basic layer
*
* @element cds-custom-layer
* @fires cds-custom-use-layer
*   The custom event that returns the layer level and the layer element.
* @slot children - The elements contained within the component.
*/
var CDSLayer = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.level = 0;
	}
	static {
		this.is = `cds-custom-layer`;
	}
	updated() {
		if (!this.layers) this.layers = this.querySelectorAll(this.constructor.selectorLayer);
		this.layers.forEach((item) => {
			const nextLevel = Math.max(0, Math.min(this.level + 1, 2));
			item.setAttribute("level", nextLevel.toString());
		});
		this.dispatchEvent(new CustomEvent(this.constructor.eventUseLayer, {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: {
				layer: this,
				level: this.level
			}
		}));
	}
	render() {
		return html` <slot></slot> `;
	}
	/**
	* A selector that selects a layer component.
	*/
	static get selectorLayer() {
		return `cds-custom-layer`;
	}
	/**
	* A selector that selects a layer component.
	*/
	static get eventUseLayer() {
		return `cds-custom-use-layer`;
	}
	static {
		this.styles = layer_default;
	}
};
__decorate([property({
	type: Number,
	reflect: true
})], CDSLayer.prototype, "level", void 0);
__decorate([property()], CDSLayer.prototype, "layers", void 0);
__decorate([property({
	type: Boolean,
	attribute: "with-background"
})], CDSLayer.prototype, "withBackground", void 0);
//#endregion
export { MAX_LEVEL, MIN_LEVEL, CDSLayer as default, levels };

//# sourceMappingURL=layer.js.map