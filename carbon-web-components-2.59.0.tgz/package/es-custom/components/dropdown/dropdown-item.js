/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "./defs.js";
import dropdown_default from "./dropdown.scss.js";
import { LitElement, html } from "lit";
import { property, query, state } from "lit/decorators.js";
import Checkmark16 from "@carbon/icons/es/checkmark/16.js";
//#region src/components/dropdown/dropdown-item.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dropdown item.
*
* @element cds-custom-dropdown-item
* @csspart selected-icon The selected icon.
*/
var CDSDropdownItem = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.disabled = false;
		this.highlighted = false;
		this.selected = false;
		this.size = "md";
		this.value = "";
		this._hasEllipsisApplied = false;
		this._nextSiblingRef = null;
		this._handleMouseEnter = () => {
			if (this.hasAttribute("disabled")) return;
			this._syncNextSibling("hovered-next-sibling", true);
		};
		this._handleMouseLeave = () => {
			this._syncNextSibling("hovered-next-sibling", false);
		};
	}
	static {
		this.is = `cds-custom-dropdown-item`;
	}
	/**
	* Gets the next dropdown/combo-box item sibling.
	*/
	_getNextItem() {
		let next = this.nextElementSibling;
		while (next) {
			if (next instanceof HTMLElement && (next.tagName.toLowerCase() === `cds-custom-dropdown-item` || next.tagName.toLowerCase() === `cds-custom-combo-box-item`)) return next;
			next = next.nextElementSibling;
		}
		return null;
	}
	/**
	* Syncs the hovered-next-sibling attribute with the next item.
	*/
	_syncNextSibling(attribute, shouldSet) {
		this._nextSiblingRef?.removeAttribute(attribute);
		if (shouldSet) {
			const next = this._getNextItem();
			if (next) {
				next.setAttribute(attribute, "");
				this._nextSiblingRef = next;
				return;
			}
		}
		this._nextSiblingRef = null;
	}
	connectedCallback() {
		super.connectedCallback();
		if (!this.hasAttribute("role")) this.setAttribute("role", "option");
		if (!this.hasAttribute("id")) this.setAttribute("id", `cds-custom-dropdown-item-${this.constructor.id++}`);
		this.setAttribute("aria-selected", String(this.selected));
		this.addEventListener("mouseenter", this._handleMouseEnter);
		this.addEventListener("mouseleave", this._handleMouseLeave);
	}
	disconnectedCallback() {
		this.removeEventListener("mouseenter", this._handleMouseEnter);
		this.removeEventListener("mouseleave", this._handleMouseLeave);
		this._syncNextSibling("hovered-next-sibling", false);
		super.disconnectedCallback();
	}
	/**
	* Handles `slotchange` event.
	*
	* Adds the `title` property to its parent element so the native
	* browser tooltip appears for menu items that result in ellipsis
	*/
	_handleSlotChange({ target }) {
		const text = target.assignedNodes().filter((node) => node.nodeType !== Node.TEXT_NODE || node.textContent.trim());
		const textContainer = this._textContainer;
		if (!textContainer || this._hasEllipsisApplied === true) return;
		new ResizeObserver(() => {
			this._hasEllipsisApplied = textContainer.scrollWidth > textContainer.clientWidth;
			if (this._hasEllipsisApplied) textContainer.setAttribute("title", text[0].textContent ?? "");
		}).observe(textContainer);
	}
	render() {
		const { selected, _handleSlotChange: handleSlotChange } = this;
		return html`
      <div class="${"cds-custom"}--list-box__menu-item__option" part="menu-item">
        <slot @slotchange=${handleSlotChange}></slot>
        ${!selected ? void 0 : iconLoader(Checkmark16, {
			part: "selected-icon",
			class: `cds-custom--list-box__menu-item__selected-icon`
		})}
      </div>
    `;
	}
	static {
		this.id = 0;
	}
	static {
		this.styles = dropdown_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSDropdownItem.prototype, "disabled", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSDropdownItem.prototype, "highlighted", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSDropdownItem.prototype, "selected", void 0);
__decorate([property({ reflect: true })], CDSDropdownItem.prototype, "size", void 0);
__decorate([property()], CDSDropdownItem.prototype, "value", void 0);
__decorate([state()], CDSDropdownItem.prototype, "_hasEllipsisApplied", void 0);
__decorate([query(`.cds-custom--list-box__menu-item__option`)], CDSDropdownItem.prototype, "_textContainer", void 0);
//#endregion
export { CDSDropdownItem as default };

//# sourceMappingURL=dropdown-item.js.map