/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../toggle-tip/index.js";
import "../ai-label/index.js";
import CDSDropdown from "./dropdown.js";
import CDSDropdownItem from "./dropdown-item.js";
import CDSDropdownSkeleton from "./dropdown-skeleton.js";
//#region src/components/dropdown/index.ts
/**
* Copyright IBM Corp. 2021, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSDropdown);
defineCustomElement(CDSDropdownItem);
defineCustomElement(CDSDropdownSkeleton);
//#endregion
export { CDSDropdown, CDSDropdownItem, CDSDropdownSkeleton };

//# sourceMappingURL=index.js.map