/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { FORM_ELEMENT_COLOR_SCHEME } from "../../globals/shared-enums.js";
//#region src/components/dropdown/defs.ts
/**
* Navigation direction, associated with key symbols.
*/
const NAVIGATION_DIRECTION = {
	Up: -1,
	ArrowUp: -1,
	Down: 1,
	ArrowDown: 1
};
/**
* The keyboard action categories for dropdown.
*/
let DROPDOWN_KEYBOARD_ACTION = /* @__PURE__ */ function(DROPDOWN_KEYBOARD_ACTION) {
	/**
	* Not doing any action.
	*/
	DROPDOWN_KEYBOARD_ACTION["NONE"] = "none";
	/**
	* Keyboard action to close menu.
	*/
	DROPDOWN_KEYBOARD_ACTION["CLOSING"] = "closing";
	/**
	* Keyboard action to navigate back/forward.
	*/
	DROPDOWN_KEYBOARD_ACTION["NAVIGATING"] = "navigating";
	/**
	* Keyboard action to open/close menu on the trigger button or select/deselect a menu item.
	*/
	DROPDOWN_KEYBOARD_ACTION["TRIGGERING"] = "triggering";
	return DROPDOWN_KEYBOARD_ACTION;
}({});
/**
* Dropdown size.
*/
let DROPDOWN_SIZE = /* @__PURE__ */ function(DROPDOWN_SIZE) {
	/**
	* Extra small size.
	*/
	DROPDOWN_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	DROPDOWN_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	DROPDOWN_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	DROPDOWN_SIZE["LARGE"] = "lg";
	return DROPDOWN_SIZE;
}({});
/**
* Dropdown types.
*/
let DROPDOWN_TYPE = /* @__PURE__ */ function(DROPDOWN_TYPE) {
	/**
	* Default type.
	*/
	DROPDOWN_TYPE["DEFAULT"] = "";
	/**
	* Inline type.
	*/
	DROPDOWN_TYPE["INLINE"] = "inline";
	return DROPDOWN_TYPE;
}({});
/**
* Dropdown direction.
*/
let DROPDOWN_DIRECTION = /* @__PURE__ */ function(DROPDOWN_DIRECTION) {
	/**
	* Top.
	*/
	DROPDOWN_DIRECTION["TOP"] = "top";
	/**
	* Bottom.
	*/
	DROPDOWN_DIRECTION["BOTTOM"] = "bottom";
	return DROPDOWN_DIRECTION;
}({});
//#endregion
export { FORM_ELEMENT_COLOR_SCHEME as DROPDOWN_COLOR_SCHEME, DROPDOWN_DIRECTION, DROPDOWN_KEYBOARD_ACTION, DROPDOWN_SIZE, DROPDOWN_TYPE, NAVIGATION_DIRECTION };

//# sourceMappingURL=defs.js.map