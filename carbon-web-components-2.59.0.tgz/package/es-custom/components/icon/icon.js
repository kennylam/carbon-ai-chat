/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import { createIconTemplate } from "../../globals/internal/icon-loader-utils.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/icon/icon.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Icon component that renders imported icons or custom SVG content.
*
* @element cds-custom-icon
* @slot - The icon content (for custom SVG)
*/
var CDSIcon = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.size = 16;
		this.ariaLabel = null;
	}
	static {
		this.is = `cds-custom-icon`;
	}
	render() {
		const { icon, size, class: className, ariaLabel } = this;
		if (icon) return createIconTemplate(icon)({
			class: className || "",
			"aria-label": ariaLabel || "",
			"aria-hidden": !ariaLabel ? "true" : "false",
			width: size,
			height: size
		});
		return html`<slot></slot>`;
	}
};
__decorate([property({ type: Object })], CDSIcon.prototype, "icon", void 0);
__decorate([property({ type: Number })], CDSIcon.prototype, "size", void 0);
__decorate([property({ type: String })], CDSIcon.prototype, "class", void 0);
__decorate([property({
	type: String,
	attribute: "aria-label"
})], CDSIcon.prototype, "ariaLabel", void 0);
//#endregion
export { CDSIcon as default };

//# sourceMappingURL=icon.js.map