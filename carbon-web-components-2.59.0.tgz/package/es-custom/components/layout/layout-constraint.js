/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import layout_default from "./layout.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/layout/layout-constraint.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* `<cds-custom-layout-constraint>` restricts the size range available to its
* descendant components.
*
* @element cds-custom-layout-constraint
*/
var CDSLayoutConstraint = class extends LitElement {
	static {
		this.is = `cds-custom-layout-constraint`;
	}
	static {
		this.styles = layout_default;
	}
	render() {
		return html`<slot></slot>`;
	}
};
__decorate([property({
	attribute: "size-default",
	reflect: true
})], CDSLayoutConstraint.prototype, "sizeDefault", void 0);
__decorate([property({
	attribute: "size-min",
	reflect: true
})], CDSLayoutConstraint.prototype, "sizeMin", void 0);
__decorate([property({
	attribute: "size-max",
	reflect: true
})], CDSLayoutConstraint.prototype, "sizeMax", void 0);
//#endregion
export { CDSLayoutConstraint, CDSLayoutConstraint as default };

//# sourceMappingURL=layout-constraint.js.map