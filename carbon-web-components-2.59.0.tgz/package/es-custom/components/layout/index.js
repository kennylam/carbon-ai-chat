/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import { CDSLayout } from "./layout.js";
import { CDSLayoutConstraint } from "./layout-constraint.js";
//#region src/components/layout/index.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSLayout);
defineCustomElement(CDSLayoutConstraint);
//#endregion
export { CDSLayout, CDSLayoutConstraint };

//# sourceMappingURL=index.js.map