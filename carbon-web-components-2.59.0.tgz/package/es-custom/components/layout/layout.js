/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import layout_default from "./layout.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/layout/layout.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const LAYOUT_SIZES = [
	"xs",
	"sm",
	"md",
	"lg",
	"xl",
	"2xl"
];
const LAYOUT_DENSITIES = ["condensed", "normal"];
/**
* `<cds-custom-layout>` sets a layout context (size and/or density) for all
* descendant Carbon components.
*
* @see This component is in {@link https://web-components.carbondesignsystem.com/?path=/docs/preview-about-preview--about-preview|preview status}
*
* @element cds-custom-layout
*/
var CDSLayout = class extends LitElement {
	static {
		this.is = `cds-custom-layout`;
	}
	static {
		this.styles = layout_default;
	}
	render() {
		return html`<slot></slot>`;
	}
};
__decorate([property({ reflect: true })], CDSLayout.prototype, "size", void 0);
__decorate([property({ reflect: true })], CDSLayout.prototype, "density", void 0);
//#endregion
export { CDSLayout, CDSLayout as default, LAYOUT_DENSITIES, LAYOUT_SIZES };

//# sourceMappingURL=layout.js.map