/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSTextareaSkeleton from "../textarea/textarea-skeleton.js";
import fluid_textarea_default from "./fluid-textarea.scss.js";
import { html } from "lit";
//#region src/components/fluid-textarea/fluid-textarea-skeleton.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text area skeleton.
*
* @element cds-custom-fluid-textarea-skeleton
*/
var CDSFluidTextareaSkeleton = class extends CDSTextareaSkeleton {
	static {
		this.is = `cds-custom-fluid-textarea-skeleton`;
	}
	render() {
		return html`
      <div class="${"cds-custom"}--text-area--fluid__skeleton ${"cds-custom"}--form-item">
        ${super.render()}
      </div>
    `;
	}
	static {
		this.styles = [CDSTextareaSkeleton.styles, fluid_textarea_default];
	}
};
//#endregion
export { CDSFluidTextareaSkeleton as default };

//# sourceMappingURL=fluid-textarea-skeleton.js.map