/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSTextarea from "../textarea/textarea.js";
import fluid_textarea_default from "./fluid-textarea.scss.js";
import { html } from "lit";
//#region src/components/fluid-textarea/fluid-textarea.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text area input.
*
* @element cds-custom-fluid-textarea
*/
var CDSFluidTextArea = class extends CDSTextarea {
	static {
		this.is = `cds-custom-fluid-textarea`;
	}
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
	}
	render() {
		return html`
      <div class="${"cds-custom"}--text-area--fluid ${"cds-custom"}--form-item">
        ${super.render()}
      </div>
    `;
	}
	static {
		this.styles = [CDSTextarea.styles, fluid_textarea_default];
	}
};
//#endregion
export { CDSFluidTextArea as default };

//# sourceMappingURL=fluid-textarea.js.map