/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import "../textarea/index.js";
import CDSFluidTextArea from "./fluid-textarea.js";
import CDSFluidTextareaSkeleton from "./fluid-textarea-skeleton.js";
//#region src/components/fluid-textarea/index.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFluidTextArea);
defineCustomElement(CDSFluidTextareaSkeleton);
//#endregion
export { CDSFluidTextArea, CDSFluidTextareaSkeleton };

//# sourceMappingURL=index.js.map