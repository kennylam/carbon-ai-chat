/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import CDSTextarea from "./textarea.js";
import CDSTextareaSkeleton from "./textarea-skeleton.js";
//#region src/components/textarea/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSTextarea);
defineCustomElement(CDSTextareaSkeleton);
//#endregion
export { CDSTextarea, CDSTextareaSkeleton };

//# sourceMappingURL=index.js.map