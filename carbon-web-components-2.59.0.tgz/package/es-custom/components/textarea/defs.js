/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { FORM_ELEMENT_COLOR_SCHEME } from "../../globals/shared-enums.js";
export { FORM_ELEMENT_COLOR_SCHEME as TEXTAREA_COLOR_SCHEME };
