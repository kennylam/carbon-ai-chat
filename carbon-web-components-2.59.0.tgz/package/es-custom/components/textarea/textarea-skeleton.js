/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import textarea_default from "./textarea.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/textarea/textarea-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @element cds-custom-textarea-skeleton
*
* Skeleton of text area.
*/
var CDSTextareaSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hideLabel = false;
	}
	static {
		this.is = `cds-custom-textarea-skeleton`;
	}
	render() {
		const { hideLabel } = this;
		return html`
      ${hideLabel ? "" : html`<span class="${"cds-custom"}--label ${"cds-custom"}--skeleton"></span>`}
      <div class="${"cds-custom"}--skeleton ${"cds-custom"}--text-area"></div>
    `;
	}
	static {
		this.styles = textarea_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-label"
})], CDSTextareaSkeleton.prototype, "hideLabel", void 0);
//#endregion
export { CDSTextareaSkeleton as default };

//# sourceMappingURL=textarea-skeleton.js.map