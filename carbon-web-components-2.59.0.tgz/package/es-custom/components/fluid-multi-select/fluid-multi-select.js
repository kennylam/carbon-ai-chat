/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import CDSMultiSelect from "../multi-select/multi-select.js";
import fluid_multi_select_default from "./fluid-multi-select.scss.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/fluid-multi-select/fluid-multi-select.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid multi select.
*
* @element cds-custom-fluid-multi-select
*/
var CDSFluidMultiSelect = class extends CDSMultiSelect {
	constructor(..._args) {
		super(..._args);
		this.isCondensed = false;
	}
	static {
		this.is = `cds-custom-fluid-multi-select`;
	}
	connectedCallback() {
		super.connectedCallback();
		this.isFluid = true;
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		if (changedProperties.has("invalid") || changedProperties.has("disabled") || changedProperties.has("readonly") || changedProperties.has("warn")) this.requestUpdate();
	}
	render() {
		return html`<div class="${classMap({
			[`cds-custom--multi-select__wrapper`]: true,
			[`cds-custom--list-box__wrapper`]: true,
			[`cds-custom--list-box__wrapper--fluid`]: true,
			[`cds-custom--list-box__wrapper--fluid--invalid`]: this.invalid
		})}">${super.render()}</div>`;
	}
	static {
		this.styles = [CDSMultiSelect.styles, fluid_multi_select_default];
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-condensed"
})], CDSFluidMultiSelect.prototype, "isCondensed", void 0);
//#endregion
export { CDSFluidMultiSelect as default };

//# sourceMappingURL=fluid-multi-select.js.map