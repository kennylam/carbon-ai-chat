/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../toggle-tip/index.js";
import "../ai-label/index.js";
import "../dropdown/index.js";
import "../multi-select/index.js";
import CDSFluidMultiSelect from "./fluid-multi-select.js";
import CDSFluidMultiSelectSkeleton from "./fluid-multi-select-skeleton.js";
//#region src/components/fluid-multi-select/index.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFluidMultiSelect);
defineCustomElement(CDSFluidMultiSelectSkeleton);
//#endregion
export { CDSFluidMultiSelect, CDSFluidMultiSelectSkeleton };

//# sourceMappingURL=index.js.map