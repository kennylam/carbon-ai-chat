/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import fluid_multi_select_default from "./fluid-multi-select.scss.js";
import { LitElement, html } from "lit";
//#region src/components/fluid-multi-select/fluid-multi-select-skeleton.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid multi select skeleton.
*
* @element cds-custom-fluid-multi-select-skeleton
*/
var CDSFluidMultiSelectSkeleton = class extends LitElement {
	static {
		this.is = `cds-custom-fluid-multi-select-skeleton`;
	}
	render() {
		return html`
      <div class="${"cds-custom"}--list-box__wrapper--fluid">
        <div class="${"cds-custom"}--skeleton ${"cds-custom"}--list-box">
          <span class="${"cds-custom"}--list-box__label"></span>
          <div class="${"cds-custom"}--list-box__field"></div>
        </div>
      </div>
    `;
	}
	static {
		this.styles = fluid_multi_select_default;
	}
};
//#endregion
export { CDSFluidMultiSelectSkeleton as default };

//# sourceMappingURL=fluid-multi-select-skeleton.js.map