/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import { PROGRESS_BAR_SIZE, PROGRESS_BAR_STATUS, PROGRESS_BAR_TYPE } from "./defs.js";
import progress_bar_default from "./progress-bar.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import CheckmarkFilled16 from "@carbon/icons/es/checkmark--filled/16.js";
import ErrorFilled16 from "@carbon/icons/es/error--filled/16.js";
//#region src/components/progress-bar/progress-bar.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Progress bar.
*
* @element cds-custom-progress-bar
*/
var CDSProgressBar = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.max = 100;
		this.size = "big";
		this.status = "active";
		this.type = "default";
	}
	static {
		this.is = `cds-custom-progress-bar`;
	}
	get _cappedValue() {
		const { value, max, status } = this;
		let cappedValue = value;
		if (cappedValue > max) cappedValue = max;
		if (cappedValue < 0) cappedValue = 0;
		if (status === "error") cappedValue = 0;
		else if (status === "finished") cappedValue = max;
		return cappedValue;
	}
	updated(changedProperties) {
		if (changedProperties.has("value") || changedProperties.has("max") || changedProperties.has("status")) {
			const { _cappedValue: cappedValue, max, status } = this;
			const percentage = cappedValue / max;
			if (status != "error" && status != "finished") this._bar.style.transform = `scaleX(${percentage})`;
			else this._bar.style.transform = "none";
		}
	}
	render() {
		const { _cappedValue: cappedValue, helperText, hideLabel, label, max, size, status, type, value } = this;
		const isFinished = status === "finished";
		const isError = status === "error";
		const indeterminate = !isFinished && !isError && (value === null || value === void 0);
		let statusIcon = null;
		if (isError) statusIcon = iconLoader(ErrorFilled16, { class: `cds-custom--progress-bar__status-icon` });
		else if (isFinished) statusIcon = iconLoader(CheckmarkFilled16, { class: `cds-custom--progress-bar__status-icon` });
		return html` <div class="${classMap({
			[`cds-custom--progress-bar`]: true,
			[`cds-custom--progress-bar--${size}`]: true,
			[`cds-custom--progress-bar--${type}`]: true,
			[`cds-custom--progress-bar--indeterminate`]: indeterminate,
			[`cds-custom--progress-bar--finished`]: isFinished,
			[`cds-custom--progress-bar--error`]: isError
		})}">
      <div class="${classMap({
			[`cds-custom--progress-bar__label`]: true,
			[`cds-custom--visually-hidden`]: hideLabel
		})}">
        <span class="${"cds-custom"}--progress-bar__label-text">${label}</span>
        ${statusIcon}
      </div>
      <div
        class="${"cds-custom"}--progress-bar__track"
        role="progressbar"
        aria-busy="${!isFinished}"
        aria-invalid="${isError}"
        aria-valuemin="${!indeterminate ? 0 : null}"
        aria-valuemax="${!indeterminate ? max : null}"
        aria-valuenow="${!indeterminate ? cappedValue : null}">
        <div class="${"cds-custom"}--progress-bar__bar"></div>
      </div>
      ${helperText ? html`<div class="${"cds-custom"}--progress-bar__helper-text">
            ${helperText}
            <div class="${"cds-custom"}--visually-hidden" aria-live="polite">
              ${isFinished ? "Done" : "Loading"}
            </div>
          </div>` : null}
    </div>`;
	}
	static {
		this.styles = progress_bar_default;
	}
};
__decorate([query(`.cds-custom--progress-bar__bar`)], CDSProgressBar.prototype, "_bar", void 0);
__decorate([property({
	type: String,
	attribute: "helper-text",
	reflect: true
})], CDSProgressBar.prototype, "helperText", void 0);
__decorate([property({
	type: Boolean,
	attribute: "hide-label",
	reflect: true
})], CDSProgressBar.prototype, "hideLabel", void 0);
__decorate([property({ type: String })], CDSProgressBar.prototype, "label", void 0);
__decorate([property({
	type: Number,
	reflect: true
})], CDSProgressBar.prototype, "max", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSProgressBar.prototype, "size", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSProgressBar.prototype, "status", void 0);
__decorate([property({
	type: String,
	reflect: true
})], CDSProgressBar.prototype, "type", void 0);
__decorate([property({
	type: Number,
	reflect: true
})], CDSProgressBar.prototype, "value", void 0);
//#endregion
export { PROGRESS_BAR_SIZE, PROGRESS_BAR_STATUS, PROGRESS_BAR_TYPE, CDSProgressBar as default };

//# sourceMappingURL=progress-bar.js.map