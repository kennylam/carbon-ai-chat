/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/progress-bar/defs.ts
/**
* Copyright IBM Corp. 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Status of progress bar.
*/
let PROGRESS_BAR_STATUS = /* @__PURE__ */ function(PROGRESS_BAR_STATUS) {
	/**
	* Currently active.
	*/
	PROGRESS_BAR_STATUS["ACTIVE"] = "active";
	/**
	* Executed.
	*/
	PROGRESS_BAR_STATUS["FINISHED"] = "finished";
	/**
	* Invalid.
	*/
	PROGRESS_BAR_STATUS["ERROR"] = "error";
	return PROGRESS_BAR_STATUS;
}({});
/**
* Size of progress bar.
*/
let PROGRESS_BAR_SIZE = /* @__PURE__ */ function(PROGRESS_BAR_SIZE) {
	/**
	* small size (thinner)
	*/
	PROGRESS_BAR_SIZE["SMALL"] = "small";
	/**
	* big size
	*/
	PROGRESS_BAR_SIZE["BIG"] = "big";
	return PROGRESS_BAR_SIZE;
}({});
/**
* Defines the alignment variant of the progress bar.
*/
let PROGRESS_BAR_TYPE = /* @__PURE__ */ function(PROGRESS_BAR_TYPE) {
	/**
	* default type
	*/
	PROGRESS_BAR_TYPE["DEFAULT"] = "default";
	/**
	* Inline type
	*/
	PROGRESS_BAR_TYPE["INLINE"] = "inline";
	/**
	* indented type
	*/
	PROGRESS_BAR_TYPE["INDENTED"] = "indented";
	return PROGRESS_BAR_TYPE;
}({});
//#endregion
export { PROGRESS_BAR_SIZE, PROGRESS_BAR_STATUS, PROGRESS_BAR_TYPE };

//# sourceMappingURL=defs.js.map