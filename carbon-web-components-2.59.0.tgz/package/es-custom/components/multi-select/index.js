/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../toggle-tip/index.js";
import "../ai-label/index.js";
import "../dropdown/index.js";
import CDSMultiSelect from "./multi-select.js";
import CDSMultiSelectItem from "./multi-select-item.js";
//#region src/components/multi-select/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSMultiSelect);
defineCustomElement(CDSMultiSelectItem);
//#endregion
export { CDSMultiSelect, CDSMultiSelectItem };

//# sourceMappingURL=index.js.map