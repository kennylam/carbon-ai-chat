/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/multi-select/defs.ts
/**
* Copyright IBM Corp. 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Multi-select selection feedback options.
*/
let SELECTION_FEEDBACK_OPTION = /* @__PURE__ */ function(SELECTION_FEEDBACK_OPTION) {
	/**
	* selected item stays at it's position
	*/
	SELECTION_FEEDBACK_OPTION["FIXED"] = "fixed";
	/**
	* selected item jumps to top
	*/
	SELECTION_FEEDBACK_OPTION["TOP"] = "top";
	/**
	* selected item jump to top after reopen dropdown
	*/
	SELECTION_FEEDBACK_OPTION["TOP_AFTER_REOPEN"] = "top-after-reopen";
	return SELECTION_FEEDBACK_OPTION;
}({});
//#endregion
export { SELECTION_FEEDBACK_OPTION };

//# sourceMappingURL=defs.js.map