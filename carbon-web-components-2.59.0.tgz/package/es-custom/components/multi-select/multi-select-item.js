/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import "../checkbox/index.js";
import CDSDropdownItem from "../dropdown/dropdown-item.js";
import multi_select_default from "./multi-select.scss.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/multi-select/multi-select-item.ts
/**
* Copyright IBM Corp. 2019, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Multi select item.
*
* @element cds-custom-multi-select-item
*/
var CDSMultiSelectItem = class extends CDSDropdownItem {
	constructor(..._args) {
		super(..._args);
		this.isSelectAll = false;
		this.indeterminate = false;
		this.selectionName = "";
	}
	static {
		this.is = `cds-custom-multi-select-item`;
	}
	render() {
		const { disabled, selected, selectionName, value, indeterminate } = this;
		return html`
      <div class="${"cds-custom"}--list-box__menu-item__option">
        <cds-custom-checkbox
          tabindex="-1"
          class="${"cds-custom"}--form-item ${"cds-custom"}--checkbox-wrapper"
          .checked=${selected}
          .indeterminate=${indeterminate}
          ?disabled=${disabled}
          name=${ifDefined(selectionName || void 0)}
          value=${value}>
          <slot></slot>
        </cds-custom-checkbox>
      </div>
    `;
	}
	/**
	* A selector that will return multi select.
	*/
	static get selectorList() {
		return `cds-custom-multi-select`;
	}
	static {
		this.styles = multi_select_default;
	}
};
__decorate([property({ type: Boolean })], CDSMultiSelectItem.prototype, "filtered", void 0);
__decorate([property({
	type: Boolean,
	attribute: "is-select-all",
	reflect: true
})], CDSMultiSelectItem.prototype, "isSelectAll", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSMultiSelectItem.prototype, "indeterminate", void 0);
__decorate([property({ attribute: "selection-name" })], CDSMultiSelectItem.prototype, "selectionName", void 0);
//#endregion
export { CDSMultiSelectItem as default };

//# sourceMappingURL=multi-select-item.js.map