/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import { MenuContext } from "./menu-context.js";
import menu_item_default from "./menu-item.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { consume } from "@lit/context";
//#region src/components/menu/menu-item-radio-group.ts
/**
* Copyright IBM Corp. 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Menu Item.
*
* @element cds-custom-menu-item-radio-group
*/
var CDSmenuItemRadioGroup = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.items = [];
	}
	static {
		this.is = `cds-custom-menu-item-radio-group`;
	}
	/**
	* The name of the custom event fired when the selection state changes.
	*/
	static get eventOnChange() {
		return `cds-custom-item-changed`;
	}
	firstUpdated() {
		this.context.updateFromChild({ hasSelectableItems: true });
		this.addEventListener(`click`, (e) => {
			this.selectedItem = e.target;
			const init = {
				bubbles: true,
				cancelable: true,
				composed: true,
				detail: { triggeredBy: e.target }
			};
			if (this.dispatchEvent(new CustomEvent(this.constructor.eventOnChange, init))) this.dispatchEvent(new CustomEvent(this.constructor.eventOnChange, init));
		});
	}
	updated(_changedProperties) {
		if (_changedProperties.has("selectedItem")) this.querySelectorAll(`cds-custom-menu-item`).forEach((item) => {
			if (item === this.selectedItem) item.setAttribute("aria-checked", "true");
			else item.setAttribute("aria-checked", "false");
		});
	}
	render() {
		const { label } = this;
		return html`
      <ul role="group" aria-label="${label}">
        <slot></slot>
      </ul>
    `;
	}
	static {
		this.styles = menu_item_default;
	}
};
__decorate([consume({ context: MenuContext })], CDSmenuItemRadioGroup.prototype, "context", void 0);
__decorate([property({ type: String })], CDSmenuItemRadioGroup.prototype, "label", void 0);
__decorate([property({ type: Array })], CDSmenuItemRadioGroup.prototype, "items", void 0);
__decorate([property({
	type: String,
	attribute: true
})], CDSmenuItemRadioGroup.prototype, "selectedItem", void 0);
__decorate([property()], CDSmenuItemRadioGroup.prototype, "itemToString", void 0);
//#endregion
export { CDSmenuItemRadioGroup as default };

//# sourceMappingURL=menu-item-radio-group.js.map