/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/menu/defs.ts
/**
* Copyright IBM Corp. 2020, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Menu size.
*/
let MENU_SIZE = /* @__PURE__ */ function(MENU_SIZE) {
	/**
	* extra small size.
	*/
	MENU_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	MENU_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	MENU_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	MENU_SIZE["LARGE"] = "lg";
	return MENU_SIZE;
}({});
/**
* menu item kind
*/
let MENU_ITEM_KIND = /* @__PURE__ */ function(MENU_ITEM_KIND) {
	/**
	* default kind
	*/
	MENU_ITEM_KIND["DEFAULT"] = "default";
	/**
	* danger kind
	*/
	MENU_ITEM_KIND["DANGER"] = "danger";
	return MENU_ITEM_KIND;
}({});
/**
* Menu background token.
*/
let MENU_BACKGROUND_TOKEN = /* @__PURE__ */ function(MENU_BACKGROUND_TOKEN) {
	/**
	* Use the layer token for the background.
	*/
	MENU_BACKGROUND_TOKEN["LAYER"] = "layer";
	/**
	* Use the background token for the background.
	*/
	MENU_BACKGROUND_TOKEN["BACKGROUND"] = "background";
	return MENU_BACKGROUND_TOKEN;
}({});
//#endregion
export { MENU_BACKGROUND_TOKEN, MENU_ITEM_KIND, MENU_SIZE };

//# sourceMappingURL=defs.js.map