/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSmenuItem from "./menu-item.js";
import CDSMenu from "./menu.js";
import CDSmenuItemDivider from "./menu-item-divider.js";
import CDSmenuItemGroup from "./menu-item-group.js";
import CDSmenuItemSelectable from "./menu-item-selectable.js";
import CDSmenuItemRadioGroup from "./menu-item-radio-group.js";
//#region src/components/menu/index.ts
/**
* Copyright IBM Corp. 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSMenu);
defineCustomElement(CDSmenuItem);
defineCustomElement(CDSmenuItemDivider);
defineCustomElement(CDSmenuItemGroup);
defineCustomElement(CDSmenuItemSelectable);
defineCustomElement(CDSmenuItemRadioGroup);
//#endregion
export { CDSMenu, CDSmenuItem, CDSmenuItemDivider, CDSmenuItemGroup, CDSmenuItemRadioGroup, CDSmenuItemSelectable };

//# sourceMappingURL=index.js.map