/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import menu_item_default from "./menu-item.scss.js";
import { LitElement } from "lit";
//#region src/components/menu/menu-item-divider.ts
/**
* Copyright IBM Corp. 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Menu Item.
*
* @element cds-custom-menu-item-divider
*/
var CDSmenuItemDivider = class extends LitElement {
	static {
		this.is = `cds-custom-menu-item-divider`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "separator");
		super.connectedCallback();
	}
	static {
		this.styles = menu_item_default;
	}
};
//#endregion
export { CDSmenuItemDivider as default };

//# sourceMappingURL=menu-item-divider.js.map