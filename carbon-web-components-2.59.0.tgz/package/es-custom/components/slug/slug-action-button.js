/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import CDSButton from "../button/button.js";
import slug_default from "./slug.scss.js";
import { property } from "lit/decorators.js";
//#region src/components/slug/slug-action-button.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Slug action button.
*
* @deprecated This component has been deprecated, please use the <cds-custom-ai-label-action-button> component instead.
* @element cds-custom-slug-action-button
*/
var CDSSlugActionButton = class extends CDSButton {
	constructor(..._args) {
		super(..._args);
		this.slot = "actions";
	}
	static {
		this.is = `cds-custom-slug-action-button`;
	}
	static {
		this.styles = slug_default;
	}
};
__decorate([property({ reflect: true })], CDSSlugActionButton.prototype, "slot", void 0);
//#endregion
export { CDSSlugActionButton as default };

//# sourceMappingURL=slug-action-button.js.map