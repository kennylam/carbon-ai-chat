/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../toggle-tip/index.js";
import "../icon-button/index.js";
import CDSSlug from "./slug.js";
import CDSSlugActionButton from "./slug-action-button.js";
//#region src/components/slug/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSSlug);
defineCustomElement(CDSSlugActionButton);
//#endregion
export { CDSSlug, CDSSlugActionButton };

//# sourceMappingURL=index.js.map