/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import toggletip_default from "../toggle-tip/toggletip.scss.js";
import popover_default from "../popover/popover.scss.js";
import CDSToggletip from "../toggle-tip/toggletip.js";
import slug_default from "./slug.scss.js";
import "./defs.js";
import { adoptStyles, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import Undo16 from "@carbon/icons/es/undo/16.js";
//#region src/components/slug/slug.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Basic slug.
*
* @deprecated This component has been deprecated, please use the <cds-custom-ai-label> component instead.
* @element cds-custom-slug
*/
var CDSSlug = class extends CDSToggletip {
	constructor(..._args) {
		super(..._args);
		this.slot = "slug";
		this.aiText = "AI";
		this.aiTextLabel = "";
		this.kind = "";
		this.revertActive = false;
		this.revertLabel = "Revert to AI input";
		this.size = "xs";
		this.slugLabel = "Show information";
		this._handleClick = () => {
			if (this.revertActive) {
				this.revertActive = false;
				this.removeAttribute("revert-active");
			} else this.open = !this.open;
		};
		this._renderToggleTipLabel = () => {
			return html``;
		};
		this._renderTooltipButton = () => {
			const { size, kind, aiText, aiTextLabel, slugLabel } = this;
			const ariaLabel = `${aiText} - ${slugLabel}`;
			const classes = classMap({
				[`cds-custom--toggletip-button`]: true,
				[`cds-custom--slug__button`]: true,
				[`cds-custom--slug__button--${size}`]: size,
				[`cds-custom--slug__button--${kind}`]: kind,
				[`cds-custom--slug__button--inline-with-content`]: kind === "inline" && aiTextLabel
			});
			return html`
      <button
        aria-controls="${this.id}"
        @click="${this._handleClick}"
        class=${classes}
        aria-label="${ariaLabel}">
        <span class="${"cds-custom"}--slug__text">${aiText}</span>
        ${aiTextLabel && kind === "inline" ? html`
              <span class="${"cds-custom"}--slug__additional-text">
                ${aiTextLabel}
              </span>
            ` : ``}
      </button>
    `;
		};
		this._renderInnerContent = () => {
			const { autoalign, revertActive, revertLabel } = this;
			return html`
      ${revertActive ? html`
            <cds-custom-icon-button
              ?autoalign=${autoalign}
              kind="ghost"
              size="sm"
              @click="${this._handleClick}">
              <span slot="tooltip-content"> ${revertLabel} </span>
              ${iconLoader(Undo16, { slot: "icon" })}
            </cds-custom-icon-button>
          ` : html`
            ${this._renderTooltipButton()} ${this._renderTooltipContent()}
          `}
    `;
		};
	}
	static {
		this.is = `cds-custom-slug`;
	}
	connectedCallback() {
		super.connectedCallback();
		adoptStyles(this.renderRoot, [
			popover_default,
			toggletip_default,
			slug_default
		]);
	}
	attributeChangedCallback(name, old, newValue) {
		super.attributeChangedCallback(name, old, newValue);
		if (name === "revert-active") this.parentElement?.requestUpdate();
	}
};
__decorate([property({ reflect: true })], CDSSlug.prototype, "slot", void 0);
__decorate([property({ attribute: "ai-text" })], CDSSlug.prototype, "aiText", void 0);
__decorate([property({ attribute: "ai-text-label" })], CDSSlug.prototype, "aiTextLabel", void 0);
__decorate([property({ reflect: true })], CDSSlug.prototype, "kind", void 0);
__decorate([property({
	type: Boolean,
	attribute: "revert-active"
})], CDSSlug.prototype, "revertActive", void 0);
__decorate([property({ attribute: "revert-label" })], CDSSlug.prototype, "revertLabel", void 0);
__decorate([property({ reflect: true })], CDSSlug.prototype, "size", void 0);
__decorate([property({ attribute: "slug-label" })], CDSSlug.prototype, "slugLabel", void 0);
__decorate([property()], CDSSlug.prototype, "previousValue", void 0);
//#endregion
export { CDSSlug as default };

//# sourceMappingURL=slug.js.map