/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/slug/defs.ts
/**
* Copyright IBM Corp. 2020, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Slug size.
*/
let SLUG_SIZE = /* @__PURE__ */ function(SLUG_SIZE) {
	/**
	* Mini size.
	*/
	SLUG_SIZE["MINI"] = "mini";
	/**
	* Extra extra small size.
	*/
	SLUG_SIZE["EXTRA_EXTRA_SMALL"] = "2xs";
	/**
	* Extra small size.
	*/
	SLUG_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	SLUG_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	SLUG_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	SLUG_SIZE["LARGE"] = "lg";
	/**
	* Extra large size.
	*/
	SLUG_SIZE["EXTRA_LARGE"] = "xl";
	return SLUG_SIZE;
}({});
/**
* Slug kind.
*/
let SLUG_KIND = /* @__PURE__ */ function(SLUG_KIND) {
	/**
	* Default kind.
	*/
	SLUG_KIND["DEFAULT"] = "";
	/**
	* Inline kind.
	*/
	SLUG_KIND["INLINE"] = "inline";
	return SLUG_KIND;
}({});
//#endregion
export { SLUG_KIND, SLUG_SIZE };

//# sourceMappingURL=defs.js.map