/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSListItem from "./list-item.js";
import CDSUnorderedList from "./unordered-list.js";
import CDSOrderedList from "./ordered-list.js";
//#region src/components/list/index.ts
/**
* Copyright IBM Corp. 2021, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSListItem);
defineCustomElement(CDSOrderedList);
defineCustomElement(CDSUnorderedList);
//#endregion
export { CDSListItem, CDSOrderedList, CDSUnorderedList };

//# sourceMappingURL=index.js.map