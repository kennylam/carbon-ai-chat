/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import CDSUnorderedList from "./unordered-list.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/list/ordered-list.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Ordered list.
*
* @element cds-custom-ordered-list
*/
var CDSOrderedList = class extends CDSUnorderedList {
	constructor(..._args) {
		super(..._args);
		this.native = false;
	}
	static {
		this.is = `cds-custom-ordered-list`;
	}
	render() {
		return html`
      <ol class="${classMap({
			[`cds-custom--list--ordered`]: !this.native,
			[`cds-custom--list--ordered--native`]: this.native,
			[`cds-custom--list--nested`]: this.getAttribute("slot") === "nested" || this.nested,
			[`cds-custom--list--expressive`]: this.isExpressive
		})}">
        <slot></slot>
      </ol>
    `;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOrderedList.prototype, "native", void 0);
//#endregion
export { CDSOrderedList as default };

//# sourceMappingURL=ordered-list.js.map