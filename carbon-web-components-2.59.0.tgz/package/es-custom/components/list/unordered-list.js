/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import list_default from "./list.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/list/unordered-list.ts
/**
* Copyright IBM Corp. 2019, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Unordered list.
*
* @element cds-custom-unordered-list
*/
var CDSUnorderedList = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.isExpressive = false;
		this.nested = false;
	}
	static {
		this.is = `cds-custom-unordered-list`;
	}
	connectedCallback() {
		if (this.closest(this.constructor.selectorListItem) || this.nested) this.setAttribute("slot", "nested");
		else this.removeAttribute("slot");
		super.connectedCallback();
	}
	render() {
		return html`
      <ul class="${classMap({
			[`cds-custom--list--unordered`]: true,
			[`cds-custom--list--nested`]: this.getAttribute("slot") === "nested" || this.nested,
			[`cds-custom--list--expressive`]: this.isExpressive
		})}">
        <slot></slot>
      </ul>
    `;
	}
	/**
	* A selector that will return list item.
	*/
	static get selectorListItem() {
		return `cds-custom-list-item`;
	}
	static {
		this.styles = list_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-expressive"
})], CDSUnorderedList.prototype, "isExpressive", void 0);
__decorate([property({ type: Boolean })], CDSUnorderedList.prototype, "nested", void 0);
//#endregion
export { CDSUnorderedList as default };

//# sourceMappingURL=unordered-list.js.map