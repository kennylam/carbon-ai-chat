/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import list_default from "./list.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/list/list-item.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* List item.
*
* @element cds-custom-list-item
* @slot nested - The nested child list.
*/
var CDSListItem = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.nested = false;
	}
	static {
		this.is = `cds-custom-list-item`;
	}
	connectedCallback() {
		this.toggleAttribute("nested", Boolean(this.closest(this.constructor.selectorNestedList)));
		if (!this.hasAttribute("role")) this.setAttribute("role", "listitem");
		super.connectedCallback();
	}
	render() {
		return html`
      <slot></slot>
      <slot name="nested"></slot>
    `;
	}
	/**
	* A selector that will return nested list.
	*/
	static get selectorNestedList() {
		return `cds-custom-ordered-list[slot="nested"],cds-custom-unordered-list[slot="nested"]`;
	}
	static {
		this.styles = list_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSListItem.prototype, "nested", void 0);
//#endregion
export { CDSListItem as default };

//# sourceMappingURL=list-item.js.map