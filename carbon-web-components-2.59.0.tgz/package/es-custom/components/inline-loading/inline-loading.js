/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import loading_icon_default from "../loading/loading-icon.js";
import { INLINE_LOADING_STATE } from "./defs.js";
import inline_loading_default from "./inline-loading.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import CheckmarkFilled16 from "@carbon/icons/es/checkmark--filled/16.js";
import ErrorFilled16 from "@carbon/icons/es/error--filled/16.js";
//#region src/components/inline-loading/inline-loading.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Lnline loading spinner.
*
* @element cds-custom-inline-loading
* @fires cds-custom-inline-loading-onsuccess The custom event fired when inline-loading has finished status
*/
var CDSInlineLoading = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.iconDescription = "Loading";
		this.successDelay = 1500;
		this.status = "active";
	}
	static {
		this.is = `cds-custom-inline-loading`;
	}
	/**
	* @deprecated The 'assistive-text' property will be deprecated in the next major release. Please use `icon-description` instead.
	*/
	get assistiveText() {
		return this.iconDescription;
	}
	set assistiveText(value) {
		this.iconDescription = value;
	}
	/**
	* @returns The template for the status icon.
	*/
	_renderIcon() {
		const { iconDescription, status } = this;
		if (status === "error") return iconLoader(ErrorFilled16, {
			class: `cds-custom--inline-loading--error`,
			"aria-label": iconDescription
		});
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true
		};
		if (status === "finished") {
			setTimeout(() => {
				this.dispatchEvent(new CustomEvent(this.constructor.eventOnSuccess, init));
			}, this.successDelay);
			return iconLoader(CheckmarkFilled16, {
				class: `cds-custom--inline-loading__checkmark-container`,
				"aria-label": iconDescription
			});
		}
		if (status === "inactive" || status === "active") return html`
        <div class="${classMap({
			[`cds-custom--loading`]: true,
			[`cds-custom--loading--small`]: true,
			[`cds-custom--loading--stop`]: status === "inactive"
		})}">
          ${loading_icon_default({
			description: iconDescription,
			small: true
		})}
        </div>
      `;
	}
	static get eventOnSuccess() {
		return `cds-custom-inline-loading-onsuccess`;
	}
	connectedCallback() {
		if (!this.hasAttribute("aria-live")) this.setAttribute("aria-live", "assertive");
		super.connectedCallback();
	}
	render() {
		const statusIconResult = this._renderIcon();
		return html`
      ${!statusIconResult ? void 0 : html`
          <div class="${"cds-custom"}--inline-loading__animation">
            ${statusIconResult}
          </div>
        `}
      <div class="${"cds-custom"}--inline-loading__text"><slot></slot></div>
    `;
	}
	static {
		this.styles = inline_loading_default;
	}
};
__decorate([property({ attribute: "assistive-text" })], CDSInlineLoading.prototype, "assistiveText", null);
__decorate([property({ attribute: "icon-description" })], CDSInlineLoading.prototype, "iconDescription", void 0);
__decorate([property({ attribute: "success-delay" })], CDSInlineLoading.prototype, "successDelay", void 0);
__decorate([property({ reflect: true })], CDSInlineLoading.prototype, "status", void 0);
//#endregion
export { INLINE_LOADING_STATE, CDSInlineLoading as default };

//# sourceMappingURL=inline-loading.js.map