/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSTimePicker from "./time-picker.js";
import CDSTimePickerSelect from "./time-picker-select.js";
//#region src/components/time-picker/index.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSTimePicker);
defineCustomElement(CDSTimePickerSelect);
//#endregion
export { CDSTimePicker, CDSTimePickerSelect };

//# sourceMappingURL=index.js.map