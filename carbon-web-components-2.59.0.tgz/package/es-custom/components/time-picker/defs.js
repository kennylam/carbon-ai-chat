/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { FORM_ELEMENT_COLOR_SCHEME } from "../../globals/shared-enums.js";
//#region src/components/time-picker/defs.ts
/**
* Time picker size.
*/
let TIME_PICKER_SIZE = /* @__PURE__ */ function(TIME_PICKER_SIZE) {
	/**
	* Small size.
	*/
	TIME_PICKER_SIZE["SMALL"] = "sm";
	/**
	* Regular size.
	*/
	TIME_PICKER_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	TIME_PICKER_SIZE["LARGE"] = "lg";
	return TIME_PICKER_SIZE;
}({});
//#endregion
export { FORM_ELEMENT_COLOR_SCHEME as TIME_PICKER_COLOR_SCHEME, TIME_PICKER_SIZE };

//# sourceMappingURL=defs.js.map