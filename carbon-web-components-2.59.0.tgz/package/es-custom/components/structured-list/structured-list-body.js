/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import structured_list_default from "./structured-list.scss.js";
import { LitElement, html } from "lit";
//#region src/components/structured-list/structured-list-body.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Structured list body.
*
* @element cds-custom-structured-list-body
*/
var CDSStructuredListBody = class extends LitElement {
	static {
		this.is = `cds-custom-structured-list-body`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "rowgroup");
		super.connectedCallback();
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = structured_list_default;
	}
};
//#endregion
export { CDSStructuredListBody as default };

//# sourceMappingURL=structured-list-body.js.map