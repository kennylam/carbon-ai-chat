/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import structured_list_default from "./structured-list.scss.js";
import { LitElement, html } from "lit";
//#region src/components/structured-list/structured-list-cell.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Structured list cell.
*
* @element cds-custom-structured-list-cell
*/
var CDSStructuredListCell = class extends LitElement {
	static {
		this.is = `cds-custom-structured-list-cell`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "cell");
		super.connectedCallback();
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = structured_list_default;
	}
};
//#endregion
export { CDSStructuredListCell as default };

//# sourceMappingURL=structured-list-cell.js.map