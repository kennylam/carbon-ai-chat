/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import RadioGroupManager from "../../globals/internal/radio-group-manager.js";
import structured_list_default from "./structured-list.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import { ifDefined } from "lit/directives/if-defined.js";
import CheckmarkFilled16 from "@carbon/icons/es/checkmark--filled/16.js";
//#region src/components/structured-list/structured-list-row.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Map of navigation direction by key.
*/
const navigationDirectionForKey = {
	ArrowUp: -1,
	Up: -1,
	ArrowDown: 1,
	Down: 1
};
/**
* The interface for `RadioGroupManager` for structured list row.
*/
var StructuredListRowRadioButtonDelegate = class {
	constructor(row) {
		this._row = row;
	}
	get checked() {
		return this._row.selected;
	}
	set checked(checked) {
		this._row.selected = checked;
		this._row.tabIndex = checked ? 0 : -1;
	}
	get tabIndex() {
		return this._row.tabIndex;
	}
	set tabIndex(tabIndex) {
		this._row.tabIndex = tabIndex;
	}
	get name() {
		return this._row.selectionName;
	}
	compareDocumentPosition(other) {
		return this._row.compareDocumentPosition(other._row);
	}
	focus() {
		this._row.focus();
	}
};
/**
* Structured list row.
*
* @element cds-custom-structured-list-row
*/
var CDSStructuredListRow = class extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this._manager = null;
		this._radioButtonDelegate = new StructuredListRowRadioButtonDelegate(this);
		this._handleClick = () => {
			const { _inputNode: inputNode } = this;
			if (inputNode) {
				this.selected = true;
				if (this._manager) this._manager.select(this._radioButtonDelegate);
			}
		};
		this._handleKeydown = (event) => {
			const { _inputNode: inputNode } = this;
			const manager = this._manager;
			if (inputNode && manager) {
				const navigationDirection = navigationDirectionForKey[event.key];
				if (navigationDirection) manager.select(manager.navigate(this._radioButtonDelegate, navigationDirection));
				if (event.key === " " || event.key === "Enter") manager.select(this._radioButtonDelegate);
			}
		};
		this.selected = false;
		this.selectionName = "";
		this.selectionValue = "";
		this.selectionIconTitle = "";
	}
	static {
		this.is = `cds-custom-structured-list-row`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "row");
		super.connectedCallback();
		if (!this._manager) {
			this._manager = RadioGroupManager.get(this.getRootNode({ composed: true }));
			const { selectionName } = this;
			if (selectionName) this._manager?.add(this._radioButtonDelegate);
		}
	}
	disconnectedCallback() {
		if (this._manager) this._manager.delete(this._radioButtonDelegate);
		super.disconnectedCallback();
	}
	updated(changedProperties) {
		const { _manager: manager, selectionName } = this;
		if (changedProperties.has("selectionName")) {
			if (manager) {
				manager.delete(this._radioButtonDelegate, changedProperties.get("selectionName"));
				if (selectionName) manager.add(this._radioButtonDelegate);
			}
			this.setAttribute("tabindex", !selectionName || !manager || !manager.shouldBeFocusable(this._radioButtonDelegate) ? "-1" : "0");
		}
	}
	render() {
		const { selected, selectionName, selectionValue, selectionIconTitle } = this;
		if (selectionName) return html`
        <slot></slot>
        <input
          id="input"
          type="radio"
          class="${"cds-custom"}--structured-list-input ${"cds-custom"}--visually-hidden"
          .checked=${selected}
          name=${selectionName}
          value=${ifDefined(selectionValue)} />
        <div
          class="${"cds-custom"}--structured-list-td ${"cds-custom"}--structured-list-cell">
          ${iconLoader(CheckmarkFilled16, {
			class: `cds-custom--structured-list-svg`,
			title: selectionIconTitle
		})}
        </div>
      `;
		return html` <slot></slot> `;
	}
	static {
		this.styles = structured_list_default;
	}
};
__decorate([query("#input")], CDSStructuredListRow.prototype, "_inputNode", void 0);
__decorate([HostListener("click")], CDSStructuredListRow.prototype, "_handleClick", void 0);
__decorate([HostListener("keydown")], CDSStructuredListRow.prototype, "_handleKeydown", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSStructuredListRow.prototype, "selected", void 0);
__decorate([property({ attribute: "selection-name" })], CDSStructuredListRow.prototype, "selectionName", void 0);
__decorate([property({ attribute: "selection-value" })], CDSStructuredListRow.prototype, "selectionValue", void 0);
__decorate([property({ attribute: "selection-icon-title" })], CDSStructuredListRow.prototype, "selectionIconTitle", void 0);
//#endregion
export { CDSStructuredListRow as default };

//# sourceMappingURL=structured-list-row.js.map