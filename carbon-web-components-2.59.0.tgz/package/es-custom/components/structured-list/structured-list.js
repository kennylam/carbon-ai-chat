/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { forEach } from "../../globals/internal/collection-helpers.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import structured_list_default from "./structured-list.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/structured-list/structured-list.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Structured list wrapper.
*
* @element cds-custom-structured-list
*/
var CDSStructuredList = class extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.selectionName = "";
		this.condensed = false;
		this.flush = false;
	}
	static {
		this.is = `cds-custom-structured-list`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "table");
		super.connectedCallback();
	}
	shouldUpdate(changedProperties) {
		if (changedProperties.has("selectionName")) forEach(this.querySelectorAll(this.constructor.selectorRowsWithHeader), (elem) => {
			elem.selectionName = this.selectionName;
		});
		return true;
	}
	updated(changedProperties) {
		["condensed", "flush"].forEach((attr) => {
			if (changedProperties.has(attr)) forEach(this.querySelectorAll(this.constructor.selectorRowsWithHeader), (elem) => {
				if (this[`${attr}`]) elem.setAttribute(attr, "");
				else elem.removeAttribute(attr);
			});
		});
	}
	render() {
		const { condensed, flush, selectionName } = this;
		return html`
      <section id="section" class=${classMap({
			[`cds-custom--structured-list`]: true,
			[`cds-custom--structured-list--selection`]: Boolean(selectionName),
			[`cds-custom--structured-list--condensed`]: condensed,
			[`cds-custom--structured-list--flush`]: flush
		})}><slot></slot></section>
    `;
	}
	static {
		this.selectorRowsWithHeader = `cds-custom-structured-list-row,cds-custom-structured-list-header-row`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = structured_list_default;
	}
};
__decorate([property({ attribute: "selection-name" })], CDSStructuredList.prototype, "selectionName", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSStructuredList.prototype, "condensed", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSStructuredList.prototype, "flush", void 0);
//#endregion
export { CDSStructuredList as default };

//# sourceMappingURL=structured-list.js.map