/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSStructuredList from "./structured-list.js";
import CDSStructuredListBody from "./structured-list-body.js";
import CDSStructuredListCell from "./structured-list-cell.js";
import CDSStructuredListHeader from "./structured-list-head.js";
import CDSStructuredListHeaderCell from "./structured-list-header-cell.js";
import CDSStructuredListHeaderCellSkeleton from "./structured-list-header-cell-skeleton.js";
import CDSStructuredListHeaderRow from "./structured-list-header-row.js";
import CDSStructuredListRow from "./structured-list-row.js";
//#region src/components/structured-list/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSStructuredList);
defineCustomElement(CDSStructuredListBody);
defineCustomElement(CDSStructuredListCell);
defineCustomElement(CDSStructuredListHeader);
defineCustomElement(CDSStructuredListHeaderCell);
defineCustomElement(CDSStructuredListHeaderCellSkeleton);
defineCustomElement(CDSStructuredListHeaderRow);
defineCustomElement(CDSStructuredListRow);
//#endregion
export { CDSStructuredList, CDSStructuredListBody, CDSStructuredListCell, CDSStructuredListHeader, CDSStructuredListHeaderCell, CDSStructuredListHeaderCellSkeleton, CDSStructuredListHeaderRow, CDSStructuredListRow };

//# sourceMappingURL=index.js.map