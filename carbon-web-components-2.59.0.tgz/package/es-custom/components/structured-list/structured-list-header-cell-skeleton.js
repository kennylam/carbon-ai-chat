/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import structured_list_default from "./structured-list.scss.js";
import { LitElement, html } from "lit";
//#region src/components/structured-list/structured-list-header-cell-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of structured list header cell.
*/
var CDSStructuredListHeaderCellSkeleton = class extends LitElement {
	static {
		this.is = `cds-custom-structured-list-header-cell-skeleton`;
	}
	render() {
		return html` <span></span> `;
	}
	static {
		this.styles = structured_list_default;
	}
};
//#endregion
export { CDSStructuredListHeaderCellSkeleton as default };

//# sourceMappingURL=structured-list-header-cell-skeleton.js.map