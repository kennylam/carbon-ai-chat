/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import structured_list_default from "./structured-list.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/structured-list/structured-list-header-row.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Structured list header row.
*
* @element cds-custom-structured-list-header-row
*/
var CDSStructuredListHeaderRow = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.selectionName = "";
	}
	static {
		this.is = `cds-custom-structured-list-header-row`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "row");
		super.connectedCallback();
	}
	render() {
		if (this.selectionName) return html`
        <slot></slot>
        <div class="${"cds-custom"}--structured-list-th"></div>
      `;
		return html` <slot></slot> `;
	}
	static {
		this.styles = structured_list_default;
	}
};
__decorate([property({ attribute: "selection-name" })], CDSStructuredListHeaderRow.prototype, "selectionName", void 0);
//#endregion
export { CDSStructuredListHeaderRow as default };

//# sourceMappingURL=structured-list-header-row.js.map