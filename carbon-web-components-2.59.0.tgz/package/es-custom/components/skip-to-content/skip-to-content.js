/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import skip_to_content_default from "./skip-to-content.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/skip-to-content/skip-to-content.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skip-to-content link.
*
* @element cds-custom-skip-to-content
*/
var CDSSkipToContent = class extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.linkAssisstiveText = "Skip to main content";
	}
	static {
		this.is = `cds-custom-skip-to-content`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "navigation");
		super.connectedCallback();
	}
	render() {
		const { linkAssisstiveText } = this;
		return html`
      <a class="${"cds-custom"}--skip-to-content" href="${ifDefined(this.href)}"
        ><slot>${linkAssisstiveText}</slot></a
      >
    `;
	}
	updated(changedProperties) {
		if (changedProperties.has("linkAssisstiveText")) {
			const { linkAssisstiveText } = this;
			this.setAttribute("aria-label", linkAssisstiveText);
		}
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = skip_to_content_default;
	}
};
__decorate([property({ attribute: "link-assistive-text" })], CDSSkipToContent.prototype, "linkAssisstiveText", void 0);
__decorate([property()], CDSSkipToContent.prototype, "href", void 0);
//#endregion
export { CDSSkipToContent as default };

//# sourceMappingURL=skip-to-content.js.map