/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../icon-button/index.js";
import CDSOverflowMenu from "./overflow-menu.js";
import CDSOverflowMenuBody from "./overflow-menu-body.js";
import CDSOverflowMenuItem from "./overflow-menu-item.js";
//#region src/components/overflow-menu/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSOverflowMenu);
defineCustomElement(CDSOverflowMenuBody);
defineCustomElement(CDSOverflowMenuItem);
//#endregion
export { CDSOverflowMenu, CDSOverflowMenuBody, CDSOverflowMenuItem };

//# sourceMappingURL=index.js.map