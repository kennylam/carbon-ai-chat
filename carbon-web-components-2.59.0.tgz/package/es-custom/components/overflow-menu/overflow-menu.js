/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { find } from "../../globals/internal/collection-helpers.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import FloatingController from "../../globals/controllers/floating-controller.js";
import icon_button_default from "../icon-button/icon-button.scss.js";
import CDSIconButton from "../icon-button/icon-button.js";
import { OVERFLOW_MENU_SIZE } from "./defs.js";
import "../menu/defs.js";
import CDSMenu from "../menu/menu.js";
import "../menu/index.js";
import { isFeatureFlagEnabled } from "../feature-flags/index.js";
import overflow_menu_default from "./overflow-menu.scss.js";
import { adoptStyles, html } from "lit";
import { property, query } from "lit/decorators.js";
//#region src/components/overflow-menu/overflow-menu.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const menuItemTagPrefix = `cds-custom-menu-item`.toUpperCase();
const deprecatedOverflowMenuTagNames = new Set([`cds-custom-overflow-menu-body`.toUpperCase(), `cds-custom-overflow-menu-item`.toUpperCase()]);
const bottomFirstFallbackPlacements = [
	"bottom-start",
	"bottom-end",
	"top-start",
	"top-end"
];
const topFirstFallbackPlacements = [
	"top-start",
	"top-end",
	"bottom-start",
	"bottom-end"
];
const warnInDev = (message) => {
	globalThis.console?.warn(message);
};
/**
* Overflow menu.
*
* @element cds-custom-overflow-menu
* @slot icon - The icon for the trigger button.
*/
var CDSOverflowMenu = class extends HostListenerMixin(FocusMixin(CDSIconButton)) {
	constructor(..._args) {
		super(..._args);
		this._menuController = new FloatingController(this);
		this._menuBody = null;
		this._menuId = `cds-custom-overflow-menu-${Math.random().toString(16).slice(2)}`;
		this._didWarnDeprecatedChildren = false;
		this._didWarnInvalidComposition = false;
		this._menuSyncToken = 0;
		this._handleClickTrigger = async (event) => {
			if (this._isTriggerEvent(event)) {
				this._handleUserInitiatedToggle();
				return;
			}
			if (!this._isMenuCompositionEnabled() && this._isDeprecatedOverflowMenuItemEvent(event)) this.open = false;
		};
		this._handleKeydownTrigger = async (event) => {
			if (!this._isTriggerEvent(event)) return;
			if (event.key === " " || event.key === "Enter") {
				this._handleUserInitiatedToggle();
				event.preventDefault();
			}
		};
		this._handleMousedownTrigger = (event) => {
			if (this._isMenuCompositionEnabled() && this._isTriggerEvent(event)) event.preventDefault();
		};
		this._handleManagedMenuClose = (event) => {
			const menu = this._getMenuChild();
			if (!this._isMenuCompositionEnabled() || !menu || event.composedPath()[0] !== menu) return;
			this.open = false;
			if (event.detail?.triggerEventType !== "focusout") requestAnimationFrame(() => {
				this._getTriggerButton()?.focus();
			});
		};
		this.dataTable = false;
		this.disabled = false;
		this.enableV12Overflowmenu = false;
		this.flipped = false;
		this.autoalign = false;
		this.open = false;
		this.index = 1;
		this.label = "";
		this.menuAlignment = "bottom-start";
		this.size = void 0;
		this.toolbarAction = false;
		this.breadcrumb = false;
		this._handleTriggerBlur = () => {
			this._clearProgrammaticFocus();
		};
		this._handleDocumentInteraction = (event) => {
			const triggerButton = this._getTriggerButton();
			if (!triggerButton || !event.composedPath().includes(triggerButton)) this._clearProgrammaticFocus();
		};
	}
	static {
		this.is = `cds-custom-overflow-menu`;
	}
	/**
	* Handles user-initiated toggling of the menu.
	*/
	async _handleUserInitiatedToggle() {
		if (this.disabled) return;
		this.open = !this.open;
		const { index, open, updateComplete } = this;
		if (open) {
			await updateComplete;
			if (this._isMenuCompositionEnabled()) {
				await this._focusManagedMenuItem(index);
				return;
			}
			const { _menuBody: menuBody } = this;
			(menuBody?.querySelector(`cds-custom-overflow-menu-item:nth-of-type(${index})`))?.focus();
		}
	}
	/**
	* @returns The position of the trigger button in the viewport.
	*/
	get triggerPosition() {
		return this.getBoundingClientRect();
	}
	/**
	* Delegates host focus to the trigger and preserves visible focus when needed.
	*/
	focus(options) {
		const triggerButton = this._getTriggerButton();
		if (!triggerButton) {
			HTMLElement.prototype.focus.call(this, options);
			return;
		}
		HTMLElement.prototype.focus.call(this, options);
		if (this.shadowRoot?.activeElement !== triggerButton) triggerButton.focus(options);
		if (this.shadowRoot?.activeElement !== triggerButton) return;
		if (triggerButton.matches(":focus")) return;
		triggerButton.dispatchEvent(new FocusEvent("focus"));
		this.toggleAttribute("data-programmatic-focus", true);
		triggerButton.addEventListener("blur", this._handleTriggerBlur, { once: true });
		this.ownerDocument.addEventListener("pointerdown", this._handleDocumentInteraction, true);
		this.ownerDocument.addEventListener("focusin", this._handleDocumentInteraction, true);
	}
	_clearProgrammaticFocus() {
		const triggerButton = this._getTriggerButton();
		const hadProgrammaticFocus = this.hasAttribute("data-programmatic-focus");
		this.toggleAttribute("data-programmatic-focus", false);
		triggerButton?.removeEventListener("blur", this._handleTriggerBlur);
		this.ownerDocument.removeEventListener("pointerdown", this._handleDocumentInteraction, true);
		this.ownerDocument.removeEventListener("focusin", this._handleDocumentInteraction, true);
		if (hadProgrammaticFocus) triggerButton?.dispatchEvent(new FocusEvent("focusout"));
	}
	connectedCallback() {
		if (!this.hasAttribute("aria-haspopup")) this.setAttribute("aria-haspopup", "true");
		if (!this.shadowRoot) this.attachShadow({ mode: "open" });
		super.connectedCallback();
		adoptStyles(this.renderRoot, [icon_button_default, overflow_menu_default]);
		this.addEventListener(CDSMenu.eventOnClose, this._handleManagedMenuClose);
		this.addEventListener("click", this._handleClickTrigger);
		this.addEventListener("keydown", this._handleKeydownTrigger);
		this.addEventListener("mousedown", this._handleMousedownTrigger);
	}
	disconnectedCallback() {
		this.removeEventListener(CDSMenu.eventOnClose, this._handleManagedMenuClose);
		this.removeEventListener("click", this._handleClickTrigger);
		this.removeEventListener("keydown", this._handleKeydownTrigger);
		this.removeEventListener("mousedown", this._handleMousedownTrigger);
		this._clearProgrammaticFocus();
		super.disconnectedCallback();
	}
	_renderTooltipContent() {
		const tooltipLabel = this._getLabelText();
		if (this.label || !this.querySelector("[slot=tooltip-content]")) return html`
        <cds-custom-tooltip-content ?hidden=${this.disabled || this.open}>
          ${tooltipLabel}
        </cds-custom-tooltip-content>
      `;
		return super._renderTooltipContent();
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		const menuCompositionEnabled = this._isMenuCompositionEnabled();
		const button = this._tooltip?.querySelector("button");
		button?.classList.add(`cds-custom--btn--icon-only`, `cds-custom--overflow-menu`);
		if (changedProperties.has("open")) {
			if (!menuCompositionEnabled) {
				this._menuController.hostDisconnected();
				this._resetMenuChildFloatingStyles();
				const { open } = this;
				if (open && !this._menuBody) this._menuBody = find(this.childNodes, (elem) => elem.constructor.FLOATING_MENU);
				const { _menuBody: menuBody, size } = this;
				if (menuBody) {
					menuBody.id ||= this._menuId;
					menuBody.setAttribute("breadcrumb", String(this.breadcrumb));
					menuBody.open = open;
					menuBody.size = size;
				}
			}
		}
		if (changedProperties.has("enableV12Overflowmenu") && !menuCompositionEnabled) {
			this._menuController.hostDisconnected();
			this._resetMenuChildFloatingStyles({ closeMenu: true });
		}
		if (changedProperties.has("dataTable")) this._tooltip?.toggleAttribute("data-table", this.dataTable);
		if (changedProperties.has("size")) {
			button?.classList.forEach((item) => {
				if (item.startsWith(`cds-custom--overflow-menu--`)) button?.classList.remove(item);
			});
			this.classList.forEach((item) => {
				if (item.startsWith(`cds-custom--layout--size-`)) this.classList.remove(item);
			});
			if (this.size) {
				button?.classList.add(`cds-custom--overflow-menu--${this.size}`);
				this.classList.add(`cds-custom--layout--size-${this.size}`);
			}
			if (this.size) this._tooltip?.setAttribute("size", this.size);
			else this._tooltip?.removeAttribute("size");
			if (this._menuBody) this._menuBody.size = this.size;
		}
		if (changedProperties.has("toolbarAction") && this.toolbarAction) this._tooltip?.setAttribute("toolbar-action", "");
		const labelText = this._getLabelText();
		const popupId = menuCompositionEnabled ? this._getMenuChild()?.id ?? this._menuId : this._menuBody?.id;
		button?.setAttribute("aria-haspopup", "menu");
		button?.setAttribute("aria-expanded", String(this.open));
		button?.setAttribute("aria-label", labelText);
		if (this.open && popupId) button?.setAttribute("aria-controls", popupId);
		else button?.removeAttribute("aria-controls");
		if (menuCompositionEnabled && (changedProperties.has("open") || changedProperties.has("label") || changedProperties.has("autoalign") || changedProperties.has("menuAlignment") || changedProperties.has("size") || changedProperties.has("enableV12Overflowmenu"))) this._syncMenuChild();
		if (changedProperties.has("open") || changedProperties.has("disabled")) this._syncTriggerTooltipState();
	}
	render() {
		return html`${super.render()} `;
	}
	_getLabelText() {
		if (this.label) return this.label;
		return this.querySelector("[slot=tooltip-content]")?.textContent?.trim() || "Options";
	}
	_getTriggerButton() {
		return this._tooltip?.querySelector("button");
	}
	_isTriggerEvent(event) {
		const triggerButton = this._getTriggerButton();
		return !!triggerButton && event.composedPath().includes(triggerButton);
	}
	_isDeprecatedOverflowMenuItemEvent(event) {
		return event.composedPath().some((entry) => entry instanceof HTMLElement && deprecatedOverflowMenuTagNames.has(entry.tagName));
	}
	/**
	* Checks whether the menu-composition path is enabled.
	*/
	_isMenuCompositionEnabled() {
		return this.enableV12Overflowmenu || isFeatureFlagEnabled("enable-v12-overflowmenu", this);
	}
	/**
	* Checks whether floating styles should be driven by Floating UI.
	*/
	_usesDynamicFloatingStyles() {
		return this.autoalign || isFeatureFlagEnabled("enable-v12-dynamic-floating-styles", this);
	}
	_getMenuChild() {
		return Array.from(this.children).find((child) => {
			return child.tagName === `cds-custom-menu`.toUpperCase();
		}) ?? null;
	}
	_warnDeprecatedChildren() {
		if (this._didWarnDeprecatedChildren) return;
		if (Array.from(this.children).some((child) => {
			return deprecatedOverflowMenuTagNames.has(child.tagName);
		})) {
			warnInDev("`cds-custom-overflow-menu` with `enable-v12-overflowmenu` expects a direct `cds-custom-menu` child instead of the deprecated `cds-custom-overflow-menu-body` structure.");
			this._didWarnDeprecatedChildren = true;
		}
	}
	_warnInvalidMenuComposition() {
		if (this._didWarnInvalidComposition) return;
		const hasDirectMenuItems = Array.from(this.children).some((child) => child.tagName.startsWith(menuItemTagPrefix));
		if (!!!this._getMenuChild() || hasDirectMenuItems) {
			warnInDev("`cds-custom-overflow-menu` with `enable-v12-overflowmenu` expects a direct `cds-custom-menu` child. Place `cds-custom-menu-item*` descendants inside that `cds-custom-menu`.");
			this._didWarnInvalidComposition = true;
		}
	}
	_syncMenuChild() {
		const menuSyncToken = ++this._menuSyncToken;
		this._warnDeprecatedChildren();
		this._warnInvalidMenuComposition();
		const menu = this._getMenuChild();
		if (!menu) return;
		const menuAlignment = this.menuAlignment;
		menu.id ||= this._menuId;
		menu.label = this._getLabelText();
		menu.menuAlignment = menuAlignment;
		this._syncMenuChildPosition(menu);
		menu.open = this.open;
		menu.size = this._toMenuSize(this.size);
		const shouldUseFloatingStyles = this._usesDynamicFloatingStyles();
		if (!this.open || !shouldUseFloatingStyles) {
			this._menuController.hostDisconnected();
			this._resetMenuFloatingStyles(menu);
			return;
		}
		this.updateComplete.then(async () => {
			if (menuSyncToken !== this._menuSyncToken || !this.open || !this._isMenuCompositionEnabled() || this._getMenuChild() !== menu) return;
			await menu.updateComplete;
			if (menuSyncToken !== this._menuSyncToken || !this.open || !this._isMenuCompositionEnabled() || this._getMenuChild() !== menu) return;
			const trigger = this._getTriggerButton();
			if (!trigger) return;
			const styleElement = menu.shadowRoot?.querySelector(`.cds-custom--menu`);
			const fallbackPlacements = menuAlignment.includes("bottom") ? [...bottomFirstFallbackPlacements] : [...topFirstFallbackPlacements];
			const flipArguments = this.autoalign ? { fallbackPlacements } : {
				mainAxis: false,
				crossAxis: false
			};
			this._menuController.setPlacement({
				trigger,
				target: menu,
				alignment: menuAlignment,
				styleElement,
				flipArguments,
				mainAxisOffset: 0,
				open: this.open
			});
		});
	}
	_syncMenuChildPosition(menu) {
		const trigger = this._getTriggerButton();
		if (!trigger) return;
		const { left, right, top, bottom } = trigger.getBoundingClientRect();
		menu.x = [left, right];
		menu.y = [top, bottom];
	}
	_toMenuSize(size) {
		switch (size) {
			case "xs": return "xs";
			case "sm": return "sm";
			case "md": return "md";
			case "lg": return "lg";
			default: return "md";
		}
	}
	async _focusManagedMenuItem(index) {
		const menu = this._getMenuChild();
		if (!menu) return;
		await menu.updateComplete;
		if (!this.open || this._getMenuChild() !== menu) return;
		const enabledItems = menu.activeitems.map(({ item }) => item).filter((item) => item instanceof HTMLElement && !item.hasAttribute("disabled"));
		(enabledItems[index - 1] ?? enabledItems[0])?.focus();
	}
	_resetMenuChildFloatingStyles({ closeMenu = false } = {}) {
		const menu = this._getMenuChild();
		if (!menu) return;
		this._resetMenuFloatingStyles(menu);
		if (closeMenu) menu.open = false;
	}
	_resetMenuFloatingStyles(menu) {
		const menuSurface = menu.shadowRoot?.querySelector(`.cds-custom--menu`);
		if (!menuSurface) return;
		menuSurface.style.removeProperty("left");
		menuSurface.style.removeProperty("top");
		menuSurface.style.removeProperty("position");
		menuSurface.style.removeProperty("visibility");
		menuSurface.removeAttribute("align");
	}
	/**
	* Suppresses trigger tooltip interactions while the menu is open.
	*/
	_syncTriggerTooltipState() {
		const tooltip = this._tooltip;
		if (!tooltip) return;
		tooltip.keyboardOnly = this.open;
		this._tooltipContent?.toggleAttribute("hidden", this.disabled || this.open);
		if (this.open) tooltip.open = false;
	}
};
__decorate([query(`cds-custom-tooltip`)], CDSOverflowMenu.prototype, "_tooltip", void 0);
__decorate([query(`cds-custom-tooltip-content`)], CDSOverflowMenu.prototype, "_tooltipContent", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "data-table"
})], CDSOverflowMenu.prototype, "dataTable", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOverflowMenu.prototype, "disabled", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "enable-v12-overflowmenu"
})], CDSOverflowMenu.prototype, "enableV12Overflowmenu", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOverflowMenu.prototype, "flipped", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOverflowMenu.prototype, "autoalign", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOverflowMenu.prototype, "open", void 0);
__decorate([property()], CDSOverflowMenu.prototype, "index", void 0);
__decorate([property({ type: String })], CDSOverflowMenu.prototype, "label", void 0);
__decorate([property({
	type: String,
	attribute: "menu-alignment"
})], CDSOverflowMenu.prototype, "menuAlignment", void 0);
__decorate([property({ reflect: true })], CDSOverflowMenu.prototype, "size", void 0);
__decorate([property({
	type: Boolean,
	attribute: "toolbar-action",
	reflect: true
})], CDSOverflowMenu.prototype, "toolbarAction", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOverflowMenu.prototype, "breadcrumb", void 0);
//#endregion
export { OVERFLOW_MENU_SIZE, CDSOverflowMenu as default };

//# sourceMappingURL=overflow-menu.js.map