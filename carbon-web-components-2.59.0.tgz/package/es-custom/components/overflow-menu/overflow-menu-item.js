/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import "./defs.js";
import overflow_menu_default from "./overflow-menu.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/overflow-menu/overflow-menu-item.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Overflow menu item.
*
* @element cds-custom-overflow-menu-item
* @fires cds-custom-overflow-menu-item-clicked - The custom event fired when an overflow menu item is clicked.
*/
var CDSOverflowMenuItem = class extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.danger = false;
		this.dangerDescription = "";
		this.disabled = false;
		this.divider = false;
		this.href = "";
		this.size = "md";
	}
	static {
		this.is = `cds-custom-overflow-menu-item`;
	}
	/**
	* Handles `click` event on this element.
	*/
	_handleClick(event) {
		this.dispatchEvent(new CustomEvent(this.constructor.itemClicked, {
			bubbles: true,
			composed: true,
			detail: { evt: event }
		}));
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "menuitem");
		super.connectedCallback();
	}
	render() {
		const { _handleClick: handleClick } = this;
		const hasDangerDescription = this.danger && Boolean(this.dangerDescription);
		return this.href ? html`
          <a
            class="${"cds-custom"}--overflow-menu-options__btn"
            ?disabled=${this.disabled}
            href="${this.href}"
            tabindex="-1"
            @click="${handleClick}">
            <div class="${"cds-custom"}--overflow-menu-options__option-content">
              <slot></slot>
              ${hasDangerDescription ? html`<span
                    id="danger-description"
                    class="${"cds-custom"}--visually-hidden"
                    >${this.dangerDescription}</span
                  >` : html``}
            </div>
            <slot name="icon"></slot>
          </a>
        ` : html`
          <button
            class="${"cds-custom"}--overflow-menu-options__btn"
            ?disabled=${this.disabled}
            tabindex="-1"
            @click="${handleClick}">
            <div class="${"cds-custom"}--overflow-menu-options__option-content">
              <slot></slot>
              ${hasDangerDescription ? html`<span
                    id="danger-description"
                    class="${"cds-custom"}--visually-hidden"
                    >${this.dangerDescription}</span
                  >` : html``}
            </div>
            <slot name="icon"></slot>
          </button>
        `;
	}
	/**
	* The name of the custom event fired when the item is clicked.
	*/
	static get itemClicked() {
		return `cds-custom-overflow-menu-item-clicked`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = overflow_menu_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOverflowMenuItem.prototype, "danger", void 0);
__decorate([property({
	type: String,
	attribute: "danger-description"
})], CDSOverflowMenuItem.prototype, "dangerDescription", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOverflowMenuItem.prototype, "disabled", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOverflowMenuItem.prototype, "divider", void 0);
__decorate([property()], CDSOverflowMenuItem.prototype, "href", void 0);
__decorate([property({ reflect: true })], CDSOverflowMenuItem.prototype, "size", void 0);
//#endregion
export { CDSOverflowMenuItem as default };

//# sourceMappingURL=overflow-menu-item.js.map