/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { indexOf } from "../../globals/internal/collection-helpers.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListener from "../../globals/decorators/host-listener.js";
import { NAVIGATION_DIRECTION } from "./defs.js";
import overflow_menu_default from "./overflow-menu.scss.js";
import "../floating-menu/defs.js";
import CDSFloatingMenu, { getMenuOffset } from "../floating-menu/floating-menu.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/overflow-menu/overflow-menu-body.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @param index The index
* @param length The length of the array.
* @returns The new index, adjusting overflow/underflow.
*/
const capIndex = (index, length) => {
	if (index < 0) return length - 1;
	if (index >= length) return 0;
	return index;
};
/**
* Overflow menu body.
*
* @element cds-custom-overflow-menu-body
*/
var CDSOverflowMenuBody = class CDSOverflowMenuBody extends CDSFloatingMenu {
	constructor(..._args) {
		super(..._args);
		this.direction = "bottom";
		this.flipped = false;
		this.open = false;
		this.selected = null;
		this._handleKeydown = async (event) => {
			const { key } = event;
			if (this.open) {
				/**
				* sets this.selected to focused menu item. the menu item is focused
				* automatically due to FocusMixin
				*/
				if (this.contains(document.activeElement)) this.selected = document.activeElement;
				if (key in NAVIGATION_DIRECTION) {
					event.preventDefault();
					this._navigate(NAVIGATION_DIRECTION[key]);
					return;
				}
				if (key === "Escape") {
					event.preventDefault();
					const menuTrigger = this.parent;
					this.open = false;
					if (menuTrigger && "open" in menuTrigger) menuTrigger.open = false;
					requestAnimationFrame(() => {
						const triggerButton = menuTrigger?.shadowRoot?.querySelector(`button.cds-custom--overflow-menu`) || menuTrigger?.querySelector(`button.cds-custom--overflow-menu`);
						if (triggerButton) triggerButton.focus();
					});
					return;
				}
				const items = this.querySelectorAll(CDSOverflowMenuBody.selectorItemEnabled);
				if (Array.from(items).some((item) => item.contains(document.activeElement))) {
					event.preventDefault();
					const menuTrigger = this.parent;
					this.open = false;
					if (menuTrigger && "open" in menuTrigger) menuTrigger.open = false;
					requestAnimationFrame(() => {
						const triggerButton = menuTrigger?.shadowRoot?.querySelector(`button.cds-custom--overflow-menu`) || menuTrigger?.querySelector(`button.cds-custom--overflow-menu`);
						if (triggerButton) triggerButton.focus();
					});
				}
			}
		};
	}
	static {
		this.is = `cds-custom-overflow-menu-body`;
	}
	/**
	* Gets the appropriate offset (menuOffset or menuOffsetFlip) based on the flipped state.
	* If no offset is provided, falls back to the default centering behavior.
	* Overrides `getOffsetConfig` in `CDSFloatingMenu`.
	*
	* @returns The menu offset configuration (object, function, or undefined).
	*/
	getOffsetConfig() {
		const offset = this.flipped ? this.menuOffsetFlip : this.menuOffset;
		if (!offset) {
			const trigger = this.parent;
			return getMenuOffset(this, this.direction, trigger, this.flipped);
		}
		return offset;
	}
	/**
	* @param currentItem The currently selected item.
	* @param direction The navigation direction.
	* @returns The item to be selected.
	*/
	_getNextItem(currentItem, direction) {
		const { selectorItemEnabled } = this.constructor;
		const menuItems = this.querySelectorAll(selectorItemEnabled);
		const currentIndex = indexOf(menuItems, currentItem);
		const nextIndex = capIndex(currentIndex + direction, menuItems.length);
		return nextIndex === currentIndex ? null : menuItems[nextIndex];
	}
	/**
	* Navigates through overflow menu items.
	*
	* @param direction `-1` to navigate backward, `1` to navigate forward.
	*/
	_navigate(direction) {
		if (this.selected) this._getNextItem(this.selected, direction)?.focus();
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "menu");
		if (!this.hasAttribute("tabindex")) this.setAttribute("tabindex", "-1");
		super.connectedCallback();
	}
	updated(changedProperties) {
		if (changedProperties.has("size")) {
			const { selectorMenuItem } = this.constructor;
			this.querySelectorAll(selectorMenuItem).forEach((item) => {
				if (this.size) item.setAttribute("size", this.size);
				else item.removeAttribute("size");
			});
		}
		super.updated(changedProperties);
	}
	render() {
		return html` <slot></slot> `;
	}
	/**
	* A selector that will return menu items.
	*/
	static get selectorMenuItem() {
		return `cds-custom-overflow-menu-item`;
	}
	/**
	* A selector that will return enabled menu items.
	*/
	static get selectorItemEnabled() {
		return `cds-custom-overflow-menu-item:not([disabled])`;
	}
	static {
		this.styles = overflow_menu_default;
	}
};
__decorate([property()], CDSOverflowMenuBody.prototype, "direction", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOverflowMenuBody.prototype, "flipped", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSOverflowMenuBody.prototype, "open", void 0);
__decorate([property({ reflect: true })], CDSOverflowMenuBody.prototype, "size", void 0);
__decorate([property({ attribute: false })], CDSOverflowMenuBody.prototype, "menuOffset", void 0);
__decorate([property({ attribute: false })], CDSOverflowMenuBody.prototype, "menuOffsetFlip", void 0);
__decorate([HostListener("keydown")], CDSOverflowMenuBody.prototype, "_handleKeydown", void 0);
//#endregion
export { CDSOverflowMenuBody as default };

//# sourceMappingURL=overflow-menu-body.js.map