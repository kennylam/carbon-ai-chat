/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/overflow-menu/defs.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Overflow menu size.
*/
let OVERFLOW_MENU_SIZE = /* @__PURE__ */ function(OVERFLOW_MENU_SIZE) {
	/**
	* Extra small size.
	*/
	OVERFLOW_MENU_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	OVERFLOW_MENU_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	OVERFLOW_MENU_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	OVERFLOW_MENU_SIZE["LARGE"] = "lg";
	return OVERFLOW_MENU_SIZE;
}({});
const NAVIGATION_DIRECTION = {
	ArrowDown: 1,
	ArrowUp: -1
};
//#endregion
export { NAVIGATION_DIRECTION, OVERFLOW_MENU_SIZE };

//# sourceMappingURL=defs.js.map