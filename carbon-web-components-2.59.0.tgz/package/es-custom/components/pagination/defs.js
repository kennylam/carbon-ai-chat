/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/pagination/defs.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Pagination size.
*/
let PAGINATION_SIZE = /* @__PURE__ */ function(PAGINATION_SIZE) {
	/**
	* Extra small size.
	*/
	PAGINATION_SIZE["XS"] = "xs";
	/**
	* Small size.
	*/
	PAGINATION_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	PAGINATION_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	PAGINATION_SIZE["LARGE"] = "lg";
	return PAGINATION_SIZE;
}({});
/**
* Backward/Forward button tooltip position.
*/
let PAGINATION_TOOLTIP_POSITION = /* @__PURE__ */ function(PAGINATION_TOOLTIP_POSITION) {
	/**
	* Positioned on the top.
	*/
	PAGINATION_TOOLTIP_POSITION["TOP"] = "top";
	/**
	* Positioned on the right.
	*/
	PAGINATION_TOOLTIP_POSITION["RIGHT"] = "right";
	/**
	* Positioned on the bottom.
	*/
	PAGINATION_TOOLTIP_POSITION["BOTTOM"] = "bottom";
	/**
	* Positioned on the left.
	*/
	PAGINATION_TOOLTIP_POSITION["LEFT"] = "left";
	return PAGINATION_TOOLTIP_POSITION;
}({});
//#endregion
export { PAGINATION_SIZE, PAGINATION_TOOLTIP_POSITION };

//# sourceMappingURL=defs.js.map