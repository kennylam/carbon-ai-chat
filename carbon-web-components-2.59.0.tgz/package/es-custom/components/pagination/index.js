/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import "../select/index.js";
import CDSPagination from "./pagination.js";
//#region src/components/pagination/index.ts
/**
* Copyright IBM Corp. 2021, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSPagination);
//#endregion
export { CDSPagination };

//# sourceMappingURL=index.js.map