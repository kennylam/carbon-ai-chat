/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import FocusMixin from "../../globals/mixins/focus.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../button/index.js";
import "./defs.js";
import pagination_default from "./pagination.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import CaretLeft16 from "@carbon/icons/es/caret--left/16.js";
import CaretRight16 from "@carbon/icons/es/caret--right/16.js";
//#region src/components/pagination/pagination.ts
const selectorPagesSelect = `cds-custom-select#pages-select`;
const selectorPageSizesSelect = `cds-custom-select`;
const selectorPreviousButton = `cds-custom--pagination__button--backward`;
const selectorForwardButton = `cds-custom--pagination__button--forward`;
/**
* Pagination UI.
*
* @element cds-custom-pagination
* @slot page-sizes-select - Where to put in the `<page-sizes-select>`.
* @fires cds-custom-pagination-changed-current - The custom event fired after the current page is changed from `<cds-custom-pages-select>`.
* @fires cds-custom-page-sizes-select-changed - The custom event fired after the number of rows per page is changed from `<cds-custom-page-sizes-select>`.
*/
var CDSPagination = class extends FocusMixin(HostListenerMixin(LitElement)) {
	constructor(..._args) {
		super(..._args);
		this.backwardText = "Previous page";
		this.backwardTextTooltipPosition = "top";
		this.page = 1;
		this.formatLabelText = ({ count }) => `Page of ${count} page${count <= 1 ? "" : "s"}`;
		this.formatStatusWithDeterminateTotal = ({ start, end, count }) => `${start}–${end} of ${count} item${count <= 1 ? "" : "s"}`;
		this.formatStatusWithIndeterminateTotal = ({ start, end, count }) => end == null ? `Item ${start}–` : `${start}–${end} item${count <= 1 ? "" : "s"}`;
		this.formatSupplementalText = ({ count }) => this.pagesUnknown || !this.totalItems ? `page` : `of ${count} page${count <= 1 ? "" : "s"}`;
		this.itemsPerPageText = "";
		this.disabled = false;
		this.forwardText = "Next page";
		this.forwardTextTooltipPosition = "top";
		this.pageInputDisabled = false;
		this.pageSize = 10;
		this.pagesUnknown = false;
		this.size = "md";
		this.start = 0;
		this.totalPages = 1;
	}
	static {
		this.is = `cds-custom-pagination`;
	}
	_handleSlotChange({ target }) {
		target.assignedNodes().filter((node) => node.nodeType !== Node.TEXT_NODE || node.textContent.trim()).forEach((item) => {
			this._pageSizeSelect.appendChild(item);
		});
	}
	/**
	* @returns Page status text.
	*/
	_renderStatusText() {
		const { start, pageSize, totalItems, pagesUnknown, formatStatusWithDeterminateTotal, formatStatusWithIndeterminateTotal } = this;
		const min = totalItems === 0 ? 0 : start + 1;
		if (pagesUnknown || totalItems == null) {
			if (totalItems === 0) return formatStatusWithDeterminateTotal({
				start: 0,
				end: 0,
				count: 0
			});
			const end = start + pageSize;
			return formatStatusWithIndeterminateTotal({
				start: min,
				end,
				count: Math.max(0, end - start)
			});
		}
		return formatStatusWithDeterminateTotal({
			start: min,
			end: Math.min(start + pageSize, totalItems),
			count: totalItems
		});
	}
	/**
	* Calculates the start value based on `page`, `pageSize`, and `totalItems`
	*/
	_calculateStart(page, pageSize, totalItems, pagesUnknown) {
		if (!pagesUnknown && totalItems === 0) return 0;
		const safePageSize = pageSize > 0 ? pageSize : 1;
		const calculatedStart = (Math.max(1, page) - 1) * safePageSize;
		if (!pagesUnknown && Number.isFinite(totalItems)) {
			const maxStart = (Math.ceil(totalItems / safePageSize) - 1) * safePageSize;
			return Math.max(0, Math.min(calculatedStart, maxStart));
		}
		return Math.max(0, calculatedStart);
	}
	/**
	* Handles user-initiated change in the row number the current page starts with.
	*
	* @param start The new current row number, index that starts with zero.
	*/
	_handleUserInitiatedChangeStart(start) {
		this.start = start;
		this.dispatchEvent(new CustomEvent(this.constructor.eventChangeCurrent, {
			bubbles: true,
			composed: true,
			detail: {
				page: this.page,
				pageSize: this.pageSize
			}
		}));
	}
	/**
	* Handles user-initiated change in the size of the page.
	*/
	_handleUserInitiatedPageSizeChange() {
		this.dispatchEvent(new CustomEvent(this.constructor.eventPageSizeChanged, {
			bubbles: true,
			composed: true,
			detail: {
				page: this.page,
				pageSize: this.pageSize
			}
		}));
	}
	/**
	* Handles `click` event on the previous button.
	*/
	_handleClickPrevButton() {
		const { start: oldStart, pageSize } = this;
		this.page--;
		const newStart = Math.max(oldStart - pageSize, 0);
		if (newStart !== oldStart) this._handleUserInitiatedChangeStart(newStart);
		if (this.page === 1) this._forwardButton.focus();
	}
	/**
	* Handles `click` event on the next button.
	*/
	_handleClickNextButton() {
		const { start: oldStart, pageSize, totalItems, pagesUnknown } = this;
		this.page++;
		const newStart = oldStart + pageSize;
		if (newStart < (totalItems == null ? Infinity : totalItems) || pagesUnknown) this._handleUserInitiatedChangeStart(newStart);
		if (!pagesUnknown && this.page === this.totalPages) this._previousButton.focus();
	}
	/**
	* Handles user-initiated change in number of rows per page.
	*
	* @param event The event.
	*/
	_handleChangeSelector(event) {
		const { value } = event.detail;
		const { totalItems, pageSize, pagesUnknown } = this;
		if (event.composedPath()[0] === this._pageSizeSelect) {
			this.pageSize = parseInt(value);
			this.totalPages = pageSize > 0 ? Math.ceil(totalItems / pageSize) : totalItems;
			this.page = 1;
			this.start = 0;
			this._handleUserInitiatedPageSizeChange();
		} else {
			this.page = Number(value);
			const newStart = this._calculateStart(value, pageSize, totalItems, pagesUnknown);
			this._handleUserInitiatedChangeStart(newStart);
		}
	}
	updated(changedProperties) {
		const { pageSize, totalItems } = this;
		if (changedProperties.has("pageSize")) this._pageSizeSelect.value = String(pageSize ?? "");
		if (changedProperties.has("pageSize") || changedProperties.has("start") || changedProperties.has("totalItems") || changedProperties.has("page")) {
			const computedTotalPages = pageSize > 0 ? Math.ceil((totalItems ?? 0) / pageSize) : totalItems ?? 0;
			if (this.totalPages !== computedTotalPages) this.updateComplete.then(() => {
				this.totalPages = computedTotalPages;
			});
			const totalPagesSafe = Math.max(1, computedTotalPages || 1);
			const requestedPage = Math.max(1, Math.floor(this.page || 1));
			const displayPage = Math.min(requestedPage, totalPagesSafe);
			if (this._pagesSelect) this._pagesSelect.value = displayPage.toString();
		}
		if (changedProperties.has("page")) {
			this.start = this._calculateStart(this.page, this.pageSize, this.totalItems, this.pagesUnknown);
			if (this._pagesSelect) this._pagesSelect.value = String(this.page);
		}
	}
	render() {
		const { page, disabled, forwardText, forwardTextTooltipPosition, backwardText, backwardTextTooltipPosition, itemsPerPageText, pageInputDisabled, pageSize, pageSizeInputDisabled, pagesUnknown, size, start, totalItems, totalPages, _handleClickPrevButton: handleClickPrevButton, _handleClickNextButton: handleClickNextButton, _handleSlotChange: handleSlotChange, formatLabelText, formatSupplementalText } = this;
		const { isLastPage = start + pageSize >= totalItems } = this;
		const prevButtonDisabled = disabled || start === 0;
		const nextButtonDisabled = disabled || !pagesUnknown && isLastPage;
		const prevButtonClassMap = {
			[`cds-custom--btn`]: true,
			[`cds-custom--btn--icon-only`]: true,
			[`cds-custom--pagination__button`]: true,
			[`cds-custom--pagination__button--backward`]: true,
			[`cds-custom--pagination__button--no-index`]: prevButtonDisabled,
			[`cds-custom--btn--${size}`]: true,
			[`cds-custom--btn--ghost`]: true
		};
		const nextButtonClassMap = {
			[`cds-custom--btn`]: true,
			[`cds-custom--btn--icon-only`]: true,
			[`cds-custom--pagination__button`]: true,
			[`cds-custom--pagination__button--forward`]: true,
			[`cds-custom--pagination__button--no-index`]: nextButtonDisabled,
			[`cds-custom--btn--${size}`]: true,
			[`cds-custom--btn--ghost`]: true
		};
		const prevButtonClasses = Object.entries(prevButtonClassMap).filter(([, value]) => value === true).map(([key]) => key).join(" ");
		const nextButtonClasses = Object.entries(nextButtonClassMap).filter(([, value]) => value === true).map(([key]) => key).join(" ");
		const totalPagesSafe = Number.isFinite(totalPages) && totalPages > 0 ? totalPages : Math.max(1, page || 1);
		return html`
      <div class="${"cds-custom"}--pagination__left">
        <cds-custom-select
          ?disabled=${disabled || pageSizeInputDisabled}
          id="page-size-select"
          left-select
          pagination
          size="${size}"
          inline
          value="${pageSize}"
          label-styles-disable>
          <div slot="label-text">
            ${itemsPerPageText && html`<span class="${"cds-custom"}--pagination__text"
              >${itemsPerPageText}</span
            >`}
            <slot name="label-text"></slot>
          </div>
          <slot @slotchange=${handleSlotChange}></slot>
        </cds-custom-select>
        <span
          class="${"cds-custom"}--pagination__text ${"cds-custom"}--pagination__items-count"
          >${this._renderStatusText()}</span
        >
      </div>
      <div class="${"cds-custom"}--pagination__right">
        ${pagesUnknown || !totalItems ? html`
              <span
                class="${"cds-custom"}--pagination__text ${"cds-custom"}--pagination__page-text ${"cds-custom"}--pagination__unknown-pages-text"
                >${formatSupplementalText({ count: totalPages })} ${page}</span
              >
            ` : html`
              <cds-custom-select
                ?disabled=${disabled || pageInputDisabled}
                id="pages-select"
                pagination
                size="${size}"
                inline
                value="${page}"
                hide-label>
                <span slot="label-text">
                  ${formatLabelText({ count: totalPages })}
                </span>
                ${Array.from(new Array(totalPagesSafe)).map((_item, index) => html`
                    <cds-custom-select-item
                      value="${index + 1}"
                      ?selected=${page === index + 1}>
                      ${index + 1}
                    </cds-custom-select-item>
                  `)}
              </cds-custom-select>
              <span class="${"cds-custom"}--pagination__text"
                >${formatSupplementalText({ count: totalPages })}</span
              >
            `}

        <div class="${"cds-custom"}--pagination__control-buttons">
          <cds-custom-button
            tooltip-position=${backwardTextTooltipPosition}
            pagination
            size="${size}"
            ?disabled="${prevButtonDisabled}"
            button-class-name="${prevButtonClasses}"
            tooltip-text="${backwardText}"
            @click="${handleClickPrevButton}">
            ${iconLoader(CaretLeft16, { slot: "icon" })}
          </cds-custom-button>
          <cds-custom-button
            tooltip-position=${forwardTextTooltipPosition}
            pagination
            size="${size}"
            ?disabled="${nextButtonDisabled}"
            button-class-name="${nextButtonClasses}"
            tooltip-text="${forwardText}"
            @click="${handleClickNextButton}">
            ${iconLoader(CaretRight16, { slot: "icon" })}
          </cds-custom-button>
        </div>
      </div>
    `;
	}
	/**
	* A selector that will return the select box for the current page.
	*/
	static get selectorPagesSelect() {
		return selectorPagesSelect;
	}
	/**
	* A selector that will return the select box for page sizes.
	*/
	static get selectorPageSizesSelect() {
		return selectorPageSizesSelect;
	}
	/**
	* A selector that will return the previous button.
	*/
	static get selectorPreviousButton() {
		return selectorPreviousButton;
	}
	/**
	* A selector that will return the forward button.
	*/
	static get selectorForwardButton() {
		return selectorForwardButton;
	}
	/**
	* The name of the custom event fired after the current row number is changed.
	*/
	static get eventChangeCurrent() {
		return `cds-custom-pagination-changed-current`;
	}
	/**
	* The name of the custom event fired after the number of rows per page is changed from `<cds-custom-page-sizes-select>`.
	*/
	static get eventPageSizeChanged() {
		return `cds-custom-page-sizes-select-changed`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = pagination_default;
	}
};
__decorate([query(selectorPageSizesSelect)], CDSPagination.prototype, "_pageSizeSelect", void 0);
__decorate([query(selectorPagesSelect)], CDSPagination.prototype, "_pagesSelect", void 0);
__decorate([query(`[button-class-name*=${selectorPreviousButton}]`)], CDSPagination.prototype, "_previousButton", void 0);
__decorate([query(`[button-class-name*=${selectorForwardButton}]`)], CDSPagination.prototype, "_forwardButton", void 0);
__decorate([HostListener(`cds-custom-select-selected`)], CDSPagination.prototype, "_handleChangeSelector", null);
__decorate([property({ attribute: "backward-text" })], CDSPagination.prototype, "backwardText", void 0);
__decorate([property({ attribute: "backward-text-tooltip-position" })], CDSPagination.prototype, "backwardTextTooltipPosition", void 0);
__decorate([property({
	type: Number,
	reflect: true
})], CDSPagination.prototype, "page", void 0);
__decorate([property({ attribute: false })], CDSPagination.prototype, "formatLabelText", void 0);
__decorate([property({ attribute: false })], CDSPagination.prototype, "formatStatusWithDeterminateTotal", void 0);
__decorate([property({ attribute: false })], CDSPagination.prototype, "formatStatusWithIndeterminateTotal", void 0);
__decorate([property({ attribute: false })], CDSPagination.prototype, "formatSupplementalText", void 0);
__decorate([property({
	type: Boolean,
	attribute: "is-last-page"
})], CDSPagination.prototype, "isLastPage", void 0);
__decorate([property({ attribute: "items-per-page-text" })], CDSPagination.prototype, "itemsPerPageText", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSPagination.prototype, "disabled", void 0);
__decorate([property({ attribute: "forward-text" })], CDSPagination.prototype, "forwardText", void 0);
__decorate([property({ attribute: "forward-text-tooltip-position" })], CDSPagination.prototype, "forwardTextTooltipPosition", void 0);
__decorate([property({
	type: Boolean,
	attribute: "page-input-disabled"
})], CDSPagination.prototype, "pageInputDisabled", void 0);
__decorate([property({
	type: Number,
	attribute: "page-size",
	reflect: true
})], CDSPagination.prototype, "pageSize", void 0);
__decorate([property({
	type: Boolean,
	attribute: "page-size-input-disabled"
})], CDSPagination.prototype, "pageSizeInputDisabled", void 0);
__decorate([property({ attribute: "page-size-label-text" })], CDSPagination.prototype, "pageSizeLabelText", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "pages-unknown"
})], CDSPagination.prototype, "pagesUnknown", void 0);
__decorate([property({ reflect: true })], CDSPagination.prototype, "size", void 0);
__decorate([property({ type: Number })], CDSPagination.prototype, "start", void 0);
__decorate([property({
	type: Number,
	attribute: "total-items",
	converter: { fromAttribute: (value) => value === null || value === "" ? void 0 : Number(value) }
})], CDSPagination.prototype, "totalItems", void 0);
__decorate([property({ type: Number })], CDSPagination.prototype, "totalPages", void 0);
//#endregion
export { CDSPagination as default };

//# sourceMappingURL=pagination.js.map