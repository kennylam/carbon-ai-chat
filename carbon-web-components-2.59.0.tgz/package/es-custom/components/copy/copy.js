/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import CDSIconButton from "../icon-button/icon-button.js";
import copy_button_default from "../copy-button/copy-button.scss.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/copy/copy.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Copy.
*
* @element cds-custom-copy
*/
var CDSCopy = class extends CDSIconButton {
	constructor(..._args) {
		super(..._args);
		this._showFeedback = false;
		this._animation = "";
		this._createHandleFeedbackTooltip = () => {
			let timeoutId;
			return (timeout) => {
				const buttonClasses = this.shadowRoot?.querySelector("button")?.classList;
				if (timeoutId) {
					clearTimeout(timeoutId);
					timeoutId = void 0;
				}
				this._showFeedback = true;
				buttonClasses?.add(`cds-custom--copy-btn--animating`);
				this._animation = "fade-in";
				buttonClasses?.add(`cds-custom--copy-btn--${this._animation}`);
				this.requestUpdate();
				timeoutId = setTimeout(() => {
					this._showFeedback = false;
					this._animation = "fade-out";
					buttonClasses?.remove(`cds-custom--copy-btn--fade-in`);
					buttonClasses?.add(`cds-custom--copy-btn--${this._animation}`);
					this.requestUpdate();
				}, timeout);
			};
		};
		this._handleFeedbackTooltip = this._createHandleFeedbackTooltip();
		this.feedback = "Copied!";
		this.feedbackTimeout = 2e3;
	}
	static {
		this.is = `cds-custom-copy`;
	}
	/**
	* Handles `click` event on the copy button.
	*/
	_handleClickButton() {
		this._handleFeedbackTooltip(this.feedbackTimeout);
	}
	_renderTooltipContent() {
		return html`
      <cds-custom-tooltip-content>
        ${this._showFeedback ? this.feedback : html`<slot name="tooltip-content"></slot>`}
      </cds-custom-tooltip-content>
    `;
	}
	connectedCallback() {
		this.closeOnActivation = false;
		this.addEventListener("click", this._handleClickButton);
		super.connectedCallback();
	}
	updated(changedProperties) {
		this.shadowRoot?.querySelector("button")?.addEventListener("animationend", () => {
			if (this._animation === "fade-out") {
				const buttonClasses = this.shadowRoot?.querySelector("button")?.classList;
				buttonClasses?.remove(`cds-custom--copy-btn--animating`);
				buttonClasses?.remove(`cds-custom--copy-btn--${this._animation}`);
				this._animation = "";
			}
		});
		super.updated(changedProperties);
		this.shadowRoot?.querySelector("button")?.setAttribute("aria-label", this.parentNode?.host.textContent);
	}
	static {
		this.styles = copy_button_default;
	}
};
__decorate([property()], CDSCopy.prototype, "feedback", void 0);
__decorate([property({
	type: Number,
	attribute: "feedback-timeout"
})], CDSCopy.prototype, "feedbackTimeout", void 0);
//#endregion
export { CDSCopy as default };

//# sourceMappingURL=copy.js.map