/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import { FeatureFlags, createScope } from "../../packages/feature-flags/es/index.js";
import { LitElement, html } from "lit";
//#region src/components/feature-flags/index.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* <feature-flags> provides scoped feature flags to child components.
*
* Usage:
* Wrap any child components inside <feature-flags> to provide scoped feature flags like this:
* <feature-flags enable-dialog-element="true">
*   <component></component>
* </feature-flags>
*
* Available flags:
* - enable-dialog-element
* - enable-treeview-controllable
* - ... (and others listed in observedAttributes)
*
* How to check a Flag in your component:
*   import { isFeatureFlagEnabled } from './feature-flags';
*   isFeatureFlagEnabled('enable-dialog-element', this)
*   Returns true if the flag is enabled in the nearest <feature-flags> ancestor
*/
const hasOwn = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
/**
* Feature Flags
*
* @element feature-flags
*/
var FeatureFlagsElement = class FeatureFlagsElement extends LitElement {
	static {
		this.is = "feature-flags";
	}
	static {
		this.flagComponentMap = {
			"enable-v12-release": null,
			"enable-v12-tile-default-icons": "CDS-CLICKABLE-TILE",
			"enable-v12-tile-radio-icons": "CDS-TILE",
			"enable-v12-overflowmenu": "CDS-OVERFLOW-MENU",
			"enable-treeview-controllable": "CDS-TREEVIEW",
			"enable-experimental-focus-wrap-without-sentinels": "CDS-FOCUS-WRAP",
			"enable-focus-wrap-without-sentinels": "CDS-FOCUS-WRAP",
			"enable-dialog-element": "CDS-MODAL",
			"enable-v12-dynamic-floating-styles": "CDS-FLOATING",
			"enable-v12-toggle-reduced-label-spacing": "CDS-TOGGLE"
		};
	}
	static get observedAttributes() {
		return Object.keys(FeatureFlagsElement.flagComponentMap);
	}
	constructor() {
		super();
		this.scope = FeatureFlags;
		this.flags = {};
		this.attachShadow({ mode: "open" });
	}
	connectedCallback() {
		super.connectedCallback();
		this.updateScope();
	}
	attributeChangedCallback(name, _oldVal, newVal) {
		const value = newVal !== null && newVal !== "false";
		this.flags[name] = value;
		const relatedComponent = hasOwn(FeatureFlagsElement.flagComponentMap, name) ? FeatureFlagsElement.flagComponentMap[name] : null;
		if (relatedComponent && this.firstElementChild?.tagName === relatedComponent) this.firstElementChild.setAttribute(name, "");
		this.updateScope();
	}
	syncFeatureFlagAttributes() {
		for (const [flag, relatedComponent] of Object.entries(FeatureFlagsElement.flagComponentMap)) {
			if (!relatedComponent) continue;
			let isEnabled = false;
			try {
				isEnabled = this.scope.enabled(flag);
			} catch {
				isEnabled = false;
			}
			for (const element of this.querySelectorAll(relatedComponent.toLowerCase())) {
				if (findParentFeatureFlags(element) !== this) continue;
				if (isEnabled) element.setAttribute(flag, "");
				else element.removeAttribute(flag);
			}
		}
	}
	getParentFeatureFlagsElement() {
		let parent = this.parentNode;
		while (parent) {
			if (parent instanceof ShadowRoot) {
				parent = parent.host;
				continue;
			}
			if (parent instanceof FeatureFlagsElement) return parent;
			parent = parent.parentNode;
		}
		return null;
	}
	getParentScope() {
		return this.getParentFeatureFlagsElement()?.getScope() ?? null;
	}
	syncChildFeatureFlagScopes() {
		for (const element of this.querySelectorAll("feature-flags")) if (element instanceof FeatureFlagsElement && element.getParentFeatureFlagsElement() === this) element.updateScope();
	}
	updateScope() {
		const newScope = createScope(this.flags);
		const parentScope = this.getParentScope() || FeatureFlags;
		if (parentScope) newScope.mergeWithScope(parentScope);
		this.scope = newScope;
		this.syncFeatureFlagAttributes();
		this.syncChildFeatureFlagScopes();
	}
	render() {
		return html` <slot></slot> `;
	}
	isFeatureFlagEnabled(flag) {
		return this.scope.enabled(flag);
	}
	getScope() {
		return this.scope;
	}
};
defineCustomElement(FeatureFlagsElement);
function findParentFeatureFlags(el) {
	let parent = el.parentNode;
	while (parent) {
		if (parent instanceof ShadowRoot) {
			parent = parent.host;
			continue;
		}
		if (parent instanceof FeatureFlagsElement) return parent;
		parent = parent.parentNode;
	}
	return null;
}
function isFeatureFlagEnabled(flag, context) {
	return findParentFeatureFlags(context)?.isFeatureFlagEnabled(flag) ?? false;
}
//#endregion
export { FeatureFlagsElement as default, findParentFeatureFlags, isFeatureFlagEnabled };

//# sourceMappingURL=index.js.map