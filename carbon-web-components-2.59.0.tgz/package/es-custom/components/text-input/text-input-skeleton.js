/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import text_input_default from "./text-input.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/text-input/text-input-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @element cds-custom-text-input-skeleton
*
* Skeleton of text input.
*/
var CDSTextInputSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hideLabel = false;
	}
	static {
		this.is = `cds-custom-text-input-skeleton`;
	}
	render() {
		const { hideLabel, size } = this;
		return html`
      <div class=${classMap({
			[`cds-custom--form-item`]: true,
			[`cds-custom--layout--size-${size}`]: size !== void 0
		})}>
        ${hideLabel ? "" : html`<span class="${"cds-custom"}--label ${"cds-custom"}--skeleton"></span>`}
        <div class="${"cds-custom"}--text-input ${"cds-custom"}--skeleton"></div>
      </div>
    `;
	}
	static {
		this.styles = text_input_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-label"
})], CDSTextInputSkeleton.prototype, "hideLabel", void 0);
__decorate([property({ reflect: true })], CDSTextInputSkeleton.prototype, "size", void 0);
//#endregion
export { CDSTextInputSkeleton as default };

//# sourceMappingURL=text-input-skeleton.js.map