/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../../globals/shared-enums.js";
import { INPUT_TYPE } from "../defs.js";
import { action } from "storybook/actions";
//#region src/components/text-input/stories/helpers.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const inputTypes = Object.entries(INPUT_TYPE).reduce((acc, [key, val]) => ({
	...acc,
	[`${key.toLowerCase()}`]: val
}), {});
const sizes = {
	[`Small size (sm)`]: "sm",
	[`Medium size (md)`]: "md",
	[`Large size (lg)`]: "lg"
};
const colorSchemes = {
	[`Regular`]: null,
	[`Light (light)`]: "light"
};
const createProps = ({ boolean, textNonEmpty, select }) => {
	const type = select("Input type (type)", inputTypes, "text");
	return {
		colorScheme: select("Color scheme (color-scheme)", colorSchemes, null),
		disabled: boolean("Disabled (disabled)", false),
		value: textNonEmpty("Input value (value)", ""),
		placeholder: textNonEmpty("Placeholder text (placeholder)", "Optional placeholder text"),
		invalid: boolean("Invalid (invalid)", false),
		onInput: action("input"),
		showPasswordVisibilityToggle: type === "text" || type === "password" ? boolean("Show password visibility toggle (show-password-visibility-toggle)", false) : null,
		size: select("Input size (size)", sizes, "md"),
		type
	};
};
//#endregion
export { createProps as default };

//# sourceMappingURL=helpers.js.map