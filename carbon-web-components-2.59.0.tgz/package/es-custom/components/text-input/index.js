/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSTextInput from "./text-input.js";
import CDSTextInputSkeleton from "./text-input-skeleton.js";
//#region src/components/text-input/index.ts
/**
* Copyright IBM Corp. 2021, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSTextInput);
defineCustomElement(CDSTextInputSkeleton);
//#endregion
export { CDSTextInput, CDSTextInputSkeleton };

//# sourceMappingURL=index.js.map