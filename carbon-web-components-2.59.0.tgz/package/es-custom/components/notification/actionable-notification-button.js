/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSButton from "../button/button.js";
import actionable_notification_default from "./actionable-notification.scss.js";
//#region src/components/notification/actionable-notification-button.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Actionable notification action button.
*
* @element cds-custom-actionable-notification-button
*/
var CDSActionableNotificationButton = class extends CDSButton {
	static {
		this.is = `cds-custom-actionable-notification-button`;
	}
	update(changedProperties) {
		super.update(changedProperties);
		this.shadowRoot.getElementById("button")?.classList.add(`cds-custom--actionable-notification__action-button`);
		this.setAttribute("size", "sm");
	}
	static {
		this.styles = actionable_notification_default;
	}
};
//#endregion
export { CDSActionableNotificationButton as default };

//# sourceMappingURL=actionable-notification-button.js.map