/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "./defs.js";
import actionable_notification_default from "./actionable-notification.scss.js";
import CDSActionableNotification, { iconsForKinds } from "./actionable-notification.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/notification/callout-notification.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Callout notification.
* @element cds-custom-callout-notification
* @slot subtitle - The subtitle.
* @slot title - The title.
* @slot action - The action button.
* @slot - The default slot for additional content.
*/
var CDSCalloutNotification = class extends CDSActionableNotification {
	constructor(..._args) {
		super(..._args);
		this.titleId = "";
		this.kind = "info";
	}
	static {
		this.is = `cds-custom-callout-notification`;
	}
	_renderIcon() {
		const { statusIconDescription, kind } = this;
		const IconComponent = iconsForKinds[kind];
		return IconComponent ? iconLoader(IconComponent, {
			class: `cds-custom--inline-notification__icon`,
			"aria-label": statusIconDescription || void 0
		}) : void 0;
	}
	_renderText() {
		const { subtitle, title, titleId, _type: type } = this;
		return html`
      <div class="${"cds-custom"}--${type}-notification__text-wrapper">
        <div class="${"cds-custom"}--${type}-notification__content">
          ${title && html`<div
            class="${"cds-custom"}--${type}-notification__title"
            id="${titleId}">
            ${title}<slot name="title"></slot>
          </div>`}
          ${subtitle && html`<div class="${"cds-custom"}--${type}-notification__subtitle">
            ${subtitle}<slot name="subtitle"></slot>
          </div>`}
          <slot></slot>
        </div>
      </div>
    `;
	}
	_renderButton() {
		return html``;
	}
	connectedCallback() {
		super.connectedCallback();
		this.removeAttribute("role");
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		const button = this.querySelector(this.constructor.selectorActionButton);
		if (button) {
			button.setAttribute("kind", "ghost");
			if (this.titleId) button.setAttribute("aria-describedby", this.titleId);
		}
	}
	static {
		this.styles = actionable_notification_default;
	}
};
__decorate([property({
	type: String,
	reflect: true,
	attribute: "title-id"
})], CDSCalloutNotification.prototype, "titleId", void 0);
__decorate([property({ reflect: true })], CDSCalloutNotification.prototype, "kind", void 0);
//#endregion
export { CDSCalloutNotification as default };

//# sourceMappingURL=callout-notification.js.map