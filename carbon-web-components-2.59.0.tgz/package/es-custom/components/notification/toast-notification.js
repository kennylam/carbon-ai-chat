/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import "./defs.js";
import CDSInlineNotification from "./inline-notification.js";
import toast_notification_default from "./toast-notification.scss.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/notification/toast-notification.ts
/**
* Copyright IBM Corp. 2019, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Toast notification.
*
* @element cds-custom-toast-notification
* @slot subtitle - The subtitle.
* @slot title - The title.
* @fires cds-custom-notification-beingclosed
*   The custom event fired before this notification is being closed upon a user gesture.
*   Cancellation of this event stops the user-initiated action of closing this notification.
* @fires cds-custom-notification-closed - The custom event fired after this notification is closed upon a user gesture.
*/
var CDSToastNotification = class extends CDSInlineNotification {
	constructor(..._args) {
		super(..._args);
		this._type = "toast";
		this.caption = "";
	}
	static {
		this.is = `cds-custom-toast-notification`;
	}
	_renderText() {
		const { caption, subtitle, title, _type: type } = this;
		return html`
      <div class="${"cds-custom"}--${type}-notification__title">
        ${title}<slot name="title"></slot>
      </div>
      <div class="${"cds-custom"}--${type}-notification__subtitle">
        ${subtitle}<slot name="subtitle"></slot>
      </div>
      ${caption || this.querySelector("[slot=\"caption\"]") ? html`
            <div class="${"cds-custom"}--${type}-notification__caption">
              ${caption}<slot name="caption"></slot>
            </div>
          ` : null}
      <slot></slot>
    `;
	}
	render() {
		const { _type: type } = this;
		return html`
      ${this._renderIcon()}
      <div class="${"cds-custom"}--${type}-notification__details">
        ${this._renderText()}
      </div>
      ${this._renderButton()}
    `;
	}
	static {
		this.styles = toast_notification_default;
	}
};
__decorate([property()], CDSToastNotification.prototype, "caption", void 0);
//#endregion
export { CDSToastNotification as default };

//# sourceMappingURL=toast-notification.js.map