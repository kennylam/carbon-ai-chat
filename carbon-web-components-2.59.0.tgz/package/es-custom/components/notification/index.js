/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../button/index.js";
import CDSInlineNotification from "./inline-notification.js";
import CDSToastNotification from "./toast-notification.js";
import CDSActionableNotification from "./actionable-notification.js";
import CDSActionableNotificationButton from "./actionable-notification-button.js";
import CDSCalloutNotification from "./callout-notification.js";
//#region src/components/notification/index.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSInlineNotification);
defineCustomElement(CDSToastNotification);
defineCustomElement(CDSActionableNotification);
defineCustomElement(CDSActionableNotificationButton);
defineCustomElement(CDSCalloutNotification);
//#endregion
export { CDSActionableNotification, CDSActionableNotificationButton, CDSCalloutNotification, CDSInlineNotification, CDSToastNotification };

//# sourceMappingURL=index.js.map