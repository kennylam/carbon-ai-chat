/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../defs.js";
//#region src/components/notification/stories/helper.ts
const kinds = {
	[`Error (error)`]: "error",
	[`Info (info)`]: "info",
	[`Info (info-square)`]: "info-square",
	[`Success (success)`]: "success",
	[`Warning (warning)`]: "warning",
	[`Warning Alt (warning-alt)`]: "warning-alt"
};
//#endregion
export { kinds as default };

//# sourceMappingURL=helper.js.map