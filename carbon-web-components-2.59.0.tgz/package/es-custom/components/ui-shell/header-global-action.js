/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListener from "../../globals/decorators/host-listener.js";
import "../button/defs.js";
import CDSButton from "../button/button.js";
import header_default from "./header.scss.js";
import { LitElement } from "lit";
import { property, query } from "lit/decorators.js";
//#region src/components/ui-shell/header-global-action.ts
/**
* Copyright IBM Corp. 2023, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header global action button
*
* @element cds-custom-header-global-action
*/
var CDSHeaderGlobalAction = class extends CDSButton {
	constructor(..._args) {
		super(..._args);
		this._handleDocumentClick = (event) => {
			const path = event.composedPath();
			this._handlePanelCloseIfFocusOutside(path);
		};
		this._handleDocumentFocusIn = (event) => {
			const path = event.composedPath();
			this._handlePanelCloseIfFocusOutside(path);
		};
	}
	static {
		this.is = `cds-custom-header-global-action`;
	}
	connectedCallback() {
		this.tooltipPosition = "bottom";
		this.kind = "ghost";
		this.size = "lg";
		super.connectedCallback();
	}
	firstUpdated() {
		document.addEventListener("click", this._handleDocumentClick, true);
		document.addEventListener("focusin", this._handleDocumentFocusIn, true);
	}
	disconnectedCallback() {
		document.removeEventListener("click", this._handleDocumentClick, true);
		document.removeEventListener("focusin", this._handleDocumentFocusIn, true);
		super.disconnectedCallback();
	}
	_handlePanelCloseIfFocusOutside(path) {
		const panel = this.ownerDocument?.querySelector(`#${this.panelId}`);
		const isInside = path.some((el) => el instanceof HTMLElement && (panel?.contains(el) || this.contains(el)));
		if (panel && !isInside) {
			panel.removeAttribute("expanded");
			this.active = false;
		}
	}
	_handleFocusOut(event) {
		const panel = this.ownerDocument?.querySelector(`#${this.panelId}`);
		const relatedTarget = event.relatedTarget;
		if (panel && relatedTarget && !this.contains(relatedTarget) && !panel.contains(relatedTarget)) {
			panel.removeAttribute("expanded");
			this.active = false;
		}
	}
	_handleClick(event) {
		const { disabled } = this;
		if (disabled) event.stopPropagation();
		else {
			const panel = this.ownerDocument?.querySelector(`#${this.panelId}`);
			if (panel) {
				const expanded = panel.hasAttribute("expanded");
				panel.toggleAttribute("expanded", !expanded);
				const active = !this.active;
				this.active = active;
			}
		}
	}
	_handleKeyDown(event) {
		const { key } = event;
		if (key === "Enter" || key === " ") {
			event.preventDefault();
			this._handleClick(event);
		} else if (key === "Escape") {
			const panel = this.ownerDocument?.querySelector(`#${this.panelId}`);
			if (panel) panel.removeAttribute("expanded");
			this.active = false;
		}
	}
	updated(changedProperties) {
		if (this._buttonNode) {
			this._buttonNode.classList.add(`cds-custom--header__action`);
			if (changedProperties.has("active") || changedProperties.size === 0) if (this.active) {
				this._buttonNode.classList.add(`cds-custom--header__action--active`);
				if (this.buttonLabelActive) this.tooltipText = this.buttonLabelActive;
			} else {
				this._buttonNode.classList.remove(`cds-custom--header__action--active`);
				if (this.buttonLabelInactive) this.tooltipText = this.buttonLabelInactive;
			}
		}
	}
	shouldUpdate(changedProperties) {
		if (changedProperties.has("active") && this._buttonNode) if (this.active) {
			this._buttonNode.classList.add(`cds-custom--header__action--active`);
			if (this.buttonLabelActive) this.tooltipText = this.buttonLabelActive;
		} else {
			this._buttonNode.classList.remove(`cds-custom--header__action--active`);
			if (this.buttonLabelInactive) this.tooltipText = this.buttonLabelInactive;
		}
		return true;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = header_default;
	}
};
__decorate([query("button")], CDSHeaderGlobalAction.prototype, "_buttonNode", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSHeaderGlobalAction.prototype, "active", void 0);
__decorate([property({
	type: String,
	attribute: "panel-id",
	reflect: true
})], CDSHeaderGlobalAction.prototype, "panelId", void 0);
__decorate([property({ attribute: "button-label-active" })], CDSHeaderGlobalAction.prototype, "buttonLabelActive", void 0);
__decorate([property({ attribute: "button-label-inactive" })], CDSHeaderGlobalAction.prototype, "buttonLabelInactive", void 0);
__decorate([HostListener("focusout")], CDSHeaderGlobalAction.prototype, "_handleFocusOut", null);
__decorate([HostListener("click", { capture: true })], CDSHeaderGlobalAction.prototype, "_handleClick", null);
__decorate([HostListener("keydown", { capture: true })], CDSHeaderGlobalAction.prototype, "_handleKeyDown", null);
//#endregion
export { CDSHeaderGlobalAction as default };

//# sourceMappingURL=header-global-action.js.map