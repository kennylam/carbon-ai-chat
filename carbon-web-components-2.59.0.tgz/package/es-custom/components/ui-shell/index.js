/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../button/index.js";
import CDSHeader from "./header.js";
import CDSHeaderGlobalAction from "./header-global-action.js";
import CDSHeaderMenu from "./header-menu.js";
import CDSSideNav from "./side-nav.js";
import CDSHeaderMenuButton from "./header-menu-button.js";
import CDSHeaderNavItem from "./header-nav-item.js";
import CDSHeaderMenuItem from "./header-menu-item.js";
import CDSHeaderName from "./header-name.js";
import CDSHeaderNav from "./header-nav.js";
import CDSHeaderPanel from "./header-panel.js";
import CDSHeaderSideNavItems from "./header-side-nav-items.js";
import CDSSideNavDivider from "./side-nav-divider.js";
import CDSSideNavItems from "./side-nav-items.js";
import CDSSideNavLink from "./side-nav-link.js";
import CDSSideNavMenu from "./side-nav-menu.js";
import CDSSideNavMenuItem from "./side-nav-menu-item.js";
import CDSSwitcher from "./switcher.js";
import CDSSwitcherDivider from "./switcher-divider.js";
import CDSSwitcherItem from "./switcher-item.js";
//#region src/components/ui-shell/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSHeader);
defineCustomElement(CDSHeaderGlobalAction);
defineCustomElement(CDSHeaderMenu);
defineCustomElement(CDSHeaderMenuButton);
defineCustomElement(CDSHeaderMenuItem);
defineCustomElement(CDSHeaderName);
defineCustomElement(CDSHeaderNav);
defineCustomElement(CDSHeaderNavItem);
defineCustomElement(CDSHeaderPanel);
defineCustomElement(CDSHeaderSideNavItems);
defineCustomElement(CDSSideNav);
defineCustomElement(CDSSideNavDivider);
defineCustomElement(CDSSideNavItems);
defineCustomElement(CDSSideNavLink);
defineCustomElement(CDSSideNavMenu);
defineCustomElement(CDSSideNavMenuItem);
defineCustomElement(CDSSwitcher);
defineCustomElement(CDSSwitcherDivider);
defineCustomElement(CDSSwitcherItem);
//#endregion
export { CDSHeader, CDSHeaderGlobalAction, CDSHeaderMenu, CDSHeaderMenuButton, CDSHeaderMenuItem, CDSHeaderName, CDSHeaderNav, CDSHeaderNavItem, CDSHeaderPanel, CDSHeaderSideNavItems, CDSSideNav, CDSSideNavDivider, CDSSideNavItems, CDSSideNavLink, CDSSideNavMenu, CDSSideNavMenuItem, CDSSwitcher, CDSSwitcherDivider, CDSSwitcherItem };

//# sourceMappingURL=index.js.map