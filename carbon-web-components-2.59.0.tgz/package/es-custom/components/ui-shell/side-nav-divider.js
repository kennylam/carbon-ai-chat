/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import side_nav_default from "./side-nav.scss.js";
import { LitElement } from "lit";
//#region src/components/ui-shell/side-nav-divider.ts
/**
* Copyright IBM Corp. 2021, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A divider in side nav.
*
* @element cds-custom-side-nav-divider
*/
var CDSSideNavDivider = class extends LitElement {
	static {
		this.is = `cds-custom-side-nav-divider`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "separator");
		super.connectedCallback();
	}
	static {
		this.styles = side_nav_default;
	}
};
//#endregion
export { CDSSideNavDivider as default };

//# sourceMappingURL=side-nav-divider.js.map