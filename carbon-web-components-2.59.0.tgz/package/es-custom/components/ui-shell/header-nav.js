/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import header_default from "./header.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/ui-shell/header-nav.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header.
*
* @element cds-custom-header-nav
* @csspart menu-body The menu body.
* @csspart divider The divider.
*/
var CDSHeaderNav = class extends LitElement {
	static {
		this.is = `cds-custom-header-nav`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "navigation");
		super.connectedCallback();
	}
	render() {
		const { menuBarLabel } = this;
		return html`
      <div part="divider" class="${"cds-custom"}-ce--header__divider"></div>
      <ul
        part="menu-body"
        class="${"cds-custom"}--header__menu-bar"
        aria-label="${menuBarLabel}">
        <slot></slot>
      </ul>
    `;
	}
	static {
		this.styles = header_default;
	}
};
__decorate([property({ attribute: "menu-bar-label" })], CDSHeaderNav.prototype, "menuBarLabel", void 0);
//#endregion
export { CDSHeaderNav as default };

//# sourceMappingURL=header-nav.js.map