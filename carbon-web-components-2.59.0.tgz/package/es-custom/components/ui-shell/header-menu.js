/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { forEach } from "../../globals/internal/collection-helpers.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import FocusMixin from "../../globals/mixins/focus.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import header_default from "./header.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
import ChevronDown16 from "@carbon/icons/es/chevron--down/16.js";
//#region src/components/ui-shell/header-menu.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header menu.
*
* @element cds-custom-header-menu
* @csspart trigger The trigger button.
* @csspart trigger-icon The trigger button icon.
* @csspart menu-body The menu body.
*/
var CDSHeaderMenu = class extends HostListenerMixin(FocusMixin(LitElement)) {
	constructor(..._args) {
		super(..._args);
		this._hasActiveChildren = false;
		this.expanded = false;
		this.isActive = false;
		this.triggerContent = "";
	}
	static {
		this.is = `cds-custom-header-menu`;
	}
	/**
	* Handles `click` event handler on this element.
	*/
	_handleClick() {
		this._handleUserInitiatedToggle();
	}
	/**
	* Handler for the `keydown` event on the trigger button.
	*/
	_handleKeydownTrigger({ key }) {
		if (key === "Esc" || key === "Escape") this._handleUserInitiatedToggle(false);
	}
	/**
	* Handles user-initiated toggling the open state.
	*
	* @param [force] If specified, forces the open state to the given one.
	*/
	_handleUserInitiatedToggle(force = !this.expanded) {
		this.expanded = force;
		if (!force) this._topMenuItem.focus();
	}
	/**
	* Handles `blur` event handler on this element.
	*/
	_handleBlur({ relatedTarget }) {
		if (!this.contains(relatedTarget)) this.expanded = false;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "listitem");
		const { selectorItem } = this.constructor;
		forEach(this.querySelectorAll(selectorItem), (elem) => {
			if (elem.isActive === true) this._hasActiveChildren = true;
		});
		super.connectedCallback();
	}
	updated(changedProperties) {
		if (changedProperties.has("expanded")) {
			const { selectorItem } = this.constructor;
			const { expanded } = this;
			forEach(this.querySelectorAll(selectorItem), (elem) => {
				elem.tabIndex = expanded ? 0 : -1;
			});
		}
	}
	render() {
		const { expanded, isActive, triggerContent, menuLabel, _hasActiveChildren, _handleClick: handleClick } = this;
		return html`
      <a
        part="trigger"
        role="button"
        tabindex="0"
        class="${classMap({
			[`cds-custom--header__menu-item`]: true,
			[`cds-custom--header__menu-title`]: true,
			[`cds-custom--header__menu-item--current`]: isActive || _hasActiveChildren && !expanded
		})}"
        href="javascript:void 0"
        aria-haspopup="menu"
        aria-expanded="${String(expanded)}"
        @click=${handleClick}>
        ${triggerContent}${iconLoader(ChevronDown16, {
			part: "trigger-icon",
			class: `cds-custom--header__menu-arrow`
		})}
      </a>
      <ul
        part="menu-body"
        class="${"cds-custom"}--header__menu"
        aria-label="${ifDefined(menuLabel)}">
        <slot></slot>
      </ul>
    `;
	}
	/**
	* A selector that will return the menu items.
	*/
	static get selectorItem() {
		return `cds-custom-header-menu-item`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = header_default;
	}
};
__decorate([query("[part=\"trigger\"]")], CDSHeaderMenu.prototype, "_topMenuItem", void 0);
__decorate([HostListener("keydown")], CDSHeaderMenu.prototype, "_handleKeydownTrigger", null);
__decorate([HostListener("focusout")], CDSHeaderMenu.prototype, "_handleBlur", null);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSHeaderMenu.prototype, "expanded", void 0);
__decorate([property({
	type: Boolean,
	attribute: "is-active",
	reflect: true
})], CDSHeaderMenu.prototype, "isActive", void 0);
__decorate([property({ attribute: "trigger-content" })], CDSHeaderMenu.prototype, "triggerContent", void 0);
__decorate([property({ attribute: "menu-label" })], CDSHeaderMenu.prototype, "menuLabel", void 0);
//#endregion
export { CDSHeaderMenu as default };

//# sourceMappingURL=header-menu.js.map