/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import side_nav_default from "./side-nav.scss.js";
import { LitElement, html } from "lit";
//#region src/components/ui-shell/side-nav-items.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Side nav items.
*
* @element cds-custom-side-nav-items
*/
var CDSSideNavItems = class extends LitElement {
	static {
		this.is = `cds-custom-side-nav-items`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "list");
		super.connectedCallback();
	}
	render() {
		return html`<slot></slot>`;
	}
	static {
		this.styles = side_nav_default;
	}
};
//#endregion
export { CDSSideNavItems as default };

//# sourceMappingURL=side-nav-items.js.map