/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSHeaderNavItem from "./header-nav-item.js";
//#region src/components/ui-shell/header-menu-item.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header submenu item.
*
* @element cds-custom-header-menu-item
*/
var CDSHeaderMenuItem = class extends CDSHeaderNavItem {
	static {
		this.is = `cds-custom-header-menu-item`;
	}
};
//#endregion
export { CDSHeaderMenuItem as default };

//# sourceMappingURL=header-menu-item.js.map