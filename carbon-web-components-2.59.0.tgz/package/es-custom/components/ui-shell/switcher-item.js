/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import header_default from "./header.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/ui-shell/switcher-item.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Switcher menu item.
*
* @element cds-custom-switcher-item
*/
var CDSSwitcherItem = class extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.href = "";
		this.selected = false;
		this.tabIndex = 0;
	}
	static {
		this.is = `cds-custom-switcher-item`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "listitem");
		super.connectedCallback();
	}
	render() {
		const { href, selected, ariaLabel, ariaLabelledBy, tabIndex } = this;
		return html`
      <a
        part="link"
        aria-label="${ariaLabel}"
        aria-labelledby="${ariaLabelledBy}"
        tabindex="${tabIndex}"
        class="${classMap({
			[`cds-custom--switcher__item-link`]: true,
			[`cds-custom--switcher__item-link--selected`]: selected
		})}"
        href="${href}">
        <slot></slot>
      </a>
    `;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = header_default;
	}
};
__decorate([property({
	type: String,
	attribute: "aria-label"
})], CDSSwitcherItem.prototype, "ariaLabel", void 0);
__decorate([property({
	type: String,
	attribute: "aria-labelledby"
})], CDSSwitcherItem.prototype, "ariaLabelledBy", void 0);
__decorate([property()], CDSSwitcherItem.prototype, "href", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSSwitcherItem.prototype, "selected", void 0);
__decorate([property({
	type: Number,
	reflect: true,
	attribute: "tab-index"
})], CDSSwitcherItem.prototype, "tabIndex", void 0);
//#endregion
export { CDSSwitcherItem as default };

//# sourceMappingURL=switcher-item.js.map