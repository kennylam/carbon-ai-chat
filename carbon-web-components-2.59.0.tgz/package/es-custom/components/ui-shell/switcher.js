/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import header_default from "./header.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/ui-shell/switcher.ts
/**
* Copyright IBM Corp. 2023, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Switcher
*
* @element cds-custom-switcher
*/
var CDSSwitcher = class extends LitElement {
	static {
		this.is = `cds-custom-switcher`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "list");
		super.connectedCallback();
	}
	render() {
		return html`<slot></slot>`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = header_default;
	}
};
__decorate([property({
	type: String,
	attribute: "aria-label"
})], CDSSwitcher.prototype, "ariaLabel", void 0);
__decorate([property({
	type: String,
	attribute: "aria-labelledby"
})], CDSSwitcher.prototype, "ariaLabelledBy", void 0);
//#endregion
export { CDSSwitcher as default };

//# sourceMappingURL=switcher.js.map