/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import header_default from "./header.scss.js";
import { LitElement } from "lit";
//#region src/components/ui-shell/switcher-divider.ts
/**
* Copyright IBM Corp. 2023, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* A divider in switcher.
*
* @element cds-custom-switcher-divider
*/
var CDSSwitcherDivider = class extends LitElement {
	static {
		this.is = `cds-custom-switcher-divider`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "separator");
		super.connectedCallback();
	}
	static {
		this.styles = header_default;
	}
};
//#endregion
export { CDSSwitcherDivider as default };

//# sourceMappingURL=switcher-divider.js.map