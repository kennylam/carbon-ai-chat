/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import header_default from "./header.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/ui-shell/header-nav-item.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header nav item.
*
* @element cds-custom-header-nav-item
* @csspart link The link.
* @csspart title The title.
*/
var CDSHeaderNavItem = class extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.isActive = false;
		this.role = "listitem";
	}
	static {
		this.is = `cds-custom-header-nav-item`;
	}
	render() {
		const { ariaCurrent, href, isActive, title, rel, target } = this;
		return html`
      <a
        part="link"
        class="${classMap({
			[`cds-custom--header__menu-item`]: true,
			[`cds-custom--header__menu-item--current`]: isActive && ariaCurrent !== "page"
		})}"
        tabindex="0"
        href="${ifDefined(href)}"
        rel="${ifDefined(rel)}"
        target="${ifDefined(target)}">
        <span part="title" class="${"cds-custom"}--text-truncate--end"
          ><slot>${title}</slot></span
        >
      </a>
    `;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = header_default;
	}
};
__decorate([property()], CDSHeaderNavItem.prototype, "href", void 0);
__decorate([property({ reflect: true })], CDSHeaderNavItem.prototype, "rel", void 0);
__decorate([property({ reflect: true })], CDSHeaderNavItem.prototype, "target", void 0);
__decorate([property()], CDSHeaderNavItem.prototype, "title", void 0);
__decorate([property({
	type: Boolean,
	attribute: "is-active"
})], CDSHeaderNavItem.prototype, "isActive", void 0);
__decorate([property({
	type: String,
	attribute: "aria-current"
})], CDSHeaderNavItem.prototype, "ariaCurrent", void 0);
__decorate([property({ reflect: true })], CDSHeaderNavItem.prototype, "role", void 0);
//#endregion
export { CDSHeaderNavItem as default };

//# sourceMappingURL=header-nav-item.js.map