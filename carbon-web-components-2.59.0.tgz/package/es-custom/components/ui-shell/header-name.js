/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import header_default from "./header.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/ui-shell/header-name.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The product name UI in header nav.
*
* @element cds-custom-header-name
* @csspart link The link.
* @csspart prefix The prefix content.
*/
var CDSHeaderName = class extends FocusMixin(LitElement) {
	static {
		this.is = `cds-custom-header-name`;
	}
	render() {
		const { href, prefix: namePrefix } = this;
		const namePrefixPart = !namePrefix ? void 0 : html`
          <span part="prefix" class="${"cds-custom"}--header__name--prefix"
            >${namePrefix}</span
          >
        `;
		return html`
      <a part="link" class="${"cds-custom"}--header__name" href="${ifDefined(href)}"
        >${namePrefixPart}&nbsp;<span><slot></slot></span
      ></a>
    `;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = header_default;
	}
};
__decorate([property()], CDSHeaderName.prototype, "href", void 0);
__decorate([property()], CDSHeaderName.prototype, "prefix", void 0);
//#endregion
export { CDSHeaderName as default };

//# sourceMappingURL=header-name.js.map