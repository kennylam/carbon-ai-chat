/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import header_default from "./header.scss.js";
import { LitElement, html } from "lit";
//#region src/components/ui-shell/header.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header.
*
* @element cds-custom-header
*/
var CDSHeader = class extends LitElement {
	static {
		this.is = `cds-custom-header`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "banner");
		super.connectedCallback();
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = header_default;
	}
};
//#endregion
export { CDSHeader as default };

//# sourceMappingURL=header.js.map