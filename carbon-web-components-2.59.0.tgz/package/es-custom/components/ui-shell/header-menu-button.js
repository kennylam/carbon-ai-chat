/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import FocusMixin from "../../globals/mixins/focus.js";
import header_default from "./header.scss.js";
import "./defs.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
import Close16 from "@carbon/icons/es/close/16.js";
import Menu16 from "@carbon/icons/es/menu/16.js";
//#region src/components/ui-shell/header-menu-button.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The trigger button for side nav in header nav.
*
* @element cds-custom-header-menu-button
* @csspart button The button.
* @csspart toggle-icon The toggle icon.
* @fires cds-custom-header-menu-button-toggled - The custom event fired after this header menu button is toggled upon a user gesture.
*/
var CDSHeaderMenuButton = class extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.active = false;
		this.buttonLabelActive = "Close navigation menu";
		this.buttonLabelInactive = "Open navigation menu";
		this.collapseMode = "responsive";
		this.disabled = false;
		this.isNotChildOfHeader = false;
	}
	static {
		this.is = `cds-custom-header-menu-button`;
	}
	_handleClick() {
		const active = !this.active;
		this.active = active;
		this.dispatchEvent(new CustomEvent(this.constructor.eventToggle, {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { active }
		}));
	}
	render() {
		const { active, buttonLabelActive, buttonLabelInactive, disabled, _handleClick: handleClick } = this;
		const buttonLabel = active ? buttonLabelActive : buttonLabelInactive;
		return html`
      <button
        part="button"
        class="${classMap({
			[`cds-custom--header__action`]: true,
			[`cds-custom--header__menu-trigger`]: true,
			[`cds-custom--header__menu-toggle`]: true,
			[`cds-custom--header__action--active`]: active
		})}"
        ?disabled=${disabled}
        aria-label="${ifDefined(buttonLabel)}"
        @click=${handleClick}>
        ${iconLoader(active ? Close16 : Menu16, { part: "toggle-icon" })}
      </button>
    `;
	}
	/**
	* The name of the custom event fired after this header menu button is toggled upon a user gesture.
	*/
	static get eventToggle() {
		return `cds-custom-header-menu-button-toggled`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = header_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSHeaderMenuButton.prototype, "active", void 0);
__decorate([property({ attribute: "button-label-active" })], CDSHeaderMenuButton.prototype, "buttonLabelActive", void 0);
__decorate([property({ attribute: "button-label-inactive" })], CDSHeaderMenuButton.prototype, "buttonLabelInactive", void 0);
__decorate([property({
	reflect: true,
	attribute: "collapse-mode"
})], CDSHeaderMenuButton.prototype, "collapseMode", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSHeaderMenuButton.prototype, "disabled", void 0);
__decorate([property({
	type: Boolean,
	attribute: "is-not-child-of-header"
})], CDSHeaderMenuButton.prototype, "isNotChildOfHeader", void 0);
//#endregion
export { CDSHeaderMenuButton as default };

//# sourceMappingURL=header-menu-button.js.map