/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import header_default from "./header.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/ui-shell/header-panel.ts
/**
* Copyright IBM Corp. 2023, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header panel
*
* @element cds-custom-header-panel
*/
var CDSHeaderPanel = class extends LitElement {
	static {
		this.is = `cds-custom-header-panel`;
	}
	render() {
		return html`<slot></slot>`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = header_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSHeaderPanel.prototype, "expanded", void 0);
//#endregion
export { CDSHeaderPanel as default };

//# sourceMappingURL=header-panel.js.map