/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import side_nav_default from "./side-nav.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/ui-shell/side-nav-menu-item.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Side nav menu item.
*
* @element cds-custom-side-nav-menu-item
* @csspart link The link.
* @csspart title The title.
*/
var CDSSideNavMenuItem = class extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.active = false;
		this.href = "";
	}
	static {
		this.is = `cds-custom-side-nav-menu-item`;
	}
	shouldUpdate(changedProperties) {
		if (changedProperties.has("active") && this.active) {
			const { selectorMenu } = this.constructor;
			const parent = this.closest(selectorMenu);
			if (parent) parent.active = true;
		}
		return true;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "button");
		super.connectedCallback();
	}
	render() {
		const { active, href, target, title } = this;
		return html`
      <a
        part="link"
        class="${classMap({
			[`cds-custom--side-nav__link`]: true,
			[`cds-custom--side-nav__link--current`]: active
		})}"
        href="${href}"
        target="${ifDefined(target)}">
        <span part="title" class="${"cds-custom"}--side-nav__link-text">
          <slot>${title}</slot>
        </span>
      </a>
    `;
	}
	/**
	* A selector that will return the parent menu.
	*/
	static get selectorMenu() {
		return `cds-custom-side-nav-menu`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = side_nav_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSSideNavMenuItem.prototype, "active", void 0);
__decorate([property()], CDSSideNavMenuItem.prototype, "href", void 0);
__decorate([property({ reflect: true })], CDSSideNavMenuItem.prototype, "target", void 0);
__decorate([property()], CDSSideNavMenuItem.prototype, "title", void 0);
//#endregion
export { CDSSideNavMenuItem as default };

//# sourceMappingURL=side-nav-menu-item.js.map