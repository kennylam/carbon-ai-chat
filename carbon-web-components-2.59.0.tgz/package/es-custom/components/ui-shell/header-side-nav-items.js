/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import side_nav_default from "./side-nav.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/ui-shell/header-side-nav-items.ts
/**
* Copyright IBM Corp. 2023, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Header Side Nav Items section
*
* @element cds-custom-header-side-nav-items
*/
var CDSHeaderSideNavItems = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hasDivider = false;
	}
	static {
		this.is = `cds-custom-header-side-nav-items`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "list");
		super.connectedCallback();
	}
	render() {
		return html`<slot></slot>`;
	}
	static {
		this.styles = side_nav_default;
	}
};
__decorate([property({
	type: Boolean,
	attribute: "has-divider"
})], CDSHeaderSideNavItems.prototype, "hasDivider", void 0);
//#endregion
export { CDSHeaderSideNavItems as default };

//# sourceMappingURL=header-side-nav-items.js.map