/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSSelectSkeleton from "../select/select-skeleton.js";
import fluid_select_default from "./fluid-select.scss.js";
import { html } from "lit";
//#region src/components/fluid-select/fluid-select-skeleton.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text area input.
*
* @element cds-custom-fluid-select-skeleton
*/
var CDSFluidSelectSkeleton = class extends CDSSelectSkeleton {
	static {
		this.is = `cds-custom-fluid-select-skeleton`;
	}
	render() {
		return html`
      <div class="${"cds-custom"}--select--fluid__skeleton">${super.render()}</div>
    `;
	}
	static {
		this.styles = [CDSSelectSkeleton.styles, fluid_select_default];
	}
};
//#endregion
export { CDSFluidSelectSkeleton as default };

//# sourceMappingURL=fluid-select-skeleton.js.map