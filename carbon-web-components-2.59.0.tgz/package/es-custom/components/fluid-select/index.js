/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import "../select/index.js";
import CDSFluidSelect from "./fluid-select.js";
import CDSFluidSelectSkeleton from "./fluid-select-skeleton.js";
//#region src/components/fluid-select/index.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFluidSelect);
defineCustomElement(CDSFluidSelectSkeleton);
//#endregion
export { CDSFluidSelect, CDSFluidSelectSkeleton };

//# sourceMappingURL=index.js.map