/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/breadcrumb/defs.ts
/**
* Copyright IBM Corp. 2020, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Breadcrumb size.
*/
let BREADCRUMB_SIZE = /* @__PURE__ */ function(BREADCRUMB_SIZE) {
	/**
	* Small size.
	*/
	BREADCRUMB_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	BREADCRUMB_SIZE["MEDIUM"] = "md";
	return BREADCRUMB_SIZE;
}({});
//#endregion
export { BREADCRUMB_SIZE };

//# sourceMappingURL=defs.js.map