/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import overflow_menu_default from "../overflow-menu/overflow-menu.scss.js";
import CDSOverflowMenu from "../overflow-menu/overflow-menu.js";
import breadcrumb_default from "./breadcrumb.scss.js";
import { adoptStyles, html } from "lit";
import OverflowMenuHorizontal16 from "@carbon/icons/es/overflow-menu--horizontal/16.js";
//#region src/components/breadcrumb/breadcrumb-overflow-menu.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Overflow menu in breadcrumb.
*
* @deprecated use `cds-custom-overflow-menu` instead with the `breadcrumb` property
*
* @element cds-custom-breadcrumb-overflow-menu
*/
var CDSBreadcrumbOverflowMenu = class extends CDSOverflowMenu {
	static {
		this.is = `cds-custom-breadcrumb-overflow-menu`;
	}
	connectedCallback() {
		super.connectedCallback();
		adoptStyles(this.renderRoot, [overflow_menu_default, breadcrumb_default]);
	}
	render() {
		return html`
      <slot name="icon">
        ${iconLoader(OverflowMenuHorizontal16, {
			class: `cds-custom--overflow-menu__icon`,
			slot: "icon"
		})}
      </slot>
    `;
	}
};
//#endregion
export { CDSBreadcrumbOverflowMenu as default };

//# sourceMappingURL=breadcrumb-overflow-menu.js.map