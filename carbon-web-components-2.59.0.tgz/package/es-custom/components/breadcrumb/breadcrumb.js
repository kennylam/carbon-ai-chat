/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import { BREADCRUMB_SIZE } from "./defs.js";
import breadcrumb_default from "./breadcrumb.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/breadcrumb/breadcrumb.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Breadcrumb.
*
* @element cds-custom-breadcrumb
*/
var CDSBreadcrumb = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.noTrailingSlash = false;
		this.size = "md";
	}
	static {
		this.is = `cds-custom-breadcrumb`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		target.assignedNodes().filter((node) => node.nodeType !== Node.TEXT_NODE || node.textContent.trim()).forEach((item) => {
			item.setAttribute("size", this.size);
		});
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "navigation");
		if (!this.hasAttribute("aria-label")) this.setAttribute("aria-label", "Breadcrumb");
		super.connectedCallback();
	}
	updated(changedProperties) {
		if (changedProperties.has("size")) this.querySelectorAll(`cds-custom-breadcrumb-item`)?.forEach((item) => {
			item.querySelector(`cds-custom-breadcrumb-link`)?.setAttribute("size", this.size);
		});
	}
	render() {
		return html`
      <ol class="${classMap({
			[`cds-custom--breadcrumb`]: true,
			[`cds-custom--breadcrumb--no-trailing-slash`]: this.noTrailingSlash,
			[`cds-custom--breadcrumb--sm`]: this.size === "sm"
		})}">
        <slot @slotchange="${this._handleSlotChange}"></slot>
      </ol>
    `;
	}
	static {
		this.styles = breadcrumb_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "no-trailing-slash"
})], CDSBreadcrumb.prototype, "noTrailingSlash", void 0);
__decorate([property({
	type: BREADCRUMB_SIZE,
	reflect: true
})], CDSBreadcrumb.prototype, "size", void 0);
//#endregion
export { CDSBreadcrumb as default };

//# sourceMappingURL=breadcrumb.js.map