/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../link/index.js";
import "../overflow-menu/index.js";
import CDSBreadcrumb from "./breadcrumb.js";
import CDSBreadcrumbItem from "./breadcrumb-item.js";
import CDSBreadcrumbLink from "./breadcrumb-link.js";
import CDSBreadcrumbOverflowMenu from "./breadcrumb-overflow-menu.js";
import CDSBreadcrumbSkeleton from "./breadcrumb-skeleton.js";
//#region src/components/breadcrumb/index.ts
/**
* Copyright IBM Corp. 2021, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSBreadcrumb);
defineCustomElement(CDSBreadcrumbItem);
defineCustomElement(CDSBreadcrumbLink);
defineCustomElement(CDSBreadcrumbOverflowMenu);
defineCustomElement(CDSBreadcrumbSkeleton);
//#endregion
export { CDSBreadcrumb, CDSBreadcrumbItem, CDSBreadcrumbLink, CDSBreadcrumbOverflowMenu, CDSBreadcrumbSkeleton };

//# sourceMappingURL=index.js.map