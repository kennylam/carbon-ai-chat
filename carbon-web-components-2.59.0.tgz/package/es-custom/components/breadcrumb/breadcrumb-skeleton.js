/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import { BREADCRUMB_SIZE } from "./defs.js";
import breadcrumb_default from "./breadcrumb.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/breadcrumb/breadcrumb-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const renderItem = () => {
	return html`
    <div class="${"cds-custom"}--breadcrumb-item">
      <span class="${"cds-custom"}--link">&nbsp;</span>
    </div>
  `;
};
/**
* Skeleton of breadcrumb.
*/
var CDSBreadcrumbSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.items = 3;
		this.noTrailingSlash = false;
		this.size = "md";
	}
	static {
		this.is = `cds-custom-breadcrumb-skeleton`;
	}
	render() {
		return html`
      <div class="${classMap({
			[`cds-custom--breadcrumb`]: true,
			[`cds-custom--skeleton`]: true,
			[`cds-custom--breadcrumb--no-trailing-slash`]: this.noTrailingSlash,
			[`cds-custom--breadcrumb--sm`]: this.size === "sm"
		})}">
        ${[...Array(this.items)].map(() => renderItem())}
      </div>
    `;
	}
	static {
		this.styles = breadcrumb_default;
	}
};
__decorate([property({
	type: Number,
	reflect: true
})], CDSBreadcrumbSkeleton.prototype, "items", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "no-trailing-slash"
})], CDSBreadcrumbSkeleton.prototype, "noTrailingSlash", void 0);
__decorate([property({
	type: BREADCRUMB_SIZE,
	reflect: true
})], CDSBreadcrumbSkeleton.prototype, "size", void 0);
//#endregion
export { CDSBreadcrumbSkeleton as default };

//# sourceMappingURL=breadcrumb-skeleton.js.map