/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import breadcrumb_default from "./breadcrumb.scss.js";
import { LitElement, html } from "lit";
//#region src/components/breadcrumb/breadcrumb-item.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Breadcrumb item.
*
* @element cds-custom-breadcrumb-item
*/
var CDSBreadcrumbItem = class extends LitElement {
	static {
		this.is = `cds-custom-breadcrumb-item`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		target.assignedNodes().filter((node) => node.nodeType === Node.ELEMENT_NODE && node.tagName.toLowerCase() === `cds-custom-overflow-menu`).forEach((item) => {
			if (this.getAttribute("size")) item.setAttribute("breadcrumb-size", this.getAttribute("size"));
			const overflowMenuBody = item.querySelector(`cds-custom-overflow-menu-body`);
			if (overflowMenuBody) overflowMenuBody.menuOffset = {
				top: 10,
				left: 59
			};
		});
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "listitem");
		super.connectedCallback();
	}
	render() {
		return html` <slot @slotchange=${this._handleSlotChange}></slot> `;
	}
	static {
		this.styles = breadcrumb_default;
	}
};
//#endregion
export { CDSBreadcrumbItem as default };

//# sourceMappingURL=breadcrumb-item.js.map