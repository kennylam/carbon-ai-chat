/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/pagination-nav/defs.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Size of the pagination nav.
*/
let PAGINATION_NAV_SIZE = /* @__PURE__ */ function(PAGINATION_NAV_SIZE) {
	/**
	* Small size.
	*/
	PAGINATION_NAV_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	PAGINATION_NAV_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	PAGINATION_NAV_SIZE["LARGE"] = "lg";
	return PAGINATION_NAV_SIZE;
}({});
/**
* Prev/Next button tooltip alignment.
*/
let PAGINATION_TOOLTIP_ALIGNMENT = /* @__PURE__ */ function(PAGINATION_TOOLTIP_ALIGNMENT) {
	/**
	* Aligned to the start.
	*/
	PAGINATION_TOOLTIP_ALIGNMENT["START"] = "start";
	/**
	* Aligned to the center.
	*/
	PAGINATION_TOOLTIP_ALIGNMENT["CENTER"] = "center";
	/**
	* Aligned to the end.
	*/
	PAGINATION_TOOLTIP_ALIGNMENT["END"] = "end";
	return PAGINATION_TOOLTIP_ALIGNMENT;
}({});
/**
* Prev/Next button tooltip position.
*/
let PAGINATION_TOOLTIP_POSITION = /* @__PURE__ */ function(PAGINATION_TOOLTIP_POSITION) {
	/**
	* Positioned on the top.
	*/
	PAGINATION_TOOLTIP_POSITION["TOP"] = "top";
	/**
	* Positioned on the right.
	*/
	PAGINATION_TOOLTIP_POSITION["RIGHT"] = "right";
	/**
	* Positioned on the bottom.
	*/
	PAGINATION_TOOLTIP_POSITION["BOTTOM"] = "bottom";
	/**
	* Positioned on the left.
	*/
	PAGINATION_TOOLTIP_POSITION["LEFT"] = "left";
	return PAGINATION_TOOLTIP_POSITION;
}({});
//#endregion
export { PAGINATION_NAV_SIZE, PAGINATION_TOOLTIP_ALIGNMENT, PAGINATION_TOOLTIP_POSITION };

//# sourceMappingURL=defs.js.map