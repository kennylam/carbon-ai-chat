/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSPaginationNav from "./pagination-nav.js";
//#region src/components/pagination-nav/index.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSPaginationNav);
//#endregion
export { CDSPaginationNav };

//# sourceMappingURL=index.js.map