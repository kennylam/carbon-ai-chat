/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import dialog_default from "./dialog.scss.js";
import { LitElement, html } from "lit";
//#region src/components/dialog/dialog-header.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog header.
*
* @element cds-custom-dialog-header
*/
var CDSDialogHeader = class extends LitElement {
	static {
		this.is = `cds-custom-dialog-header`;
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = dialog_default;
	}
};
//#endregion
export { CDSDialogHeader as default };

//# sourceMappingURL=dialog-header.js.map