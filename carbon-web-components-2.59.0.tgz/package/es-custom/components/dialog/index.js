/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../icon-button/index.js";
import CDSDialog from "./dialog.js";
import "../modal/index.js";
import CDSDialogHeader from "./dialog-header.js";
import CDSDialogControls from "./dialog-controls.js";
import CDSDialogCloseButton from "./dialog-close-button.js";
import CDSDialogTitle from "./dialog-title.js";
import CDSDialogSubtitle from "./dialog-subtitle.js";
import CDSDialogBody from "./dialog-body.js";
import CDSDialogFooter from "./dialog-footer.js";
import CDSDialogFooterButton from "./dialog-footer-button.js";
//#region src/components/dialog/index.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSDialog);
defineCustomElement(CDSDialogHeader);
defineCustomElement(CDSDialogControls);
defineCustomElement(CDSDialogCloseButton);
defineCustomElement(CDSDialogTitle);
defineCustomElement(CDSDialogSubtitle);
defineCustomElement(CDSDialogBody);
defineCustomElement(CDSDialogFooter);
defineCustomElement(CDSDialogFooterButton);
//#endregion
export { CDSDialog, CDSDialogBody, CDSDialogCloseButton, CDSDialogControls, CDSDialogFooter, CDSDialogFooterButton, CDSDialogHeader, CDSDialogSubtitle, CDSDialogTitle };

//# sourceMappingURL=index.js.map