/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListener from "../../globals/decorators/host-listener.js";
import { CDSModalBase } from "../modal/modal-base.js";
import dialog_default from "./dialog.scss.js";
import { html } from "lit";
import { property, query } from "lit/decorators.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/dialog/dialog.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog.
*
* @see This component is in {@link https://web-components.carbondesignsystem.com/?path=/docs/preview-about-preview--about-preview|preview status}
*
* @element cds-custom-dialog
* @fires cds-custom-dialog-beingclosed
*   The custom event fired before this dialog is being closed upon a user gesture.
*   Cancellation of this event stops the user-initiated action of closing this dialog.
* @fires cds-custom-dialog-closed - The custom event fired after this dialog is closed upon a user gesture.
*/
var CDSDialog = class extends CDSModalBase {
	constructor(..._args) {
		super(..._args);
		this._handleClick = (event) => {
			if (this.open && this.modal && event.composedPath()[0] === this._dialogElement && !this.preventCloseOnClickOutside) this._handleUserInitiatedClose(event.target);
		};
		this.modal = true;
		this.ariaLabel = null;
		this.ariaLabelledBy = null;
		this.ariaDescribedBy = null;
		this.role = "dialog";
		this.preventCloseOnClickOutside = false;
		this._handleKeydown = (event) => {
			const { key, target } = event;
			if (!this.modal || !this.open) return;
			if (key === "Esc" || key === "Escape") {
				event.preventDefault();
				this._handleUserInitiatedClose(target);
			}
		};
	}
	static {
		this.is = `cds-custom-dialog`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange() {
		if (this.querySelector(`cds-custom-dialog-footer`)) this.setAttribute("has-footer", "");
		else this.removeAttribute("has-footer");
		this.requestUpdate();
	}
	/**
	* Observes the dialog footer's `has-three-buttons` attribute to account for cases
	* where the loading status and the amount of footer-buttons
	* are being changed dynamically
	*/
	_observeFooter() {
		const footer = this.querySelector(`cds-custom-dialog-footer`);
		if (!footer) return;
		this._footerObserver = new MutationObserver(() => {
			this._updateLoadingElement();
		});
		this._footerObserver.observe(footer, {
			attributes: true,
			childList: true,
			attributeFilter: ["has-three-buttons"]
		});
	}
	connectedCallback() {
		super.connectedCallback?.();
		this._observeFooter();
	}
	disconnectedCallback() {
		this._footerObserver?.disconnect();
		super.disconnectedCallback?.();
	}
	/**
	* Gets footer elements.
	*/
	_getFooterElements() {
		return {
			footer: this.querySelector(`cds-custom-dialog-footer`),
			primaryButton: this.querySelector(`cds-custom-dialog-footer-button[kind="primary"]`) || this.querySelector(`cds-custom-dialog-footer-button[kind="danger"]`) || null,
			secondaryButtons: Array.from(this.querySelectorAll(`cds-custom-dialog-footer-button[kind="secondary"]`))
		};
	}
	async updated(changedProperties) {
		if (changedProperties.has("open")) if (this.open) {
			this._launcher = this.ownerDocument.activeElement;
			if (this._dialogElement && !this.ariaLabel && !this.ariaLabelledBy) {
				const title = this.querySelector(`cds-custom-dialog-title`);
				if (title && title.id) this._dialogElement.setAttribute("aria-labelledby", title.id);
			}
			if (this._dialogElement) if (this.modal) this._dialogElement.showModal();
			else this._dialogElement.show();
			if (!this.hasAttribute("modal-controlled")) {
				const primaryFocusNode = this.querySelector(this.constructor.selectorPrimaryFocus);
				await this.constructor._delay();
				if (primaryFocusNode) primaryFocusNode.focus();
				else {
					const { primaryButton, secondaryButtons } = this._getFooterElements();
					if (primaryButton && primaryButton?.getAttribute("kind") === "danger" && secondaryButtons[0]) secondaryButtons[0].focus();
					else {
						const closeButton = this.querySelector(this.constructor.selectorCloseButton);
						if (closeButton) closeButton.focus();
						else {
							const { first } = this.getFocusable();
							first?.focus();
						}
					}
				}
			}
		} else {
			if (this._dialogElement && this._dialogElement.open) this._dialogElement.close();
			if (this._launcher && typeof this._launcher.focus === "function") {
				this._launcher.focus();
				this._launcher = null;
			}
		}
		if (changedProperties.has("loadingStatus") || changedProperties.has("loadingDescription") || changedProperties.has("loadingSuccessDelay") || changedProperties.has("loadingIconDescription")) {
			await this.constructor._delay();
			this._updateLoadingElement();
		}
	}
	render() {
		const { ariaLabel, ariaLabelledBy, ariaDescribedBy, role } = this;
		const title = this.querySelector(`cds-custom-dialog-title`);
		return html`
      <dialog
        part="dialog"
        class="${"cds-custom"}--dialog"
        role=${role}
        aria-label=${ifDefined(ariaLabel || void 0)}
        aria-labelledby=${ifDefined(ariaLabelledBy || (!ariaLabel ? title?.id : void 0))}
        aria-describedby=${ifDefined(ariaDescribedBy || void 0)}>
        <div
          class="${"cds-custom"}--dialog-container"
          @click=${this._handleClickContainer}>
          <slot @slotchange="${this._handleSlotChange}"></slot>
        </div>
      </dialog>
    `;
	}
	/**
	* A selector selecting buttons that should close this dialog.
	*/
	static get selectorCloseButton() {
		return `[data-dialog-close],cds-custom-dialog-close-button,[data-modal-close],cds-custom-modal-close-button`;
	}
	/**
	* A selector selecting the nodes that should be focused when dialog gets open.
	*/
	static get selectorPrimaryFocus() {
		return `[data-dialog-primary-focus]`;
	}
	/**
	* A selector selecting the dialog body component
	*/
	static get selectorModalBody() {
		return `cds-custom-dialog-body`;
	}
	/**
	* The name of the custom event fired before this dialog is being closed upon a user gesture.
	* Cancellation of this event stops the user-initiated action of closing this dialog.
	*/
	static get eventBeforeClose() {
		return `cds-custom-dialog-beingclosed`;
	}
	/**
	* The name of the custom event fired after this dialog is closed upon a user gesture.
	*/
	static get eventClose() {
		return `cds-custom-dialog-closed`;
	}
	/**
	* The name of the custom event fired when this modal reaches a `finished` loading state
	*/
	static get eventOnLoadingSuccess() {
		return `cds-custom-dialog-on-loadingsuccess`;
	}
	static {
		this.styles = dialog_default;
	}
};
__decorate([query("dialog")], CDSDialog.prototype, "_dialogElement", void 0);
__decorate([HostListener("click")], CDSDialog.prototype, "_handleClick", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSDialog.prototype, "modal", void 0);
__decorate([property({ attribute: "aria-label" })], CDSDialog.prototype, "ariaLabel", void 0);
__decorate([property({ attribute: "aria-labelledby" })], CDSDialog.prototype, "ariaLabelledBy", void 0);
__decorate([property({ attribute: "aria-describedby" })], CDSDialog.prototype, "ariaDescribedBy", void 0);
__decorate([property({ reflect: true })], CDSDialog.prototype, "role", void 0);
__decorate([property({
	type: Boolean,
	attribute: "prevent-close-on-click-outside"
})], CDSDialog.prototype, "preventCloseOnClickOutside", void 0);
__decorate([HostListener("document:keydown")], CDSDialog.prototype, "_handleKeydown", void 0);
//#endregion
export { CDSDialog as default };

//# sourceMappingURL=dialog.js.map