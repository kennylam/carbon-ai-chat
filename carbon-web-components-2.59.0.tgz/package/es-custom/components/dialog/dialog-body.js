/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import dialog_default from "./dialog.scss.js";
import CDSModalBody from "../modal/modal-body.js";
//#region src/components/dialog/dialog-body.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog body.
*
* @element cds-custom-dialog-body
*/
var CDSDialogBody = class extends CDSModalBody {
	static {
		this.is = `cds-custom-dialog-body`;
	}
	_getAriaLabelledBy() {
		const dialog = this.closest(`cds-custom-dialog`);
		if (!dialog) return null;
		const subTitleEl = dialog.querySelector(`cds-custom-dialog-subtitle`);
		if (subTitleEl?.id) return subTitleEl.id;
		const titleEl = dialog.querySelector(`cds-custom-dialog-title`);
		if (titleEl?.id) return titleEl.id;
		return null;
	}
	_parentHasScrollingContent() {
		return this.closest(`cds-custom-dialog`)?.hasAttribute("has-scrolling-content") ?? false;
	}
	static {
		this.styles = dialog_default;
	}
};
//#endregion
export { CDSDialogBody as default };

//# sourceMappingURL=dialog-body.js.map