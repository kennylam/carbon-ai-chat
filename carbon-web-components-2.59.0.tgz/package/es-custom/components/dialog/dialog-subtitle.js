/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import dialog_default from "./dialog.scss.js";
import CDSModalLabel from "../modal/modal-label.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/dialog/dialog-subtitle.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog subtitle.
*
* @element cds-custom-dialog-subtitle
*/
var CDSDialogSubtitle = class extends CDSModalLabel {
	constructor(..._args) {
		super(..._args);
		this.id = `cds-custom--dialog-subtitle--id-${Math.random().toString(16).slice(2)}`;
	}
	static {
		this.is = `cds-custom-dialog-subtitle`;
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = dialog_default;
	}
};
__decorate([property({
	type: String,
	reflect: true
})], CDSDialogSubtitle.prototype, "id", void 0);
//#endregion
export { CDSDialogSubtitle as default };

//# sourceMappingURL=dialog-subtitle.js.map