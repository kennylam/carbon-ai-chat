/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import dialog_default from "./dialog.scss.js";
import CDSModalFooter from "../modal/modal-footer.js";
//#region src/components/dialog/dialog-footer.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog footer.
*
* @element cds-custom-dialog-footer
*/
var CDSDialogFooter = class extends CDSModalFooter {
	static {
		this.is = `cds-custom-dialog-footer`;
	}
	/**
	* A selector that selects the child buttons.
	*/
	static get selectorButtons() {
		return `cds-custom-button,cds-custom-dialog-footer-button`;
	}
	static {
		this.styles = dialog_default;
	}
};
//#endregion
export { CDSDialogFooter as default };

//# sourceMappingURL=dialog-footer.js.map