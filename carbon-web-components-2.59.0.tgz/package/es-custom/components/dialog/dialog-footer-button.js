/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import button_default from "../button/button.scss.js";
import CDSButton from "../button/button.js";
import dialog_default from "./dialog.scss.js";
//#region src/components/dialog/dialog-footer-button.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Dialog footer button.
*
* @element cds-custom-dialog-footer-button
*/
var CDSDialogFooterButton = class extends CDSButton {
	static {
		this.is = `cds-custom-dialog-footer-button`;
	}
	static {
		this.styles = [button_default, dialog_default];
	}
};
//#endregion
export { CDSDialogFooterButton as default };

//# sourceMappingURL=dialog-footer-button.js.map