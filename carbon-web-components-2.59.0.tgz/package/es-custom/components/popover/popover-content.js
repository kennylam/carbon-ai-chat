/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import "./defs.js";
import popover_default from "./popover.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/popover/popover-content.ts
/**
* Copyright IBM Corp. 2019, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Popover.
*
* @element cds-custom-popover-content
*/
var CDSPopoverContent = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.align = "";
		this.autoalign = false;
		this.dropShadow = true;
		this.border = false;
		this.highContrast = false;
		this.open = false;
		this.tabTip = false;
		this.backgroundToken = "layer";
		this.slot = "content";
	}
	static {
		this.is = `cds-custom-popover-content`;
	}
	render() {
		return html`
      <span class="${"cds-custom"}--popover">
        <span class="${"cds-custom"}--popover-content" part="content" tabindex="-1">
          <slot> </slot>
          ${this.autoalign ? html`<span
                class="${"cds-custom"}--popover-caret ${"cds-custom"}--popover--auto-align"></span>` : null}
        </span>
        ${!this.autoalign ? html`<span class="${"cds-custom"}--popover-caret"></span>` : null}
      </span>
    `;
	}
	static {
		this.styles = popover_default;
	}
};
__decorate([property({
	reflect: true,
	type: String
})], CDSPopoverContent.prototype, "align", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSPopoverContent.prototype, "autoalign", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSPopoverContent.prototype, "caret", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSPopoverContent.prototype, "dropShadow", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSPopoverContent.prototype, "border", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSPopoverContent.prototype, "highContrast", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSPopoverContent.prototype, "open", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSPopoverContent.prototype, "tabTip", void 0);
__decorate([property({
	reflect: true,
	type: String
})], CDSPopoverContent.prototype, "backgroundToken", void 0);
__decorate([property({ reflect: true })], CDSPopoverContent.prototype, "slot", void 0);
//#endregion
export { CDSPopoverContent as default };

//# sourceMappingURL=popover-content.js.map