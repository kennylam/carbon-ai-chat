/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSPopover from "./popover.js";
import CDSPopoverContent from "./popover-content.js";
//#region src/components/popover/index.ts
/**
* Copyright IBM Corp. 2021, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSPopover);
defineCustomElement(CDSPopoverContent);
//#endregion
export { CDSPopover, CDSPopoverContent };

//# sourceMappingURL=index.js.map