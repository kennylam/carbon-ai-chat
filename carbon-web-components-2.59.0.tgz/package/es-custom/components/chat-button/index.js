/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../button/index.js";
import CDSChatButton from "./chat-button.js";
import CDSChatButtonSkeleton from "./chat-button-skeleton.js";
//#region src/components/chat-button/index.ts
/**
* Copyright IBM Corp. 2021, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSChatButton);
defineCustomElement(CDSChatButtonSkeleton);
//#endregion
export { CDSChatButton, CDSChatButtonSkeleton };

//# sourceMappingURL=index.js.map