/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/chat-button/defs.ts
/**
* Copyright IBM Corp. 2020, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Chat Button size.
*/
let CHAT_BUTTON_SIZE = /* @__PURE__ */ function(CHAT_BUTTON_SIZE) {
	/**
	* Small size.
	*/
	CHAT_BUTTON_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	CHAT_BUTTON_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	CHAT_BUTTON_SIZE["LARGE"] = "lg";
	return CHAT_BUTTON_SIZE;
}({});
/**
* Chat button kind.
*/
let CHAT_BUTTON_KIND = /* @__PURE__ */ function(CHAT_BUTTON_KIND) {
	/**
	* Primary button.
	*/
	CHAT_BUTTON_KIND["PRIMARY"] = "primary";
	/**
	* Secondary button.
	*/
	CHAT_BUTTON_KIND["SECONDARY"] = "secondary";
	/**
	* Tertiary button.
	*/
	CHAT_BUTTON_KIND["TERTIARY"] = "tertiary";
	/**
	* Ghost button.
	*/
	CHAT_BUTTON_KIND["GHOST"] = "ghost";
	/**
	* Danger button.
	*/
	CHAT_BUTTON_KIND["DANGER"] = "danger";
	return CHAT_BUTTON_KIND;
}({});
//#endregion
export { CHAT_BUTTON_KIND, CHAT_BUTTON_SIZE };

//# sourceMappingURL=defs.js.map