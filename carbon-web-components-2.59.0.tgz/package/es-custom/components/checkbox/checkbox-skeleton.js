/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import checkbox_default from "./checkbox.scss.js";
import { LitElement, html } from "lit";
//#region src/components/checkbox/checkbox-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of number input.
*/
var CDSCheckboxSkeleton = class extends LitElement {
	static {
		this.is = `cds-custom-checkbox-skeleton`;
	}
	render() {
		return html`
      <label class="${"cds-custom"}--checkbox-label" for="checkbox" part="label">
        <span class="${"cds-custom"}--checkbox-label-text ${"cds-custom"}--skeleton"
          ><slot></slot
        ></span>
      </label>
    `;
	}
	static {
		this.styles = checkbox_default;
	}
};
//#endregion
export { CDSCheckboxSkeleton as default };

//# sourceMappingURL=checkbox-skeleton.js.map