/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSCheckbox from "./checkbox.js";
import CDSCheckboxGroup from "./checkbox-group.js";
import CDSCheckboxSkeleton from "./checkbox-skeleton.js";
//#region src/components/checkbox/index.ts
/**
* Copyright IBM Corp. 2021, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSCheckbox);
defineCustomElement(CDSCheckboxGroup);
defineCustomElement(CDSCheckboxSkeleton);
//#endregion
export { CDSCheckbox, CDSCheckboxGroup, CDSCheckboxSkeleton };

//# sourceMappingURL=index.js.map