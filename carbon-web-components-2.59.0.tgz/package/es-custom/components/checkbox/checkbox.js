/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import FocusMixin from "../../globals/mixins/focus.js";
import FormMixin from "../../globals/mixins/form.js";
import checkbox_default from "./checkbox.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
import WarningFilled16 from "@carbon/icons/es/warning--filled/16.js";
import WarningAltFilled16 from "@carbon/icons/es/warning--alt--filled/16.js";
//#region src/components/checkbox/checkbox.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Check box.
*
* @element cds-custom-checkbox
* @fires cds-custom-checkbox-changed - The custom event fired after this changebox changes its checked state.
* @csspart input The checkbox.
* @csspart label The label.
*/
var CDSCheckbox = class extends FocusMixin(FormMixin(LitElement)) {
	constructor(..._args) {
		super(..._args);
		this.checked = false;
		this.dataTable = false;
		this.disabled = false;
		this.hideCheckbox = false;
		this.hideLabel = false;
		this.id = "checkbox";
		this.indeterminate = false;
		this.labelText = "";
		this.readonly = false;
		this.invalid = false;
		this.title = "";
		this.warn = false;
		this.warnText = false;
		this._hasAILabel = false;
	}
	static {
		this.is = `cds-custom-checkbox`;
	}
	/**
	* Handles `click` event on the `<input>` in the shadow DOM.
	*/
	_handleChange() {
		const { checked, indeterminate } = this._checkboxNode;
		this.checked = checked;
		this.indeterminate = indeterminate;
		const { eventChange } = this.constructor;
		this.dispatchEvent(new CustomEvent(eventChange, {
			bubbles: true,
			composed: true,
			detail: {
				checked,
				indeterminate
			}
		}));
	}
	/**
	* Prevent checkbox state from updating when readonly
	*/
	_handleClick(event) {
		if (this.readonly) event.preventDefault();
	}
	_handleFormdata(event) {
		const { formData } = event;
		const { checked, disabled, name, value = "on" } = this;
		if (!disabled && checked) formData.append(name, value);
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		const hasContent = target.assignedNodes().filter((elem) => elem.matches !== void 0 ? elem.matches(this.constructor.aiLabelItem) || elem.matches(this.constructor.slugItem) : false);
		this._hasAILabel = Boolean(hasContent);
		const type = hasContent[0].getAttribute("kind");
		hasContent[0].setAttribute("size", type === "inline" ? "md" : "mini");
		this.requestUpdate();
	}
	updated() {
		const { _hasAILabel: hasAILabel } = this;
		if (hasAILabel) this.setAttribute("ai-label", "");
		else this.removeAttribute("ai-label");
	}
	connectedCallback() {
		super.connectedCallback();
		if (this.defaultChecked) this.checked = this.defaultChecked;
	}
	render() {
		const { checked, disabled, helperText, hideLabel, id, indeterminate, invalid, invalidText, labelText, name, readonly, title, value, warn, warnText, defaultChecked, _handleChange: handleChange, _handleClick: handleClick } = this;
		const normalizedProps = {
			invalid: !readonly && !disabled && invalid,
			warn: !readonly && !invalid && !disabled && warn
		};
		const showHelper = !normalizedProps.invalid && !normalizedProps.warn;
		const helper = helperText ? html` <div class="${"cds-custom"}--form__helper-text">${helperText}</div>` : null;
		const labelClasses = classMap({ [`cds-custom--checkbox-label`]: true });
		const labelTextClasses = classMap({
			[`cds-custom--checkbox-label-text`]: true,
			[`cds-custom--visually-hidden`]: hideLabel
		});
		return html`
      <input
        id="${ifDefined(id)}"
        type="checkbox"
        part="input"
        class="${`cds-custom--checkbox`}"
        aria-readonly="${String(readonly)}"
        .checked="${checked}"
        ?data-invalid="${normalizedProps.invalid}"
        ?disabled="${disabled}"
        ?defaultChecked="${defaultChecked}"
        .indeterminate="${indeterminate}"
        name="${ifDefined(name)}"
        value="${ifDefined(value)}"
        @change="${handleChange}"
        @click="${handleClick}" />
      <label
        for="${ifDefined(id)}"
        part="label"
        class="${labelClasses}"
        title="${ifDefined(title)}">
        <span class="${labelTextClasses}"
          >${labelText ? labelText : html`<slot></slot>`}</span
        >
      </label>
      <slot name="ai-label" @slotchange="${this._handleSlotChange}"></slot>
      <slot name="decorator" @slotchange="${this._handleSlotChange}"></slot>
      <slot name="slug" @slotchange="${this._handleSlotChange}"></slot>
      <div class="${"cds-custom"}--checkbox__validation-msg">
        ${normalizedProps.invalid ? html`
              ${iconLoader(WarningFilled16, { class: `cds-custom--checkbox__invalid-icon` })}
              <div class="${"cds-custom"}--form-requirement">${invalidText}</div>
            ` : null}
        ${normalizedProps.warn ? html`
              ${iconLoader(WarningAltFilled16, { class: `cds-custom--checkbox__invalid-icon cds-custom--checkbox__invalid-icon--warning` })}
              <div class="${"cds-custom"}--form-requirement">${warnText}</div>
            ` : null}
      </div>
      ${showHelper ? helper : null}
    `;
	}
	/**
	* The name of the custom event fired after this changebox changes its checked state.
	*/
	static get eventChange() {
		return `cds-custom-checkbox-changed`;
	}
	/**
	* A selector that will return the slug item.
	*
	* Remove in v12
	*/
	static get slugItem() {
		return `cds-custom-slug`;
	}
	/**
	* A selector that will return the ai-label item.
	*/
	static get aiLabelItem() {
		return `cds-custom-ai-label`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = checkbox_default;
	}
};
__decorate([query("input")], CDSCheckbox.prototype, "_checkboxNode", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "checked"
})], CDSCheckbox.prototype, "checked", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "data-table"
})], CDSCheckbox.prototype, "dataTable", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCheckbox.prototype, "disabled", void 0);
__decorate([property({
	type: String,
	reflect: true,
	attribute: "helper-text"
})], CDSCheckbox.prototype, "helperText", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-checkbox"
})], CDSCheckbox.prototype, "hideCheckbox", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-label"
})], CDSCheckbox.prototype, "hideLabel", void 0);
__decorate([property({ reflect: true })], CDSCheckbox.prototype, "id", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCheckbox.prototype, "indeterminate", void 0);
__decorate([property({ attribute: "label-text" })], CDSCheckbox.prototype, "labelText", void 0);
__decorate([property()], CDSCheckbox.prototype, "name", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCheckbox.prototype, "readonly", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCheckbox.prototype, "invalid", void 0);
__decorate([property({
	type: String,
	attribute: "invalid-text"
})], CDSCheckbox.prototype, "invalidText", void 0);
__decorate([property({ attribute: "title" })], CDSCheckbox.prototype, "title", void 0);
__decorate([property()], CDSCheckbox.prototype, "value", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCheckbox.prototype, "warn", void 0);
__decorate([property({
	type: String,
	attribute: "warn-text"
})], CDSCheckbox.prototype, "warnText", void 0);
__decorate([property({
	type: Boolean,
	attribute: "default-checked"
})], CDSCheckbox.prototype, "defaultChecked", void 0);
//#endregion
export { CDSCheckbox as default };

//# sourceMappingURL=checkbox.js.map