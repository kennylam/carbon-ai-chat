/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import checkbox_default from "./checkbox.scss.js";
import { CHECKBOX_ORIENTATION } from "./defs.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import WarningFilled16 from "@carbon/icons/es/warning--filled/16.js";
import WarningAltFilled16 from "@carbon/icons/es/warning--alt--filled/16.js";
//#region src/components/checkbox/checkbox-group.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Check box.
*
* @element cds-custom-checkbox-group
*/
var CDSCheckboxGroup = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.orientation = "vertical";
		this.readonly = false;
		this.warn = false;
		this.warnText = "";
		this._hasAILabel = false;
	}
	static {
		this.is = `cds-custom-checkbox-group`;
	}
	_handleSlotChange({ target }) {
		const hasContent = target.assignedNodes().filter((elem) => elem.matches !== void 0 ? elem.matches(this.constructor.aiLabelItem) || elem.matches(this.constructor.slugItem) : false);
		this._hasAILabel = Boolean(hasContent);
		hasContent[0].setAttribute("size", "mini");
		this.requestUpdate();
	}
	updated(changedProperties) {
		const { selectorCheckbox } = this.constructor;
		const checkboxes = this.querySelectorAll(selectorCheckbox);
		[
			"disabled",
			"readonly",
			"orientation"
		].forEach((name) => {
			if (changedProperties.has(name)) {
				const { [name]: value } = this;
				checkboxes.forEach((elem) => {
					elem[name] = value;
				});
			}
		});
		if (changedProperties.has("invalid") || changedProperties.has("disabled") || changedProperties.has("readonly")) {
			const { invalid, disabled, readonly } = this;
			const hasInvalidState = invalid && !disabled && !readonly;
			checkboxes.forEach((elem) => {
				if (hasInvalidState) elem.setAttribute("invalid-group", "");
				else elem.removeAttribute("invalid-group");
			});
		}
	}
	render() {
		const { ariaLabelledBy, disabled, helperText, invalid, invalidText, legendId, legendText, orientation, readonly, warn, warnText, _hasAILabel: hasAILabel, _handleSlotChange: handleSlotChange } = this;
		const normalizedProps = {
			invalid: !readonly && !disabled && invalid,
			warn: !readonly && !invalid && !disabled && warn
		};
		const showHelper = !normalizedProps.invalid && !normalizedProps.warn;
		const checkboxGroupInstanceId = Math.random().toString(16).slice(2);
		const helperId = !helperText ? void 0 : `checkbox-group-helper-text-${checkboxGroupInstanceId}`;
		const helper = helperText ? html` <div id="${helperId}" class="${"cds-custom"}--form__helper-text">
          ${helperText}
        </div>` : null;
		return html`
      <fieldset
        class="${classMap({
			[`cds-custom--checkbox-group`]: true,
			[`cds-custom--checkbox-group--readonly`]: readonly,
			[`cds-custom--checkbox-group--invalid`]: normalizedProps.invalid,
			[`cds-custom--checkbox-group--warning`]: normalizedProps.warn,
			[`cds-custom--checkbox-group--slug`]: hasAILabel,
			[`cds-custom--checkbox-group--${orientation}`]: orientation === "horizontal"
		})}"
        ?data-invalid=${normalizedProps.invalid}
        ?disabled=${disabled}
        aria-disabled=${readonly || disabled}
        ?aria-labelledby=${ariaLabelledBy || legendId}
        ?aria-describedby=${!normalizedProps.invalid && !normalizedProps.warn && helper ? helperId : void 0}
        orientation=${orientation}>
        <legend class="${"cds-custom"}--label" id=${legendId || ariaLabelledBy}>
          ${legendText}
          <slot name="ai-label" @slotchange="${handleSlotChange}"></slot>
          <slot name="decorator" @slotchange="${handleSlotChange}"></slot>
          <slot name="slug" @slotchange="${handleSlotChange}"></slot>
        </legend>
        <slot></slot>
        <div class="${"cds-custom"}--checkbox-group__validation-msg">
          ${normalizedProps.invalid ? html`
                ${iconLoader(WarningFilled16, { class: `cds-custom--checkbox__invalid-icon` })}
                <div class="${"cds-custom"}--form-requirement">${invalidText}</div>
              ` : null}
          ${normalizedProps.warn ? html`
                ${iconLoader(WarningAltFilled16, { class: `cds-custom--checkbox__invalid-icon cds-custom--checkbox__invalid-icon--warning` })}
                <div class="${"cds-custom"}--form-requirement">${warnText}</div>
              ` : null}
        </div>
        ${showHelper ? helper : null}
      </fieldset>
    `;
	}
	/**
	* A selector that will return the checkboxes.
	*/
	static get selectorCheckbox() {
		return `cds-custom-checkbox`;
	}
	/**
	* A selector that will return the slug item.
	*
	* remove in v12
	*/
	static get slugItem() {
		return `cds-custom-slug`;
	}
	/**
	* A selector that will return the AI Label item.
	*/
	static get aiLabelItem() {
		return `cds-custom-ai-label`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = checkbox_default;
	}
};
__decorate([property({
	type: String,
	reflect: true,
	attribute: "aria-labelledby"
})], CDSCheckboxGroup.prototype, "ariaLabelledBy", void 0);
__decorate([property({ type: Boolean })], CDSCheckboxGroup.prototype, "disabled", void 0);
__decorate([property({
	type: String,
	reflect: true,
	attribute: "helper-text"
})], CDSCheckboxGroup.prototype, "helperText", void 0);
__decorate([property({
	type: Boolean,
	attribute: "invalid"
})], CDSCheckboxGroup.prototype, "invalid", void 0);
__decorate([property({
	type: String,
	reflect: true,
	attribute: "invalid-text"
})], CDSCheckboxGroup.prototype, "invalidText", void 0);
__decorate([property({
	type: String,
	reflect: true,
	attribute: "legend-id"
})], CDSCheckboxGroup.prototype, "legendId", void 0);
__decorate([property({
	type: String,
	reflect: true,
	attribute: "legend-text"
})], CDSCheckboxGroup.prototype, "legendText", void 0);
__decorate([property({
	type: String,
	reflect: true,
	attribute: "orientation"
})], CDSCheckboxGroup.prototype, "orientation", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCheckboxGroup.prototype, "readonly", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSCheckboxGroup.prototype, "warn", void 0);
__decorate([property({
	type: String,
	reflect: true,
	attribute: "warn-text"
})], CDSCheckboxGroup.prototype, "warnText", void 0);
//#endregion
export { CHECKBOX_ORIENTATION, CDSCheckboxGroup as default };

//# sourceMappingURL=checkbox-group.js.map