/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/checkbox/defs.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* How to lay out radio buttons.
*/
let CHECKBOX_ORIENTATION = /* @__PURE__ */ function(CHECKBOX_ORIENTATION) {
	/**
	* Laying out radio buttons horizontally.
	*/
	CHECKBOX_ORIENTATION["HORIZONTAL"] = "horizontal";
	/**
	* Laying out radio buttons vertically.
	*/
	CHECKBOX_ORIENTATION["VERTICAL"] = "vertical";
	return CHECKBOX_ORIENTATION;
}({});
//#endregion
export { CHECKBOX_ORIENTATION };

//# sourceMappingURL=defs.js.map