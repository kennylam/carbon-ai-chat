/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import "../number-input/index.js";
import CDSFluidNumberInput from "./fluid-number-input.js";
import CDSFluidNumberInputSkeleton from "./fluid-number-input-skeleton.js";
//#region src/components/fluid-number-input/index.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFluidNumberInput);
defineCustomElement(CDSFluidNumberInputSkeleton);
//#endregion
export { CDSFluidNumberInput, CDSFluidNumberInputSkeleton };

//# sourceMappingURL=index.js.map