/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSNumberInput from "../number-input/number-input.js";
import fluid_number_input_default from "./fluid-number-input.scss.js";
import { html } from "lit";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/fluid-number-input/fluid-number-input.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid number input.
*
* @element cds-custom-fluid-number-input
*/
var CDSFluidNumberInput = class extends CDSNumberInput {
	static {
		this.is = `cds-custom-fluid-number-input`;
	}
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
	}
	updated(changedProperties) {
		super.updated(changedProperties);
	}
	render() {
		return html`<div class="${classMap({
			[`cds-custom--number-input--fluid`]: true,
			[`cds-custom--number-input--fluid--invalid`]: this.invalid,
			[`cds-custom--number-input--fluid--warning`]: this.warn && !this.invalid,
			[`cds-custom--number-input--fluid--disabled`]: this.disabled,
			[`cds-custom--number-input--fluid--readonly`]: this.readonly
		})}">${super.render()}</div>`;
	}
	static {
		this.styles = [CDSNumberInput.styles, fluid_number_input_default];
	}
};
//#endregion
export { CDSFluidNumberInput as default };

//# sourceMappingURL=fluid-number-input.js.map