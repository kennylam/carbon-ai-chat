/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSNumberInputSkeleton from "../number-input/number-input-skeleton.js";
import fluid_number_input_default from "./fluid-number-input.scss.js";
import { html } from "lit";
//#region src/components/fluid-number-input/fluid-number-input-skeleton.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid number input.
*
* @element cds-custom-fluid-number-input-skeleton
*/
var CDSFluidNumberInputSkeleton = class extends CDSNumberInputSkeleton {
	static {
		this.is = `cds-custom-fluid-number-input-skeleton`;
	}
	render() {
		return html` ${super.render()} `;
	}
	static {
		this.styles = [CDSNumberInputSkeleton.styles, fluid_number_input_default];
	}
};
//#endregion
export { CDSFluidNumberInputSkeleton as default };

//# sourceMappingURL=fluid-number-input-skeleton.js.map