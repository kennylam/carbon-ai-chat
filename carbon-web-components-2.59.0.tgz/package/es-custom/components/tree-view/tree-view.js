/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import tree_view_default from "./tree-view.scss.js";
import { TREE_SIZE } from "./defs.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/tree-view/tree-view.ts
/**
* Copyright IBM Corp. 2025, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Tree view.
*
* @element cds-custom-tree-view
*/
var CDSTreeView = class CDSTreeView extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.hideLabel = false;
		this.size = "sm";
		this._click = ({ target }) => {
			if (target.disabled) return;
			this.querySelectorAll(CDSTreeView.selectorTreeNode).forEach((node) => {
				const isTarget = node === target;
				const isLink = node.hasAttribute("href");
				const element = isLink ? node.shadowRoot?.querySelector("a") : node;
				node.selected = isTarget;
				node.active = isTarget;
				if (!isTarget) if (isLink) element.setAttribute("tabindex", "-1");
				else element.removeAttribute("tabindex");
				else element.setAttribute("tabindex", "0");
			});
		};
		this._handleKeyDown = (event) => {
			const { key } = event;
			const nodes = Array.from(this.querySelectorAll(CDSTreeView.selectorTreeNode)).filter((node) => node.checkVisibility() && !node.hasAttribute("disabled"));
			const allNodes = Array.from(this.querySelectorAll(CDSTreeView.selectorTreeNode)).filter((node) => !node.hasAttribute("disabled"));
			const withLinks = nodes[0].href;
			const currentIndex = nodes.findIndex((node) => withLinks ? node.shadowRoot?.querySelector("a").getAttribute("tabindex") === "0" : node.getAttribute("tabindex") === "0");
			let nextIndex = currentIndex;
			switch (key) {
				case "ArrowDown":
					nextIndex = Math.min(currentIndex + 1, nodes.length - 1);
					break;
				case "ArrowUp":
					nextIndex = Math.max(currentIndex - 1, 0);
					break;
				case "Home":
					nextIndex = 0;
					break;
				case "End":
					nextIndex = nodes.length - 1;
					break;
				case "Enter":
				case " ":
					event.preventDefault();
					allNodes.forEach((node) => {
						node.selected = false;
						node.active = false;
					});
					nodes[currentIndex].selected = true;
					nodes[currentIndex].active = true;
					break;
				case "ArrowRight":
					if (nodes[currentIndex].hasAttribute("parent")) {
						nodes[currentIndex].isExpanded = true;
						nodes[currentIndex].setAttribute("aria-expanded", "true");
					}
					break;
				case "ArrowLeft":
					if (!nodes[currentIndex].hasAttribute("parent")) {
						const temp = nodes.findIndex((node) => node === nodes[currentIndex].parentElement);
						nextIndex = temp === -1 ? currentIndex : temp;
					} else {
						nodes[currentIndex].isExpanded = false;
						nodes[currentIndex].setAttribute("aria-expanded", "false");
					}
					break;
			}
			if (nextIndex !== currentIndex) {
				nodes.forEach((node) => {
					if (!withLinks) node.removeAttribute("tabindex");
					else node.shadowRoot?.querySelector("a").setAttribute("tabindex", "-1");
				});
				const element = withLinks ? nodes[nextIndex].shadowRoot.querySelector("a") : nodes[nextIndex];
				element.setAttribute("tabindex", "0");
				element.focus();
				event.preventDefault();
			}
		};
	}
	static {
		this.is = `cds-custom-tree-view`;
	}
	async _setInitialFocus() {
		await this.updateComplete;
		const nodes = this.querySelectorAll(CDSTreeView.selectorTreeNode);
		if (nodes.length > 0) {
			const selectedNode = Array.from(nodes).find((node) => node.selected) || nodes[0];
			(selectedNode.href ? selectedNode.shadowRoot.querySelector("a") : selectedNode).setAttribute("tabindex", "0");
		}
	}
	connectedCallback() {
		super.connectedCallback();
		if (!this.hasAttribute("role")) this.setAttribute("role", "tree");
		if (!this.hasAttribute("aria-label")) this.setAttribute("aria-label", this.label);
	}
	updated(changedProperties) {
		this._setInitialFocus();
		if (changedProperties.has("size")) this.querySelectorAll(CDSTreeView.selectorTreeNode).forEach((item) => {
			item.setAttribute("size", this.size);
		});
	}
	render() {
		const { hideLabel, label, size } = this;
		const labelId = "tree-view__label";
		const treeClasses = classMap({
			[`cds-custom--tree`]: true,
			[`cds-custom--tree--${size}`]: size
		});
		return html`
      ${!hideLabel ? html`<label id=${labelId} class=${`cds-custom--label`}
              >${label}
            </label>` : null}
      <ul
        aria-label=${hideLabel ? label : void 0}
        aria-labelledby=${!hideLabel ? labelId : void 0}
        class=${treeClasses}
        role="tree">
        <slot><slot>
      </ul>
    `;
	}
	static get selectorTreeNode() {
		return `cds-custom-tree-node`;
	}
	static {
		this.styles = tree_view_default;
	}
};
__decorate([property({
	type: Boolean,
	attribute: "hide-label"
})], CDSTreeView.prototype, "hideLabel", void 0);
__decorate([property()], CDSTreeView.prototype, "label", void 0);
__decorate([property({ reflect: true })], CDSTreeView.prototype, "size", void 0);
__decorate([HostListener("click")], CDSTreeView.prototype, "_click", void 0);
__decorate([HostListener("keydown")], CDSTreeView.prototype, "_handleKeyDown", void 0);
//#endregion
export { TREE_SIZE, CDSTreeView as default };

//# sourceMappingURL=tree-view.js.map