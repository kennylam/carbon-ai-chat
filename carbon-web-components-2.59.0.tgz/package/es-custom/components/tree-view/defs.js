/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/tree-view/defs.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
let TREE_SIZE = /* @__PURE__ */ function(TREE_SIZE) {
	/**
	* Small
	*/
	TREE_SIZE["SMALL"] = "sm";
	/**
	* Extra small size.
	*/
	TREE_SIZE["EXTRA_SMALL"] = "xs";
	return TREE_SIZE;
}({});
//#endregion
export { TREE_SIZE };

//# sourceMappingURL=defs.js.map