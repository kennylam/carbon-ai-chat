/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSTreeNode from "./tree-node.js";
import CDSTreeView from "./tree-view.js";
//#region src/components/tree-view/index.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSTreeNode);
defineCustomElement(CDSTreeView);
//#endregion
export { CDSTreeNode, CDSTreeView };

//# sourceMappingURL=index.js.map