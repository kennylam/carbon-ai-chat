/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import fluid_time_picker_default from "./fluid-time-picker.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/fluid-time-picker/fluid-time-picker-skeleton.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid time picker skeleton.
*
* @element cds-custom-fluid-time-picker-skeleton
*/
var CDSFluidTimePickerSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.isOnlyTwo = false;
	}
	static {
		this.is = `cds-custom-fluid-time-picker-skeleton`;
	}
	render() {
		return html`
      <div class="${classMap({
			[`cds-custom--time-picker--fluid--skeleton`]: true,
			[`cds-custom--time-picker--equal-width`]: this.isOnlyTwo
		})}">
        <cds-custom-fluid-text-input-skeleton></cds-custom-fluid-text-input-skeleton>
        <cds-custom-fluid-select-skeleton></cds-custom-fluid-select-skeleton>
        ${this.isOnlyTwo ? null : html`<cds-custom-fluid-select-skeleton></cds-custom-fluid-select-skeleton>`}
      </div>
    `;
	}
	static {
		this.styles = fluid_time_picker_default;
	}
};
__decorate([property({
	type: Boolean,
	attribute: "is-only-two",
	reflect: true
})], CDSFluidTimePickerSkeleton.prototype, "isOnlyTwo", void 0);
//#endregion
export { CDSFluidTimePickerSkeleton as default };

//# sourceMappingURL=fluid-time-picker-skeleton.js.map