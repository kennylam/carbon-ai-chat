/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import "../select/index.js";
import "../fluid-select/index.js";
import "../fluid-text-input/index.js";
import "../time-picker/index.js";
import CDSFluidTimePicker from "./fluid-time-picker.js";
import CDSFluidTimePickerSelect from "./fluid-time-picker-select.js";
import CDSFluidTimePickerSkeleton from "./fluid-time-picker-skeleton.js";
//#region src/components/fluid-time-picker/index.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFluidTimePicker);
defineCustomElement(CDSFluidTimePickerSelect);
defineCustomElement(CDSFluidTimePickerSkeleton);
//#endregion
export { CDSFluidTimePicker, CDSFluidTimePickerSelect, CDSFluidTimePickerSkeleton };

//# sourceMappingURL=index.js.map