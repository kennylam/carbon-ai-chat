/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import link_default from "./link.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/link/link.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Link size.
*/
const LINK_SIZE = {
	MEDIUM: "md",
	SMALL: "sm",
	LARGE: "lg"
};
/**
* Link.
*
* @element cds-custom-link
* @csspart link The link.
*/
var CDSLink = class extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this._hasIcon = false;
		this.disabled = false;
		this.inline = false;
		this.size = LINK_SIZE.MEDIUM;
		this.visited = false;
	}
	static {
		this.is = `cds-custom-link`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		const { name } = target;
		const hasContent = target.assignedNodes().some((node) => node.nodeType !== Node.TEXT_NODE || node.textContent.trim());
		this[name === "icon" ? "_hasIcon" : ""] = hasContent;
		this.requestUpdate();
	}
	/**
	* The CSS class list for the link node.
	*/
	get _classes() {
		const { disabled, size, inline, visited, _hasIcon } = this;
		return classMap({
			[`cds-custom--link`]: true,
			[`cds-custom--link--disabled`]: disabled,
			[`cds-custom--link--icon`]: _hasIcon,
			[`cds-custom--link--inline`]: inline,
			[`cds-custom--link--${size}`]: size,
			[`cds-custom--link--visited`]: visited
		});
	}
	/**
	* @returns The inner content.
	*/
	_renderInner() {
		const { _hasIcon: hasIcon, _handleSlotChange: handleSlotChange } = this;
		return html`
      <slot @slotchange="${handleSlotChange}"></slot>
      <span ?hidden="${!hasIcon}" class="${"cds-custom"}--link__icon">
        <slot name="icon" @slotchange="${handleSlotChange}"></slot>
      </span>
    `;
	}
	/**
	* @returns The disabled link content.
	*/
	_renderDisabledLink() {
		const { _classes: classes } = this;
		return html`
      <p id="link" part="link" class="${classes}">${this._renderInner()}</p>
    `;
	}
	/**
	* @returns The link content.
	*/
	_renderLink() {
		const { download, href, hreflang, linkRole, ping, rel, target, type, _classes: classes } = this;
		return html`
      <a
        tabindex="0"
        id="link"
        role="${ifDefined(linkRole)}"
        class="${classes}"
        part="link"
        download="${ifDefined(download)}"
        href="${ifDefined(href)}"
        hreflang="${ifDefined(hreflang)}"
        ping="${ifDefined(ping)}"
        rel="${ifDefined(rel)}"
        target="${ifDefined(target)}"
        type="${ifDefined(type)}">
        ${this._renderInner()}
      </a>
    `;
	}
	render() {
		const { disabled } = this;
		return disabled ? this._renderDisabledLink() : this._renderLink();
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = link_default;
	}
};
__decorate([query("#link")], CDSLink.prototype, "_linkNode", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSLink.prototype, "disabled", void 0);
__decorate([property({ reflect: true })], CDSLink.prototype, "download", void 0);
__decorate([property({ reflect: true })], CDSLink.prototype, "href", void 0);
__decorate([property({ reflect: true })], CDSLink.prototype, "hreflang", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSLink.prototype, "inline", void 0);
__decorate([property({ attribute: "link-role" })], CDSLink.prototype, "linkRole", void 0);
__decorate([property({ reflect: true })], CDSLink.prototype, "ping", void 0);
__decorate([property({ reflect: true })], CDSLink.prototype, "rel", void 0);
__decorate([property({ reflect: true })], CDSLink.prototype, "size", void 0);
__decorate([property({ reflect: true })], CDSLink.prototype, "target", void 0);
__decorate([property({ reflect: true })], CDSLink.prototype, "type", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSLink.prototype, "visited", void 0);
//#endregion
export { LINK_SIZE, CDSLink as default };

//# sourceMappingURL=link.js.map