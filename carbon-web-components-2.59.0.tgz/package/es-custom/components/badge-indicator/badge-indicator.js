/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import badge_indicator_default from "./badge-indicator.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/badge-indicator/badge-indicator.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Badge Indicator.
*
* @element cds-custom-badge-indicator
*/
var CDSBadgeIndicator = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.slot = "badge-indicator";
	}
	static {
		this.is = `cds-custom-badge-indicator`;
	}
	render() {
		return html`${this.count && this.count > 999 ? "999+" : this.count}`;
	}
	static {
		this.styles = badge_indicator_default;
	}
};
__decorate([property({ type: Number })], CDSBadgeIndicator.prototype, "count", void 0);
__decorate([property({ reflect: true })], CDSBadgeIndicator.prototype, "slot", void 0);
//#endregion
export { CDSBadgeIndicator as default };

//# sourceMappingURL=badge-indicator.js.map