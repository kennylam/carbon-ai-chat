/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { css } from "lit";
//#region src/components/badge-indicator/badge-indicator.scss?lit
var badge_indicator_default = css([".cds-custom--badge-indicator,:host(cds-custom-badge-indicator){font-size:var(--cds-helper-text-01-font-size,.75rem);line-height:var(--cds-helper-text-01-line-height,1.33333);letter-spacing:var(--cds-helper-text-01-letter-spacing,.32px);position:absolute;display:flex;padding:0 .25rem .125rem;border-radius:100px;background:var(--cds-support-error,#da1e28);color:var(--cds-text-on-color,#fff);inset-block-start:0;inset-inline-end:0;margin-block-start:.5rem;margin-inline-end:.5rem;max-block-size:1rem;min-block-size:.5rem;min-inline-size:.5rem}.cds-custom--badge-indicator--count,:host(cds-custom-badge-indicator[count]){margin-block-start:.25rem;margin-inline-end:.25rem}"]);
//#endregion
export { badge_indicator_default as default };

//# sourceMappingURL=badge-indicator.scss.js.map