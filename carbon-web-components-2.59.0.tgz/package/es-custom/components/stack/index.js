/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSStack from "./stack.js";
//#region src/components/stack/index.ts
/**
* Copyright IBM Corp. 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSStack);
//#endregion
export { CDSStack };

//# sourceMappingURL=index.js.map