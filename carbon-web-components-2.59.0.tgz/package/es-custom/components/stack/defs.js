/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { spacing } from "@carbon/layout";
//#region src/components/stack/defs.ts
/**
* Copyright IBM Corp. 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Stack orientation
*/
let STACK_ORIENTATION = /* @__PURE__ */ function(STACK_ORIENTATION) {
	/**
	* Default vertical orientation.
	*/
	STACK_ORIENTATION["VERTICAL"] = "vertical";
	/**
	* Horizontal.
	*/
	STACK_ORIENTATION["HORIZONTAL"] = "horizontal";
	return STACK_ORIENTATION;
}({});
/**
* The steps in the spacing scale
*
* @type {Array<number>}
*/
const SPACING_STEPS = Array.from({ length: spacing.length - 1 }).map((_, step) => {
	return step + 1;
});
//#endregion
export { SPACING_STEPS, STACK_ORIENTATION };

//# sourceMappingURL=defs.js.map