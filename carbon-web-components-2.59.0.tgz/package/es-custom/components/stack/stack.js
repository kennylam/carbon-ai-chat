/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import stack_default from "./stack.scss.js";
import { SPACING_STEPS, STACK_ORIENTATION } from "./defs.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/stack/stack.ts
/**
* Copyright IBM Corp. 2023, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The Stack component is a useful layout utility in a component-based model.
* This allows components to not use margin and instead delegate the
* responsibility of positioning and layout to parent components.
*
* In the case of the Stack component, it uses the spacing scale from the
* Design Language in order to determine how much space there should be between
* items rendered by the Stack component. It also supports a custom `gap` prop
* which will allow a user to provide a custom value for the gap of the layout.
*
* This component supports both horizontal and vertical orientations.
*
* @element cds-custom-stack
*/
var CDSStack = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.orientation = "vertical";
		this.useCustomGapValue = false;
	}
	static {
		this.is = `cds-custom-stack`;
	}
	updated(changedProperties) {
		if (changedProperties.has("gap")) if (this.useCustomGapValue) this.style.setProperty(`--cds-stack-gap`, `${this.gap}`);
		else {
			const oldGapValue = changedProperties.get("gap");
			this.shadowRoot?.querySelector("div")?.classList.remove(`cds-custom--stack-scale-${oldGapValue}`);
			this.shadowRoot?.querySelector("div")?.classList.add(`cds-custom--stack-scale-${this.gap}`);
		}
	}
	render() {
		return html`<div><slot></slot></div>`;
	}
	static {
		this.styles = stack_default;
	}
};
__decorate([property({
	type: String,
	reflect: true
})], CDSStack.prototype, "orientation", void 0);
__decorate([property({
	type: SPACING_STEPS || String,
	reflect: true
})], CDSStack.prototype, "gap", void 0);
__decorate([property({
	type: Boolean,
	attribute: "use-custom-gap-value"
})], CDSStack.prototype, "useCustomGapValue", void 0);
//#endregion
export { SPACING_STEPS, STACK_ORIENTATION, CDSStack as default };

//# sourceMappingURL=stack.js.map