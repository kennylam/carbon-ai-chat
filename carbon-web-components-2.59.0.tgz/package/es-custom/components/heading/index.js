/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSHeading, { CDSSection } from "./heading.js";
//#region src/components/heading/index.ts
/**
* Copyright IBM Corp. 2021, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSHeading);
defineCustomElement(CDSSection);
//#endregion
export { CDSHeading, CDSSection };

//# sourceMappingURL=index.js.map