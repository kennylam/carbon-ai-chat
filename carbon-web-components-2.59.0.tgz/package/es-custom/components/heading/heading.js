/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import heading_default from "./heading.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { unsafeHTML } from "lit/directives/unsafe-html.js";
//#region src/components/heading/heading.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
var CDSSection = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._currentLevel = 1;
	}
	static {
		this.is = `cds-custom-section`;
	}
	getParentLevel() {
		const parentSection = this.parentElement?.closest(`cds-custom-section`);
		return parentSection ? parentSection.getCurrentLevel() : 1;
	}
	connectedCallback() {
		super.connectedCallback();
		const parentLevel = this.getParentLevel();
		this._currentLevel = this.level ?? Math.min(parentLevel + 1, 6);
	}
	getCurrentLevel() {
		return this._currentLevel;
	}
	render() {
		return html`<slot></slot>`;
	}
};
__decorate([property({ type: Number })], CDSSection.prototype, "level", void 0);
/**
* The heading component
*
* @element cds-custom-heading
*/
var CDSHeading = class extends LitElement {
	constructor(..._args2) {
		super(..._args2);
		this._level = 1;
	}
	static {
		this.is = `cds-custom-heading`;
	}
	connectedCallback() {
		super.connectedCallback();
		const section = this.closest(`cds-custom-section`);
		this._level = section ? section.getCurrentLevel() : 1;
	}
	render() {
		return html`${unsafeHTML(`
      <h${this._level}>
        <slot></slot>
      </h${this._level}>
    `)}`;
	}
	static {
		this.styles = heading_default;
	}
};
//#endregion
export { CDSSection, CDSHeading as default };

//# sourceMappingURL=heading.js.map