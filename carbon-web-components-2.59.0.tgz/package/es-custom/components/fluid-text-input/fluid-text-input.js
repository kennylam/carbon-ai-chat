/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import CDSTextInput from "../text-input/text-input.js";
import fluid_text_input_default from "./fluid-text-input.scss.js";
import { html } from "lit";
import { query } from "lit/decorators.js";
//#region src/components/fluid-text-input/fluid-text-input.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text input.
*
* @element cds-custom-fluid-text-input
*/
var CDSFluidTextInput = class extends CDSTextInput {
	static {
		this.is = `cds-custom-fluid-text-input`;
	}
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
	}
	updated() {
		if (this._formItem) this._formItem.classList.add(`cds-custom--text-input--fluid`);
	}
	render() {
		return html` ${super.render()} `;
	}
	static {
		this.styles = [CDSTextInput.styles, fluid_text_input_default];
	}
};
__decorate([query(`.cds-custom--form-item`)], CDSFluidTextInput.prototype, "_formItem", void 0);
//#endregion
export { CDSFluidTextInput as default };

//# sourceMappingURL=fluid-text-input.js.map