/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import CDSFluidTextInput from "./fluid-text-input.js";
import CDSFluidTextInputSkeleton from "./fluid-text-input-skeleton.js";
//#region src/components/fluid-text-input/index.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFluidTextInput);
defineCustomElement(CDSFluidTextInputSkeleton);
//#endregion
export { CDSFluidTextInput, CDSFluidTextInputSkeleton };

//# sourceMappingURL=index.js.map