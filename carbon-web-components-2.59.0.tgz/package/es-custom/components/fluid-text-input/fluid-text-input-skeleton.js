/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSTextInputSkeleton from "../text-input/text-input-skeleton.js";
import fluid_text_input_default from "./fluid-text-input.scss.js";
import { html } from "lit";
//#region src/components/fluid-text-input/fluid-text-input-skeleton.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text area input.
*
* @element cds-custom-fluid-text-input-skeleton
*/
var CDSFluidTextInputSkeleton = class extends CDSTextInputSkeleton {
	static {
		this.is = `cds-custom-fluid-text-input-skeleton`;
	}
	render() {
		return html` ${super.render()} `;
	}
	static {
		this.styles = [CDSTextInputSkeleton.styles, fluid_text_input_default];
	}
};
//#endregion
export { CDSFluidTextInputSkeleton as default };

//# sourceMappingURL=fluid-text-input-skeleton.js.map