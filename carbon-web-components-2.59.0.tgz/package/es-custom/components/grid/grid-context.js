/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { createContext } from "@lit/context";
//#region src/components/grid/grid-context.ts
const gridContext = createContext(Symbol("GridContext"));
//#endregion
export { gridContext };

//# sourceMappingURL=grid-context.js.map