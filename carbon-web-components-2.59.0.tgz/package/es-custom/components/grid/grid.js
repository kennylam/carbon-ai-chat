/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import { gridContext } from "./grid-context.js";
import grid_default from "./grid.scss.js";
import { GRID_ALIGNMENT } from "./defs.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { consume, provide } from "@lit/context";
//#region src/components/grid/grid.ts
/**
* Copyright IBM Corp. 2024, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The grid component.
*
* @element cds-custom-grid
*/
var CDSGrid = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.condensed = false;
		this.narrow = false;
		this.fullWidth = false;
		this.withRowGap = false;
		this.gridContext = { subgrid: false };
	}
	static {
		this.is = `cds-custom-grid`;
	}
	render() {
		this.gridContext = { subgrid: true };
		if (this.gridContextIn?.subgrid) {
			let subMode = "wide";
			if (this.narrow) subMode = "narrow";
			else if (this.condensed) subMode = "condensed";
			return html`<div
        subgrid
        mode=${subMode}
        ?with-row-gap=${this.withRowGap}
        part="grid">
        <slot></slot>
      </div> `;
		} else return html`<div grid part="grid">
        <slot></slot>
      </div> `;
	}
	static {
		this.styles = grid_default;
	}
};
__decorate([property({
	reflect: true,
	type: String
})], CDSGrid.prototype, "align", void 0);
__decorate([property({
	reflect: true,
	type: Boolean
})], CDSGrid.prototype, "condensed", void 0);
__decorate([property({
	reflect: true,
	type: Boolean
})], CDSGrid.prototype, "narrow", void 0);
__decorate([property({
	reflect: true,
	attribute: "full-width",
	type: Boolean
})], CDSGrid.prototype, "fullWidth", void 0);
__decorate([property({
	reflect: true,
	attribute: "with-row-gap",
	type: Boolean
})], CDSGrid.prototype, "withRowGap", void 0);
__decorate([consume({
	context: gridContext,
	subscribe: true
}), property({ attribute: false })], CDSGrid.prototype, "gridContextIn", void 0);
__decorate([provide({ context: gridContext }), property({ attribute: false })], CDSGrid.prototype, "gridContext", void 0);
//#endregion
export { GRID_ALIGNMENT, CDSGrid as default };

//# sourceMappingURL=grid.js.map