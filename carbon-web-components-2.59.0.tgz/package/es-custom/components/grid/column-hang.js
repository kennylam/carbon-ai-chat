/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import column_hang_default from "./column-hang.scss.js";
import { LitElement, html } from "lit";
//#region src/components/grid/column-hang.ts
/**
* Copyright IBM Corp. 2024, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The column component.
*
* @element cds-custom-column-hang
*/
var CDSColumnHang = class extends LitElement {
	static {
		this.is = `cds-custom-column-hang`;
	}
	render() {
		return html`<div part="column-hang">
      <slot></slot>
    </div>`;
	}
	static {
		this.styles = column_hang_default;
	}
};
//#endregion
export { CDSColumnHang as default };

//# sourceMappingURL=column-hang.js.map