/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSGrid from "./grid.js";
import CDSColumn from "./column.js";
import CDSColumnHang from "./column-hang.js";
//#region src/components/grid/index.ts
/**
* Copyright IBM Corp. 2024, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSGrid);
defineCustomElement(CDSColumn);
defineCustomElement(CDSColumnHang);
//#endregion
export { CDSColumn, CDSColumnHang, CDSGrid };

//# sourceMappingURL=index.js.map