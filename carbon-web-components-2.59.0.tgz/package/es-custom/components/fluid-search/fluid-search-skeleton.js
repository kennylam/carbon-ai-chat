/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSSearchSkeleton from "../search/search-skeleton.js";
import fluid_search_default from "./fluid-search.scss.js";
import { html } from "lit";
//#region src/components/fluid-search/fluid-search-skeleton.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid Search.
*
* @element cds-custom-fluid-search-skeleton
*/
var CDSFluidSearchSkeleton = class extends CDSSearchSkeleton {
	static {
		this.is = `cds-custom-fluid-search-skeleton`;
	}
	render() {
		return html`${super.render()}`;
	}
	static {
		this.styles = [CDSSearchSkeleton.styles, fluid_search_default];
	}
};
//#endregion
export { CDSFluidSearchSkeleton as default };

//# sourceMappingURL=fluid-search-skeleton.js.map