/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../search/index.js";
import CDSFluidSearch from "./fluid-search.js";
import CDSFluidSearchSkeleton from "./fluid-search-skeleton.js";
//#region src/components/fluid-search/index.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFluidSearch);
defineCustomElement(CDSFluidSearchSkeleton);
//#endregion
export { CDSFluidSearch, CDSFluidSearchSkeleton };

//# sourceMappingURL=index.js.map