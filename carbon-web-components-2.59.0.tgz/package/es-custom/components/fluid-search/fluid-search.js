/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSSearch from "../search/search.js";
import fluid_search_default from "./fluid-search.scss.js";
import { html } from "lit";
//#region src/components/fluid-search/fluid-search.ts
/**
* Copyright IBM Corp.2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid text input.
*
* @element cds-custom-fluid-search
*/
var CDSFluidSearch = class extends CDSSearch {
	static {
		this.is = `cds-custom-fluid-search`;
	}
	render() {
		const { labelText, id } = this;
		return html`
      <label for="${id}" part="label-text" class="${"cds-custom"}--label"
        >${labelText}</label
      >
      ${super.render()}
    `;
	}
	static {
		this.styles = [CDSSearch.styles, fluid_search_default];
	}
};
//#endregion
export { CDSFluidSearch as default };

//# sourceMappingURL=fluid-search.js.map