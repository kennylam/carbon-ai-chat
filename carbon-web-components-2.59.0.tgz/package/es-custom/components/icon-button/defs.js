/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/icon-button/defs.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Icon Button size.
*/
let ICON_BUTTON_SIZE = /* @__PURE__ */ function(ICON_BUTTON_SIZE) {
	/**
	* Small size.
	*/
	ICON_BUTTON_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	ICON_BUTTON_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	ICON_BUTTON_SIZE["LARGE"] = "lg";
	return ICON_BUTTON_SIZE;
}({});
/**
* Icon Button Tooltip alignment.
*/
let ICON_BUTTON_TOOLTIP_ALIGNMENT = /* @__PURE__ */ function(ICON_BUTTON_TOOLTIP_ALIGNMENT) {
	/**
	* Align the top position for the tooltip content.
	*/
	ICON_BUTTON_TOOLTIP_ALIGNMENT["TOP"] = "top";
	/**
	* Align the top-left position for the tooltip content.
	*/
	ICON_BUTTON_TOOLTIP_ALIGNMENT["TOP_LEFT"] = "top-left";
	/**
	* Align the top right position for the tooltip content.
	*/
	ICON_BUTTON_TOOLTIP_ALIGNMENT["TOP_RIGHT"] = "top-right";
	/**
	* Align the bottom position for the tooltip content.
	*/
	ICON_BUTTON_TOOLTIP_ALIGNMENT["BOTTOM"] = "bottom";
	/**
	* Align the bottom left position for the tooltip content.
	*/
	ICON_BUTTON_TOOLTIP_ALIGNMENT["BOTTOM_LEFT"] = "bottom-left";
	/**
	* Align the bottom right position for the tooltip content.
	*/
	ICON_BUTTON_TOOLTIP_ALIGNMENT["BOTTOM_RIGHT"] = "bottom-right";
	/**
	* Align the left position for the tooltip content.
	*/
	ICON_BUTTON_TOOLTIP_ALIGNMENT["LEFT"] = "left";
	/**
	* Align the right position for the tooltip content.
	*/
	ICON_BUTTON_TOOLTIP_ALIGNMENT["RIGHT"] = "right";
	return ICON_BUTTON_TOOLTIP_ALIGNMENT;
}({});
//#endregion
export { ICON_BUTTON_SIZE, ICON_BUTTON_TOOLTIP_ALIGNMENT };

//# sourceMappingURL=defs.js.map