/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import tooltip_default from "../tooltip/tooltip.scss.js";
import "../tooltip/index.js";
import button_default from "../button/button.scss.js";
import CDSButton from "../button/button.js";
import "../button/index.js";
import { ICON_BUTTON_SIZE, ICON_BUTTON_TOOLTIP_ALIGNMENT } from "./defs.js";
import icon_button_default from "./icon-button.scss.js";
import { adoptStyles, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/icon-button/icon-button.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Icon Button
*
* @element cds-custom-icon-button
*/
var CDSIconButton = class extends CDSButton {
	constructor(..._args) {
		super(..._args);
		this.align = "top";
		this.autoalign = false;
		this.closeOnActivation = true;
		this.defaultOpen = false;
		this.enterDelayMs = 100;
		this.leaveDelayMs = 100;
		this.size = "md";
	}
	static {
		this.is = `cds-custom-icon-button`;
	}
	connectedCallback() {
		super.connectedCallback();
		adoptStyles(this.renderRoot, [
			tooltip_default,
			button_default,
			icon_button_default
		]);
	}
	updated(changedProperties) {
		super.updated?.(changedProperties);
		if (changedProperties) {
			this.shadowRoot?.querySelector(`cds-custom-tooltip`)?.shadowRoot?.querySelector(`.cds-custom--tooltip`)?.classList.add(`cds-custom--icon-tooltip`);
			const tooltipContent = this.querySelector("[slot=tooltip-content]")?.textContent;
			this.shadowRoot?.querySelector(`cds-custom-tooltip`)?.querySelector(`button`)?.setAttribute("aria-label", String(tooltipContent));
		}
	}
	_renderTooltipContent() {
		return html`
      <cds-custom-tooltip-content ?hidden=${this.disabled}>
        <slot name="tooltip-content"></slot>
      </cds-custom-tooltip-content>
    `;
	}
	render() {
		const { align, autoalign, closeOnActivation, defaultOpen, enterDelayMs, leaveDelayMs } = this;
		return html`
      <cds-custom-tooltip
        ?autoalign=${autoalign}
        align=${align}
        ?defaultOpen=${defaultOpen}
        ?closeOnActivation=${closeOnActivation}
        enter-delay-ms=${enterDelayMs}
        leave-delay-ms=${leaveDelayMs}
        .dropShadow=${false}>
        ${super.render()} ${this._renderTooltipContent()}
      </cds-custom-tooltip>
    `;
	}
};
__decorate([property({
	reflect: true,
	type: String
})], CDSIconButton.prototype, "align", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSIconButton.prototype, "autoalign", void 0);
__decorate([property({
	attribute: "close-on-activation",
	reflect: true,
	type: Boolean
})], CDSIconButton.prototype, "closeOnActivation", void 0);
__decorate([property({
	reflect: true,
	type: Boolean
})], CDSIconButton.prototype, "defaultOpen", void 0);
__decorate([property({
	attribute: "enter-delay-ms",
	type: Number
})], CDSIconButton.prototype, "enterDelayMs", void 0);
__decorate([property({
	attribute: "leave-delay-ms",
	type: Number
})], CDSIconButton.prototype, "leaveDelayMs", void 0);
__decorate([property({ reflect: true })], CDSIconButton.prototype, "size", void 0);
//#endregion
export { ICON_BUTTON_SIZE, ICON_BUTTON_TOOLTIP_ALIGNMENT, CDSIconButton as default };

//# sourceMappingURL=icon-button.js.map