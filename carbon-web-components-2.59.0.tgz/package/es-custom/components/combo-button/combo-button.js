/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../popover/defs.js";
import FloatingController from "../../globals/controllers/floating-controller.js";
import "../button/index.js";
import "../icon-button/defs.js";
import "../icon-button/index.js";
import "../menu/index.js";
import combo_button_default from "./combo-button.scss.js";
import { COMBO_BUTTON_SIZE, COMBO_BUTTON_TOOLTIP_ALIGNMENT } from "./defs.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import ChevronDown16 from "@carbon/icons/es/chevron--down/16.js";
//#region src/components/combo-button/combo-button.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Combo button.
* @element cds-custom-combo-button
*/
var CDSComboButton = class extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this._menuController = new FloatingController(this);
		this._open = false;
		this.menuAlignment = "top";
		this.size = "lg";
		this.tooltipAlignment = "top";
		this.tooltipContent = "Additional actions";
		this._handleClick = (event) => {
			if (event.composedPath().includes(this._triggerNode)) this._open = !this._open;
			else if (this._open) this._open = false;
			if (event.target.tagName === "CDS-MENU-ITEM") this.onClick?.(event);
		};
		this._handleBlur = ({ relatedTarget }) => {
			if (!this.contains(relatedTarget)) this._open = false;
		};
	}
	static {
		this.is = `cds-custom-combo-button`;
	}
	updated(changedProperties) {
		const menu = this.querySelector(`cds-custom-menu`);
		if (changedProperties.has("_open") || changedProperties.has("menuAlignment")) this.updateComplete.then(() => {
			const styleElement = menu.shadowRoot?.querySelector(`.cds-custom--menu`);
			menu.open = this._open;
			this._menuController.setPlacement({
				trigger: this,
				target: menu,
				alignment: this.menuAlignment,
				styleElement,
				matchWidth: true,
				open: this._open
			});
		});
		if (changedProperties.has("size")) menu.setAttribute("size", this.size);
	}
	render() {
		const { size, disabled, label, tooltipAlignment, menuAlignment, onClick } = this;
		return html`
      <cds-custom-button size=${size} ?disabled=${disabled} @click=${onClick}>
        ${label}
      </cds-custom-button>
      <cds-custom-icon-button
        size=${size}
        ?disabled=${disabled}
        align=${tooltipAlignment}
        menu-alignment=${menuAlignment}
        part="trigger">
        ${iconLoader(ChevronDown16, { slot: "icon" })}
        <span slot="tooltip-content">${this.tooltipContent}</span>
      </cds-custom-icon-button>
      <slot></slot>
    `;
	}
	static {
		this.styles = combo_button_default;
	}
};
__decorate([query(`cds-custom-icon-button`)], CDSComboButton.prototype, "_triggerNode", void 0);
__decorate([query(`cds-custom-menu`)], CDSComboButton.prototype, "_menuNode", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSComboButton.prototype, "_open", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSComboButton.prototype, "disabled", void 0);
__decorate([property()], CDSComboButton.prototype, "label", void 0);
__decorate([property({
	reflect: true,
	type: String,
	attribute: "menu-alignment"
})], CDSComboButton.prototype, "menuAlignment", void 0);
__decorate([property({ type: Function })], CDSComboButton.prototype, "onClick", void 0);
__decorate([property({
	type: COMBO_BUTTON_SIZE,
	reflect: true
})], CDSComboButton.prototype, "size", void 0);
__decorate([property({
	reflect: true,
	attribute: "tooltip-alignment"
})], CDSComboButton.prototype, "tooltipAlignment", void 0);
__decorate([property({
	type: String,
	attribute: "tooltip-content"
})], CDSComboButton.prototype, "tooltipContent", void 0);
__decorate([HostListener("click")], CDSComboButton.prototype, "_handleClick", void 0);
__decorate([HostListener("focusout")], CDSComboButton.prototype, "_handleBlur", void 0);
//#endregion
export { COMBO_BUTTON_SIZE, COMBO_BUTTON_TOOLTIP_ALIGNMENT, CDSComboButton as default };

//# sourceMappingURL=combo-button.js.map