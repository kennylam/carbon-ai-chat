/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/combo-button/defs.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Combo button size.
*/
let COMBO_BUTTON_SIZE = /* @__PURE__ */ function(COMBO_BUTTON_SIZE) {
	/**
	* Extra small size.
	*/
	COMBO_BUTTON_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	COMBO_BUTTON_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	COMBO_BUTTON_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	COMBO_BUTTON_SIZE["LARGE"] = "lg";
	return COMBO_BUTTON_SIZE;
}({});
/**
* Combo button tooltip alignment.
*/
let COMBO_BUTTON_TOOLTIP_ALIGNMENT = /* @__PURE__ */ function(COMBO_BUTTON_TOOLTIP_ALIGNMENT) {
	/**
	* Aligned to the start.
	*/
	COMBO_BUTTON_TOOLTIP_ALIGNMENT["START"] = "left";
	/**
	* Aligned to the center.
	*/
	COMBO_BUTTON_TOOLTIP_ALIGNMENT["CENTER"] = "center";
	/**
	* Aligned to the end.
	*/
	COMBO_BUTTON_TOOLTIP_ALIGNMENT["END"] = "right";
	return COMBO_BUTTON_TOOLTIP_ALIGNMENT;
}({});
//#endregion
export { COMBO_BUTTON_SIZE, COMBO_BUTTON_TOOLTIP_ALIGNMENT };

//# sourceMappingURL=defs.js.map