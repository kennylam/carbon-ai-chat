/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/modal/defs.ts
/**
* Copyright IBM Corp. 2020, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal size.
*/
let MODAL_SIZE = /* @__PURE__ */ function(MODAL_SIZE) {
	/**
	* Extra small size.
	*/
	MODAL_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	MODAL_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	MODAL_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	MODAL_SIZE["LARGE"] = "lg";
	return MODAL_SIZE;
}({});
//#endregion
export { MODAL_SIZE };

//# sourceMappingURL=defs.js.map