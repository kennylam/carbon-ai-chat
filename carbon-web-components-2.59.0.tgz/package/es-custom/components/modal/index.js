/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSModal from "./modal.js";
import CDSModalBody from "./modal-body.js";
import CDSModalBodyContent from "./modal-body-content.js";
import CDSModalCloseButton from "./modal-close-button.js";
import CDSModalFooter from "./modal-footer.js";
import CDSModalFooterButton from "./modal-footer-button.js";
import CDSModalHeader from "./modal-header.js";
import CDSModalHeading from "./modal-heading.js";
import CDSModalLabel from "./modal-label.js";
import "../dialog/index.js";
//#region src/components/modal/index.ts
/**
* Copyright IBM Corp. 2021, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSModal);
defineCustomElement(CDSModalBody);
defineCustomElement(CDSModalBodyContent);
defineCustomElement(CDSModalCloseButton);
defineCustomElement(CDSModalFooter);
defineCustomElement(CDSModalFooterButton);
defineCustomElement(CDSModalHeader);
defineCustomElement(CDSModalHeading);
defineCustomElement(CDSModalLabel);
//#endregion
export { CDSModal, CDSModalBody, CDSModalBodyContent, CDSModalCloseButton, CDSModalFooter, CDSModalFooterButton, CDSModalHeader, CDSModalHeading, CDSModalLabel };

//# sourceMappingURL=index.js.map