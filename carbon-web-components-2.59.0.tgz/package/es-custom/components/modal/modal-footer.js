/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import modal_default from "./modal.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/modal/modal-footer.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal footer.
*
* @element cds-custom-modal-footer
*/
var CDSModalFooter = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hasThreeButtons = false;
	}
	static {
		this.is = `cds-custom-modal-footer`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange(event) {
		const { selectorButtons } = this.constructor;
		this.hasThreeButtons = event.target.assignedNodes().filter((node) => node.nodeType === Node.ELEMENT_NODE && node.matches(selectorButtons)).length > 2;
		this.requestUpdate();
	}
	render() {
		return html` <slot @slotchange="${this._handleSlotChange}"></slot> `;
	}
	/**
	* A selector that selects the child buttons.
	*/
	static get selectorButtons() {
		return `cds-custom-button,cds-custom-modal-footer-button`;
	}
	static {
		this.styles = modal_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "has-three-buttons"
})], CDSModalFooter.prototype, "hasThreeButtons", void 0);
//#endregion
export { CDSModalFooter as default };

//# sourceMappingURL=modal-footer.js.map