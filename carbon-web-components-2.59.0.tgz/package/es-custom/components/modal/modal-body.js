/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import modal_default from "./modal.scss.js";
import { LitElement, html } from "lit";
//#region src/components/modal/modal-body.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal body.
*
* @element cds-custom-modal-body
*/
var CDSModalBody = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.userDefinedTabindex = null;
	}
	static {
		this.is = `cds-custom-modal-body`;
	}
	connectedCallback() {
		super.connectedCallback?.();
		if (this.hasAttribute("tabindex")) this.userDefinedTabindex = this.getAttribute("tabindex");
		this._resizeObserver = new ResizeObserver(() => this.checkScroll());
		this._resizeObserver.observe(this);
	}
	disconnectedCallback() {
		this._resizeObserver?.disconnect();
		super.disconnectedCallback?.();
	}
	_getAriaLabelledBy() {
		const modal = this.closest(`cds-custom-modal`);
		if (!modal) return null;
		const labelEl = modal.querySelector(`cds-custom-modal-label`);
		if (labelEl?.id) return labelEl.id;
		const headingEl = modal.querySelector(`cds-custom-modal-heading`);
		if (headingEl?.id) return headingEl.id;
		return null;
	}
	_parentHasScrollingContent() {
		return this.closest(`cds-custom-modal`)?.hasAttribute("has-scrolling-content") ?? false;
	}
	checkScroll() {
		const hasScroll = this.scrollHeight > this.clientHeight;
		const hasScrollingContent = this._parentHasScrollingContent();
		const hasAutoAlign = this.querySelector("[autoalign]") !== null;
		if (this.clientHeight <= 300 || hasAutoAlign) this.setAttribute("no-fade", "");
		else this.removeAttribute("no-fade");
		if (hasScrollingContent || hasScroll) {
			if (this.userDefinedTabindex === null) this.setAttribute("tabindex", "0");
			this.setAttribute("is-scrollable", "");
			this.setAttribute("role", "region");
			const ariaLabelledBy = this._getAriaLabelledBy();
			if (ariaLabelledBy) this.setAttribute("aria-labelledby", ariaLabelledBy);
		} else if (!hasScrollingContent) {
			if (this.userDefinedTabindex === null) this.removeAttribute("tabindex");
			this.removeAttribute("is-scrollable");
			this.removeAttribute("role");
			this.removeAttribute("aria-labelledby");
		}
	}
	render() {
		return html` <slot @slotchange=${this.checkScroll}></slot> `;
	}
	static {
		this.styles = modal_default;
	}
};
//#endregion
export { CDSModalBody as default };

//# sourceMappingURL=modal-body.js.map