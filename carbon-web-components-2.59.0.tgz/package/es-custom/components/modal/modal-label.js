/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import modal_default from "./modal.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/modal/modal-label.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal label.
*
* @element cds-custom-modal-label
*/
var CDSModalLabel = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.id = `cds-custom--modal-label--id-${Math.random().toString(16).slice(2)}`;
	}
	static {
		this.is = `cds-custom-modal-label`;
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = modal_default;
	}
};
__decorate([property({
	type: String,
	reflect: true
})], CDSModalLabel.prototype, "id", void 0);
//#endregion
export { CDSModalLabel as default };

//# sourceMappingURL=modal-label.js.map