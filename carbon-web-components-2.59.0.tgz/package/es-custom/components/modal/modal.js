/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListener from "../../globals/decorators/host-listener.js";
import { MODAL_SIZE } from "./defs.js";
import modal_default from "./modal.scss.js";
import { CDSModalBase } from "./modal-base.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/modal/modal.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal.
*
* @element cds-custom-modal
* @csspart dialog The dialog.
* @fires cds-custom-modal-beingclosed
*   The custom event fired before this modal is being closed upon a user gesture.
*   Cancellation of this event stops the user-initiated action of closing this modal.
* @fires cds-custom-modal-closed - The custom event fired after this modal is closed upon a user gesture.
*/
var CDSModal = class extends CDSModalBase {
	constructor(..._args) {
		super(..._args);
		this.enableDialogElement = false;
		this._handleClick = (event) => {
			if (event.composedPath().indexOf(this.shadowRoot) < 0 && !this.preventCloseOnClickOutside) this._handleUserInitiatedClose(event.target);
		};
		this._handleKeydown = ({ key, target }) => {
			if (!this.open || this.enableDialogElement) return;
			if (key === "Esc" || key === "Escape") this._handleUserInitiatedClose(target);
		};
		this._handleHostKeydown = (event) => {
			const target = event.target;
			const { primaryButton } = this._getFooterElements();
			if (this.open && this.shouldSubmitOnEnter && event.key === "Enter" && target && document.activeElement !== primaryButton) {
				const closeButton = this.constructor.selectorCloseButton;
				if (!(!!target.closest(closeButton) || !!document.activeElement?.closest?.(closeButton))) {
					primaryButton?.click();
					return;
				}
			}
			if (this.enableDialogElement) return;
			if (event.key === "Tab") {
				const { first: _firstElement, last: _lastElement } = this.getFocusable();
				if (event.shiftKey && (this.shadowRoot?.activeElement === _firstElement || document.activeElement === _firstElement)) {
					event.preventDefault();
					_lastElement?.focus();
				} else if (!event.shiftKey && document.activeElement === _lastElement) {
					event.preventDefault();
					_firstElement?.focus();
				}
			}
		};
		this._handleDialogClosed = (event) => {
			event.stopPropagation();
			this.open = false;
			this.dispatchEvent(new CustomEvent(this.constructor.eventClose, {
				bubbles: true,
				cancelable: true,
				composed: true,
				detail: event.detail
			}));
		};
		this._handleDialogBeingClosed = (event) => {
			event.stopPropagation();
			const modalEvent = new CustomEvent(this.constructor.eventBeforeClose, {
				bubbles: true,
				cancelable: true,
				composed: true,
				detail: event.detail
			});
			if (!this.dispatchEvent(modalEvent)) event.preventDefault();
		};
		this.alert = false;
		this.ariaLabel = null;
		this.containerClass = "";
		this.fullWidth = false;
		this.hasScrollingContent = false;
		this.open = false;
		this.size = "md";
		this.shouldSubmitOnEnter = false;
	}
	static {
		this.is = `cds-custom-modal`;
	}
	async firstUpdated() {
		if (!this.querySelector(this.constructor.selectorModalBody)) {
			const bodyElement = document.createElement(this.constructor.selectorModalBody);
			this.appendChild(bodyElement);
		}
	}
	/**
	* Computes the aria-label of the modal based on (in order of highest to lowest precedence):
	* - `modal-label`
	* - `aria-label`
	* - `modal-heading`
	*/
	_computeAriaLabel() {
		const label = this.querySelector(`cds-custom-modal-label`)?.textContent?.trim();
		if (label) return label;
		const ariaLabel = this.ariaLabel?.trim();
		if (ariaLabel) return ariaLabel;
		return this.querySelector(`cds-custom-modal-heading`)?.textContent?.trim() || "";
	}
	/**
	* Observes the modal footer's `has-three-buttons` attribute to account for cases
	* where the loading status and the amount of footer-buttons
	* are being changed dynamically
	*/
	_observeFooter() {
		const footer = this.querySelector(`cds-custom-modal-footer`);
		if (!footer) return;
		this._footerObserver = new MutationObserver(() => {
			this._updateLoadingElement();
		});
		this._footerObserver.observe(footer, {
			attributes: true,
			childList: true,
			attributeFilter: ["has-three-buttons"]
		});
	}
	/**
	* Observes the modal header to account for cases where the modal-heading,
	* modal-label, and/or `aria-label` are dynamically changing
	* to update the `aria-label` put on the modal
	*/
	_observeHeader() {
		const header = this.querySelector(`cds-custom-modal-header`);
		if (!header) return;
		this._headerObserver = new MutationObserver(() => {
			this.requestUpdate("ariaLabel");
		});
		this._headerObserver.observe(header, {
			subtree: true,
			characterData: true,
			childList: true
		});
	}
	connectedCallback() {
		super.connectedCallback?.();
		this._observeFooter();
		this._observeHeader();
	}
	disconnectedCallback() {
		this._footerObserver?.disconnect();
		this._headerObserver?.disconnect();
		super.disconnectedCallback?.();
	}
	render() {
		const { alert, size, hasScrollingContent, enableDialogElement } = this;
		const containerClass = this.containerClass.split(" ").filter(Boolean).reduce((acc, item) => ({
			...acc,
			[item]: true
		}), {});
		const containerClasses = classMap({
			[`cds-custom--modal-container`]: true,
			[`cds-custom--modal-container--${size}`]: size,
			...containerClass
		});
		const ariaLabel = this._computeAriaLabel();
		if (enableDialogElement) return html`
        <cds-custom-dialog
          .open=${this.open}
          .alert=${this.alert}
          .preventCloseOnClickOutside=${this.preventCloseOnClickOutside}
          .preventClose=${this.preventClose}
          role="${alert ? "alertdialog" : "dialog"}"
          aria-label=${ariaLabel}
          modal-controlled
          @cds-custom-dialog-closed=${this._handleDialogClosed}
          @cds-custom-dialog-beingclosed=${this._handleDialogBeingClosed}>
          <slot @slotchange="${this._handleSlotChange}"></slot>
          ${hasScrollingContent ? html` <div class="cds-custom--modal-content--overflow-indicator"></div> ` : ``}
        </cds-custom-dialog>
      `;
		else return html`
        <div
          aria-label=${ariaLabel}
          part="dialog"
          class=${containerClasses}
          aria-modal=${true}
          role="${alert ? "alert" : "dialog"}"
          tabindex="-1"
          @click=${this._handleClickContainer}>
          <slot @slotchange="${this._handleSlotChange}"></slot>
          ${hasScrollingContent ? html` <div class="cds-custom--modal-content--overflow-indicator"></div> ` : ``}
        </div>
      `;
	}
	async updated(changedProperties) {
		if (changedProperties.has("open")) {
			if (this.open) {
				this._launcher = this.ownerDocument.activeElement;
				const primaryFocusNode = this.querySelector(this.constructor.selectorPrimaryFocus);
				await this.constructor._delay();
				if (primaryFocusNode) primaryFocusNode.focus();
				else {
					const { primaryButton, secondaryButtons } = this._getFooterElements();
					if (primaryButton) if (primaryButton?.getAttribute("kind") === "danger" && secondaryButtons[0]) secondaryButtons[0].focus();
					else primaryButton.focus();
					else {
						const { first } = this.getFocusable();
						first?.focus();
					}
				}
			} else if (this._launcher && typeof this._launcher.focus === "function") {
				this._launcher.focus();
				this._launcher = null;
			}
		}
		if (changedProperties.has("loadingStatus") || changedProperties.has("loadingDescription") || changedProperties.has("loadingSuccessDelay") || changedProperties.has("loadingIconDescription")) {
			await this.constructor._delay();
			this._updateLoadingElement();
		}
	}
	/**
	* @param ms The number of milliseconds.
	* @returns A promise that is resolves after the given milliseconds.
	*/
	static _delay(ms = 0) {
		return new Promise((resolve) => {
			setTimeout(resolve, ms);
		});
	}
	/**
	* A selector selecting buttons that should close this modal.
	*/
	static get selectorCloseButton() {
		return `[data-modal-close],cds-custom-modal-close-button`;
	}
	/**
	* A selector selecting the nodes that should be focused when modal gets open.
	*/
	static get selectorPrimaryFocus() {
		return `[data-modal-primary-focus],cds-custom-modal-footer cds-custom-button[kind="primary"]`;
	}
	/**
	* A selector selecting the modal body component
	*/
	static get selectorModalBody() {
		return `cds-custom-modal-body`;
	}
	/**
	* The name of the custom event fired before this modal is being closed upon a user gesture.
	* Cancellation of this event stops the user-initiated action of closing this modal.
	*/
	static get eventBeforeClose() {
		return `cds-custom-modal-beingclosed`;
	}
	/**
	* The name of the custom event fired after this modal is closed upon a user gesture.
	*/
	static get eventClose() {
		return `cds-custom-modal-closed`;
	}
	static {
		this.styles = modal_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "enable-dialog-element"
})], CDSModal.prototype, "enableDialogElement", void 0);
__decorate([HostListener("click")], CDSModal.prototype, "_handleClick", void 0);
__decorate([HostListener("document:keydown")], CDSModal.prototype, "_handleKeydown", void 0);
__decorate([HostListener("keydown")], CDSModal.prototype, "_handleHostKeydown", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSModal.prototype, "alert", void 0);
__decorate([property({ attribute: "aria-label" })], CDSModal.prototype, "ariaLabel", void 0);
__decorate([property({ attribute: "container-class" })], CDSModal.prototype, "containerClass", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "full-width"
})], CDSModal.prototype, "fullWidth", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "has-scrolling-content"
})], CDSModal.prototype, "hasScrollingContent", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSModal.prototype, "open", void 0);
__decorate([property({ reflect: true })], CDSModal.prototype, "size", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "should-submit-on-enter"
})], CDSModal.prototype, "shouldSubmitOnEnter", void 0);
//#endregion
export { MODAL_SIZE, CDSModal as default };

//# sourceMappingURL=modal.js.map