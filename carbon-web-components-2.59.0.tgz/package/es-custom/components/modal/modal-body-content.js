/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import modal_default from "./modal.scss.js";
import { LitElement, html } from "lit";
//#region src/components/modal/modal-body-content.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal body content
*
* @element cds-custom-modal-body-content
*/
var CDSModalBodyContent = class extends LitElement {
	static {
		this.is = `cds-custom-modal-body-content`;
	}
	render() {
		return html`<slot></slot>`;
	}
	static {
		this.styles = modal_default;
	}
};
//#endregion
export { CDSModalBodyContent as default };

//# sourceMappingURL=modal-body-content.js.map