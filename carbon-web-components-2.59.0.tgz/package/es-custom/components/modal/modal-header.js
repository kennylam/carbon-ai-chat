/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import modal_default from "./modal.scss.js";
import { LitElement, html } from "lit";
//#region src/components/modal/modal-header.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal header.
*
* @element cds-custom-modal-header
*/
var CDSModalHeader = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._hasAILabel = false;
	}
	static {
		this.is = `cds-custom-modal-header`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		const hasContent = target.assignedNodes().filter((elem) => elem.matches !== void 0 ? elem.matches(this.constructor.aiLabelItem) || elem.matches(this.constructor.slugItem) : false);
		if (hasContent.length > 0) {
			this._hasAILabel = Boolean(hasContent);
			hasContent[0].setAttribute("size", "sm");
		}
		this.requestUpdate();
	}
	updated() {
		if (this._hasAILabel) this.parentElement?.setAttribute("ai-label", "");
		else this.parentElement?.removeAttribute("ai-label");
	}
	render() {
		return html` <slot></slot>
      <slot name="ai-label" @slotchange="${this._handleSlotChange}"></slot>
      <slot name="slug" @slotchange="${this._handleSlotChange}"></slot>`;
	}
	/**
	* A selector that will return the slug item.
	*
	* remove in v12
	*/
	static get slugItem() {
		return `cds-custom-slug`;
	}
	/**
	* A selector that will return the AI Label item.
	*/
	static get aiLabelItem() {
		return `cds-custom-ai-label`;
	}
	static {
		this.styles = modal_default;
	}
};
//#endregion
export { CDSModalHeader as default };

//# sourceMappingURL=modal-header.js.map