/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import button_default from "../button/button.scss.js";
import CDSButton from "../button/button.js";
import modal_default from "./modal.scss.js";
//#region src/components/modal/modal-footer-button.ts
/**
* Copyright IBM Corp. 2021, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Modal footer button.
*
* @element cds-custom-modal-footer-button
*/
var CDSModalFooterButton = class extends CDSButton {
	static {
		this.is = `cds-custom-modal-footer-button`;
	}
	static {
		this.styles = [button_default, modal_default];
	}
};
//#endregion
export { CDSModalFooterButton as default };

//# sourceMappingURL=modal-footer-button.js.map