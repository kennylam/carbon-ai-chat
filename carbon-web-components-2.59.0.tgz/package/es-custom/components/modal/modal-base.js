/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import { selectorTabbable } from "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../inline-loading/index.js";
import { LitElement } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/modal/modal-base.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Base class for Modal and Dialog components.
*/
var CDSModalBase = class extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this._launcher = null;
		this._loadingEl = null;
		this.WORKING_LOADING_STATUSES = [
			"active",
			"finished",
			"error"
		];
		this.loadingStatus = "inactive";
		this.loadingDescription = "";
		this.loadingSuccessDelay = 1500;
		this.loadingIconDescription = "Loading";
		this.open = false;
		this.alert = false;
		this.preventCloseOnClickOutside = false;
		this.preventClose = false;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange() {
		if (this.querySelector(`cds-custom-modal-footer`)) this.setAttribute("has-footer", "");
		else this.removeAttribute("has-footer");
	}
	/**
	* Handles `click` event on the modal container.
	*
	* @param event The event.
	*/
	_handleClickContainer(event) {
		const { selectorCloseButton } = this.constructor;
		if (event.target.matches?.(selectorCloseButton) && !this.preventClose) this._handleUserInitiatedClose(event.target);
	}
	/**
	* Handles user-initiated close request of this modal.
	*
	* @param triggeredBy The element that triggered this close request.
	*/
	_handleUserInitiatedClose(triggeredBy) {
		if (this.open) {
			const init = {
				bubbles: true,
				cancelable: true,
				composed: true,
				detail: { triggeredBy }
			};
			if (this.dispatchEvent(new CustomEvent(this.constructor.eventBeforeClose, init))) {
				this.open = false;
				this.dispatchEvent(new CustomEvent(this.constructor.eventClose, init));
			}
		}
	}
	/**
	* Get focusable elements.
	*
	* Querying all tabbable items.
	*
	* @returns {{first: HTMLElement, last: HTMLElement, all: HTMLElement[]}} Returns an object with various elements.
	*/
	getFocusable() {
		const elements = [];
		const tabbableItems = this.querySelectorAll(selectorTabbable);
		if (tabbableItems?.length) elements.push(...tabbableItems);
		const all = elements?.filter((el) => typeof el?.focus === "function");
		return {
			first: all[0],
			last: all[all.length - 1],
			all
		};
	}
	_getFooterElements() {
		return {
			footer: this.querySelector(`cds-custom-modal-footer`),
			primaryButton: this.querySelector(`cds-custom-modal-footer-button[kind="primary"]`) || this.querySelector(`cds-custom-modal-footer-button[kind="danger"]`) || null,
			secondaryButtons: Array.from(this.querySelectorAll(`cds-custom-modal-footer-button[kind="secondary"]`))
		};
	}
	_initializeLoadingEl(footer) {
		if (!footer) return null;
		if (!this._loadingEl && this.WORKING_LOADING_STATUSES.includes(this.loadingStatus)) {
			const el = document.createElement(`cds-custom-inline-loading`);
			el.setAttribute("controlled", "");
			el.setAttribute("aria-live", "off");
			footer.appendChild(el);
			this._loadingEl = el;
		}
		return this._loadingEl;
	}
	_updateLoadingElement() {
		const { footer, primaryButton, secondaryButtons } = this._getFooterElements();
		const loader = this._initializeLoadingEl(footer);
		if (!footer || !loader || !primaryButton) return;
		if (this.WORKING_LOADING_STATUSES.includes(this.loadingStatus)) {
			loader.style.display = "inline-flex";
			loader.setAttribute("status", String(this.loadingStatus));
			loader.setAttribute("aria-live", "assertive");
			loader.setAttribute("icon-description", String(this.loadingIconDescription));
			loader.textContent = this.loadingDescription;
			primaryButton.style.display = "none";
			if (secondaryButtons[0]) if (!footer.hasAttribute("has-three-buttons")) secondaryButtons[0].setAttribute("disabled", "");
			else secondaryButtons.forEach((b) => b.removeAttribute("disabled"));
			if (this.loadingStatus === "finished") setTimeout(() => {
				this.dispatchEvent(new CustomEvent(this.constructor.eventOnLoadingSuccess, {
					bubbles: true,
					cancelable: true,
					composed: true
				}));
			}, this.loadingSuccessDelay);
		} else if (this.loadingStatus === "inactive") {
			loader.style.display = "none";
			loader.setAttribute("aria-live", "off");
			if (primaryButton) primaryButton.style.display = "";
			if (secondaryButtons) secondaryButtons.forEach((b) => b.removeAttribute("disabled"));
		}
	}
	/**
	* @param ms The number of milliseconds.
	* @returns A promise that is resolves after the given milliseconds.
	*/
	static _delay(ms = 0) {
		return new Promise((resolve) => {
			setTimeout(resolve, ms);
		});
	}
	/**
	* A selector selecting buttons that should close this modal.
	*/
	static get selectorCloseButton() {
		return `[data-modal-close],cds-custom-modal-close-button`;
	}
	/**
	* A selector selecting tabbable nodes.
	*/
	static get selectorTabbable() {
		return selectorTabbable;
	}
	/**
	* A selector selecting the nodes that should be focused when modal gets open.
	*/
	static get selectorPrimaryFocus() {
		return `[data-modal-primary-focus],cds-custom-modal-footer cds-custom-button[kind="primary"]`;
	}
	/**
	* A selector selecting the modal body component
	*/
	static get selectorModalBody() {
		return `cds-custom-modal-body`;
	}
	/**
	* The name of the custom event fired before this modal is being closed upon a user gesture.
	* Cancellation of this event stops the user-initiated action of closing this modal.
	*/
	static get eventBeforeClose() {
		return `cds-custom-modal-beingclosed`;
	}
	/**
	* The name of the custom event fired after this modal is closed upon a user gesture.
	*/
	static get eventClose() {
		return `cds-custom-modal-closed`;
	}
	/**
	* The name of the custom event fired when this modal reaches a `finished` loading state
	*/
	static get eventOnLoadingSuccess() {
		return `cds-custom-modal-on-loadingsuccess`;
	}
};
__decorate([property({
	reflect: true,
	attribute: "loading-status"
})], CDSModalBase.prototype, "loadingStatus", void 0);
__decorate([property({
	type: String,
	attribute: "loading-description"
})], CDSModalBase.prototype, "loadingDescription", void 0);
__decorate([property({
	type: Number,
	attribute: "loading-success-delay"
})], CDSModalBase.prototype, "loadingSuccessDelay", void 0);
__decorate([property({
	type: String,
	attribute: "loading-icon-description"
})], CDSModalBase.prototype, "loadingIconDescription", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSModalBase.prototype, "open", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSModalBase.prototype, "alert", void 0);
__decorate([property({
	type: Boolean,
	attribute: "prevent-close-on-click-outside"
})], CDSModalBase.prototype, "preventCloseOnClickOutside", void 0);
__decorate([property({
	type: Boolean,
	attribute: "prevent-close"
})], CDSModalBase.prototype, "preventClose", void 0);
//#endregion
export { CDSModalBase, CDSModalBase as default };

//# sourceMappingURL=modal-base.js.map