/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
//#region src/components/data-table/table-body.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Data table body.
*
* @element cds-custom-table-body
*/
var CDSTableBody = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._handleSlotChange = () => {
			this._updateZebra();
			this.dispatchEvent(new CustomEvent(this.constructor.eventTableBodyContentChange, {
				bubbles: true,
				cancelable: false
			}));
		};
		this.useZebraStyles = false;
	}
	static {
		this.is = `cds-custom-table-body`;
	}
	/**
	* Updates `even`/`odd` properties of the child `<cds-custom-table-row>`s.
	*/
	_updateZebra() {
		const { useZebraStyles, _slotNode: slotNode } = this;
		slotNode.assignedNodes().forEach((node) => {
			if (node.nodeType === Node.ELEMENT_NODE) {
				const even = node.matches("*:nth-of-type(even)");
				node.even = useZebraStyles && even;
				node.odd = useZebraStyles && !even;
			}
		});
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "rowgroup");
		super.connectedCallback();
	}
	updated(changedProperties) {
		if (changedProperties.has("useZebraStyles")) this._updateZebra();
	}
	render() {
		const { _handleSlotChange: handleSlotChange } = this;
		return html` <slot @slotchange="${handleSlotChange}"></slot> `;
	}
	/**
	* The name of the custom event fired after the body slot content changes
	*/
	static get eventTableBodyContentChange() {
		return `cds-custom-table-body-content-change`;
	}
	static {
		this.styles = data_table_default;
	}
};
__decorate([query("slot")], CDSTableBody.prototype, "_slotNode", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "use-zebra-styles"
})], CDSTableBody.prototype, "useZebraStyles", void 0);
//#endregion
export { CDSTableBody as default };

//# sourceMappingURL=table-body.js.map