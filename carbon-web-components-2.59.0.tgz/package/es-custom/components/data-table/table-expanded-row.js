/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/data-table/table-expanded-row.ts
/**
* Copyright IBM Corp. 2020, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Table row of collapsible details.
*
* @element cds-custom-table-expanded-row
*/
var CDSTableExpandedRow = class extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.colSpan = 1;
		this.expanded = false;
		this.filtered = false;
		this.highlighted = false;
		this.selected = false;
	}
	static {
		this.is = `cds-custom-table-expanded-row`;
	}
	/**
	* Handles `mouseover`/`mouseout` event handler on this element.
	*
	* @param event The event.
	*/
	_handleMouseOverOut(event) {
		const { selectorRow } = this.constructor;
		const { previousElementSibling } = this;
		if (previousElementSibling?.matches(selectorRow)) previousElementSibling.highlighted = event.type === "mouseover";
	}
	render() {
		const { colSpan } = this;
		return html`
      <td colspan="${colSpan}">
        <div class="${"cds-custom"}--child-row-inner-container">
          <slot></slot>
        </div>
      </td>
    `;
	}
	updated() {
		if (this.previousElementSibling?.hasAttribute("ai-label")) this.setAttribute("ai-label", "");
		else this.removeAttribute("ai-label");
	}
	/**
	* A selector that will return the previous sibling row.
	*/
	static get selectorRow() {
		return `cds-custom-table-row`;
	}
	static {
		this.styles = data_table_default;
	}
};
__decorate([HostListener("mouseover"), HostListener("mouseout")], CDSTableExpandedRow.prototype, "_handleMouseOverOut", null);
__decorate([property({
	type: Number,
	attribute: "colspan"
})], CDSTableExpandedRow.prototype, "colSpan", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableExpandedRow.prototype, "expanded", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableExpandedRow.prototype, "filtered", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableExpandedRow.prototype, "highlighted", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableExpandedRow.prototype, "selected", void 0);
//#endregion
export { CDSTableExpandedRow as default };

//# sourceMappingURL=table-expanded-row.js.map