/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../button/index.js";
import "../search/index.js";
import CDSTable from "./table.js";
import CDSTableSkeleton from "./table-skeleton.js";
import CDSTableHeader from "./table-header-title.js";
import CDSTableHeaderDescription from "./table-header-description.js";
import CDSTableBatchActions from "./table-batch-actions.js";
import CDSTableBody from "./table-body.js";
import CDSTableCell from "./table-cell.js";
import CDSTableCellContent from "./table-cell-content.js";
import CDSTableExpandedRow from "./table-expanded-row.js";
import CDSTableHead from "./table-head.js";
import CDSTableHeaderCell from "./table-header-cell.js";
import CDSTableRow from "./table-row.js";
import CDSTableHeaderRow from "./table-header-row.js";
import CDSTableToolbar from "./table-toolbar.js";
import CDSTableToolbarContent from "./table-toolbar-content.js";
import CDSTableToolbarSearch from "./table-toolbar-search.js";
//#region src/components/data-table/index.ts
/**
* Copyright IBM Corp. 2021, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSTable);
defineCustomElement(CDSTableSkeleton);
defineCustomElement(CDSTableHeader);
defineCustomElement(CDSTableHeaderDescription);
defineCustomElement(CDSTableBatchActions);
defineCustomElement(CDSTableBody);
defineCustomElement(CDSTableCell);
defineCustomElement(CDSTableCellContent);
defineCustomElement(CDSTableExpandedRow);
defineCustomElement(CDSTableHead);
defineCustomElement(CDSTableHeaderCell);
defineCustomElement(CDSTableHeaderRow);
defineCustomElement(CDSTableRow);
defineCustomElement(CDSTableToolbar);
defineCustomElement(CDSTableToolbarContent);
defineCustomElement(CDSTableToolbarSearch);
//#endregion
export { CDSTable, CDSTableBatchActions, CDSTableBody, CDSTableCell, CDSTableCellContent, CDSTableExpandedRow, CDSTableHead, CDSTableHeader, CDSTableHeaderCell, CDSTableHeaderDescription, CDSTableHeaderRow, CDSTableRow, CDSTableSkeleton, CDSTableToolbar, CDSTableToolbarContent, CDSTableToolbarSearch };

//# sourceMappingURL=index.js.map