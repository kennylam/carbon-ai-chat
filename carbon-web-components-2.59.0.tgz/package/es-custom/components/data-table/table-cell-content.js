/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html } from "lit";
//#region src/components/data-table/table-cell-content.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Data table cell content.
*
* @element cds-custom-table-cell-content
*/
var CDSTableCellContent = class extends LitElement {
	static {
		this.is = `cds-custom-table-cell-content`;
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = data_table_default;
	}
};
//#endregion
export { CDSTableCellContent as default };

//# sourceMappingURL=table-cell-content.js.map