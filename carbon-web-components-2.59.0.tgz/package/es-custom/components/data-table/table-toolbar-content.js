/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/data-table/table-toolbar-content.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Table toolbar content.
*
* @element cds-custom-table-toolbar-content
*/
var CDSTableToolbarContent = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hasBatchActions = false;
	}
	static {
		this.is = `cds-custom-table-toolbar-content`;
	}
	updated(changedProperties) {
		if (this.hasBatchActions) this.setAttribute("tabindex", "-1");
		else this.removeAttribute("tabindex");
		if (changedProperties.has("size")) [...this.children].forEach((e) => {
			const size = this.size === "md" || this.size === "xl" ? "lg" : this.size;
			e.setAttribute("size", size);
		});
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = data_table_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "has-batch-actions"
})], CDSTableToolbarContent.prototype, "hasBatchActions", void 0);
__decorate([property({ reflect: true })], CDSTableToolbarContent.prototype, "size", void 0);
//#endregion
export { CDSTableToolbarContent as default };

//# sourceMappingURL=table-toolbar-content.js.map