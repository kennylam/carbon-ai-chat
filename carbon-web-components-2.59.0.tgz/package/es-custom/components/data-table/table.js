/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { forEach } from "../../globals/internal/collection-helpers.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import { TABLE_SIZE } from "./defs.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html } from "lit";
import { property, state } from "lit/decorators.js";
//#region src/components/data-table/table.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Data table.
*
* @element cds-custom-table
* @fires cds-custom-table-header-cell-sort
*   The name of the custom event fired before a new sort direction is set upon a user gesture.
*   Cancellation of this event stops the user-initiated change in sort direction.
* @fires cds-custom-search input
*   The name of the custom event fired during search bar input
* @fires cds-custom-table-change-selection-all
*   The name of the custom event fired before header row is selected/unselected upon a user gesture.
* @fires cds-custom-table-row-change-selection
*   The name of the custom event fired before a row is selected/unselected upon a user gesture.
* @fires cds-custom-table-batch-actions-cancel-clicked
*   The name of the custom event fired after the Cancel button is clicked.
* @fires cds-custom-table-row-expando-toggled
*   The name of the custom event fired after the expanded state of a row is toggled upon a user gesture.
* @fires cds-custom-table-row-selected
*   The name of the custom event fired after a row has been selected.
* @fires cds-custom-table-row-all-selected
*   The name of the custom event fired after all rows have been selected.
* @fires cds-custom-table-sorted
*   The name of the custom event fired after the table has been sorted.
* @fires cds-custom-table-filtered
*   The name of the custom event fired after the table has been filtered containing remaining rows.
*/
var CDSTable = class extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.collationFactors = {
			["ascending"]: 1,
			["descending"]: -1
		};
		this._searchValue = "";
		this._selectedRows = [];
		this.batchExpansion = false;
		this.expandable = false;
		this.filterRows = (rowText, searchString) => rowText.toLowerCase().indexOf(searchString.toLowerCase()) < 0;
		this.headerCount = 0;
		this.isSelectable = false;
		this.isSortable = false;
		this.locale = "en";
		this.overflowMenuOnHover = false;
		this.radio = false;
		this.size = "lg";
		this.useStaticWidth = false;
		this.useZebraStyles = false;
		this.withRowAILabels = false;
		this.withRowSlugs = false;
		this._handleBatchExpansion = async (event) => {
			const { detail, target } = event;
			const { expanded } = detail;
			if (target === this._tableHeaderRow) this._tableRows.forEach((e) => e.expanded = expanded);
		};
		this._handleSort = async (event) => {
			const { detail, target } = event;
			const { sortDirection } = detail;
			if (!this.contains(target)) return;
			const columns = [...this._tableHeaderRow.children];
			const columnIndex = columns.indexOf(target);
			columns.forEach((e) => {
				if (e !== target && this.isSortable) e.setAttribute("sort-direction", "none");
				else if (e.hasAttribute("is-sortable")) e.setAttribute("sort-direction", "none");
			});
			this._handleSortAction(columnIndex, sortDirection);
			const init = {
				bubbles: true,
				cancelable: true,
				composed: true,
				detail: { sortedHeader: columns[columnIndex] }
			};
			this.dispatchEvent(new CustomEvent(this.constructor.eventTableSorted, init));
			this._handleFilterRows();
		};
		this._handleSearchInput = async (event) => {
			const { detail, target } = event;
			if (this.contains(target)) {
				const { value } = detail;
				this._searchValue = value;
				this._handleFilterRows();
			}
		};
		this._handleRowSelect = async (event) => {
			const { detail, target } = event;
			const { selected } = detail;
			const { _tableBatchActions: tableBatchActions, _tableToolbarContent: tableToolbarContent, _tableHeaderRow: tableHeaderRow, _selectedRows: selectedRows } = this;
			if (!this.contains(target)) return;
			if (this.radio) {
				this._tableRows.forEach((e) => {
					if (e !== target) {
						e.removeAttribute("selected");
						e.shadowRoot.querySelector(`cds-custom-radio-button`).checked = false;
					}
				});
				this._selectedRows.push(...[target]);
			} else {
				if (selectedRows.includes(target)) this._selectedRows = selectedRows.filter((e) => e !== target);
				else selectedRows.push(target);
				if (tableBatchActions) {
					tableBatchActions.active = this._selectedRows?.length;
					tableBatchActions.selectedRowsCount += selected ? 1 : -1;
				}
				if (tableToolbarContent) tableToolbarContent.hasBatchActions = this._selectedRows.length;
			}
			const totalSelectableRows = [...this._tableRows].filter((elem) => !elem.hasAttribute("filtered") && !elem.hasAttribute("disabled")).length;
			const headerCheckbox = tableHeaderRow.shadowRoot?.querySelector(`cds-custom-checkbox`).shadowRoot.querySelector(`.cds-custom--checkbox`);
			const allRowsSelected = this._selectedRows.length === totalSelectableRows;
			headerCheckbox.checked = Boolean(this._selectedRows.length);
			headerCheckbox.indeterminate = !allRowsSelected && this._selectedRows.length > 0;
			const init = {
				bubbles: true,
				cancelable: true,
				composed: true,
				detail: {
					selectedRow: target,
					selectedRows
				}
			};
			this.dispatchEvent(new CustomEvent(this.constructor.eventTableRowSelect, init));
		};
		this._handleAllRowsSelect = async (event) => {
			const { detail, target } = event;
			const { selected } = detail;
			const { _tableBatchActions: tableBatchActions, _tableToolbarContent: tableToolbarContent, _tableRows: tableRows } = this;
			if (!this.contains(target)) return;
			let totalRows = 0;
			forEach(tableRows, (elem) => {
				if (!elem.filtered && !elem.disabled) {
					elem.selected = selected;
					if (this.radio) {
						const radioButton = elem.shadowRoot.querySelector(`cds-custom-radio-button`);
						radioButton.checked = selected;
					}
					this._selectedRows.push(elem);
					totalRows++;
					const { selectorTableExpandedRows } = this.constructor;
					const { nextElementSibling } = elem;
					if (nextElementSibling?.matches(selectorTableExpandedRows)) elem.nextElementSibling.selected = selected;
				}
			});
			if (!selected) this._selectedRows = [];
			if (tableBatchActions) {
				tableBatchActions.selectedRowsCount = selected ? totalRows : 0;
				tableBatchActions.active = selected;
			}
			if (tableToolbarContent) tableToolbarContent.hasBatchActions = selected;
			const init = {
				bubbles: true,
				cancelable: true,
				composed: true,
				detail: { selectedRows: this._selectedRows }
			};
			this.dispatchEvent(new CustomEvent(this.constructor.eventTableRowSelectAll, init));
		};
		this._handleCancelSelection = async (event) => {
			const { target } = event;
			const { _tableHeaderRow: tableHeaderRow } = this;
			if (this.contains(target)) tableHeaderRow.shadowRoot?.querySelector(`cds-custom-checkbox`).shadowRoot.querySelector(`.cds-custom--checkbox`).click();
		};
	}
	static {
		this.is = `cds-custom-table`;
	}
	/**
	* @param lhs A value.
	* @param rhs Another value.
	* @param collator A custom collator.
	* @returns
	*   `0` if the given two values are equal
	*   A negative value to sort `lhs` to an index lower than `rhs`
	*   A positive value to sort `rhs` to an index lower than `lhs`
	*/
	customSortRow(lhs, rhs, collator) {
		if (typeof lhs === "number" && typeof rhs === "number") return lhs - rhs;
		return collator.compare(lhs, rhs);
	}
	_handleSlotChange({ target }) {
		const hasContent = target.assignedNodes().some((node) => node.nodeType !== Node.TEXT_NODE || node.textContent.trim());
		this.withHeader = hasContent;
	}
	_handleTableBodyChange() {
		this._tableBody = this.querySelector(this.constructor.selectorTableBody);
		this._tableExpandedRows = this.querySelectorAll(this.constructor.selectorTableExpandedRows);
		this._tableRows = this.querySelectorAll(this.constructor.selectorTableRow);
		this.updateExpandable();
	}
	/**
	* Normalizes table size to toolbar size.
	* Toolbar only supports `xs`, `sm`, and `lg`.
	* `md` and `xl` table sizes are mapped to `lg`.
	*/
	normalizeToolbarSize(size) {
		if (size === "xs" || size === "sm") return size;
		return "lg";
	}
	_handleSortAction(columnIndex, sortDirection) {
		const rows = [...this._tableRows];
		rows.sort((a, b) => {
			const cellA = a.querySelectorAll(this.constructor.selectorTableRowCells)[columnIndex].textContent;
			const cellB = b.querySelectorAll(this.constructor.selectorTableRowCells)[columnIndex].textContent;
			return this.collationFactors[sortDirection] * this.customSortRow(cellA, cellB, this.collator);
		});
		if (this.expandable) {
			const originalRows = [...this._tableRows];
			const expandedRows = [...this._tableExpandedRows];
			const mapping = originalRows.reduce((acc, element, index) => {
				const sortId = element.getAttribute("sort-id");
				acc[sortId] = expandedRows[index];
				return acc;
			}, {});
			const sortedWithExpanded = [];
			rows.forEach((e) => {
				const sortId = e.getAttribute("sort-id");
				sortedWithExpanded.push(e);
				if (mapping[sortId]) sortedWithExpanded.push(mapping[sortId]);
			});
			sortedWithExpanded.forEach((e) => {
				this._tableBody.insertBefore(e, null);
			});
		} else rows.forEach((e) => {
			this._tableBody.insertBefore(e, null);
		});
	}
	_handleFilterRows() {
		const unfilteredRows = [];
		forEach(this._tableRows, (elem) => {
			let rowText = elem.textContent?.trim();
			let filtered = this.filterRows(rowText, this._searchValue);
			elem.filtered = filtered;
			if (filtered && this.expandable) {
				rowText = elem.nextElementSibling.textContent?.trim();
				filtered = this.filterRows(rowText, this._searchValue);
				elem.filtered = filtered;
			}
			if (!filtered) unfilteredRows.push(elem);
			if (this.isSelectable) {
				const unfilteredSelectableLength = unfilteredRows.filter((elem) => {
					return !elem.hasAttribute("disabled");
				}).length;
				const headerCheckbox = this._tableHeaderRow.shadowRoot?.querySelector(`cds-custom-checkbox`).shadowRoot.querySelector(`.cds-custom--checkbox`);
				headerCheckbox.disabled = unfilteredSelectableLength === 0;
			}
			if (this.expandable) elem.nextElementSibling.filtered = filtered;
		});
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { unfilteredRows }
		};
		this.dispatchEvent(new CustomEvent(this.constructor.eventTableFiltered, init));
	}
	/**
	* Download manager for selected rows.
	*/
	_handleDownload({ target }) {
		const data = [];
		const elementsToArray = (elements) => Array.from(elements, (element) => element.textContent);
		const headerCells = this.querySelectorAll(this.constructor.selectorHeaderCell);
		const rows = this._selectedRows;
		const headerTitleArray = elementsToArray(headerCells);
		rows.forEach((row) => {
			const rowData = {};
			elementsToArray(row.querySelectorAll(this.constructor.selectorTableRowCells)).forEach((cellText, index) => {
				const headerTitle = headerTitleArray[index];
				rowData[headerTitle] = cellText;
			});
			data.push(rowData);
		});
		const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
		target.href = URL.createObjectURL(blob);
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "table");
		/**
		* If using `with-row-slugs`, set `with-row-ai-labels` attribute to true so
		* the styles are applied for slug as well
		*
		* remove in v12
		*/
		if (this.withRowSlugs) {
			this.setAttribute("with-rows-ai-labels", "");
			this.withRowAILabels = true;
		}
		super.connectedCallback();
	}
	firstUpdated() {
		this._tableBatchActions = this.querySelector(this.constructor.selectorTableBatchActions);
		this._tableToolbar = this.querySelector(this.constructor.selectorTableToolbar);
		this._tableToolbarContent = this.querySelector(this.constructor.selectorTableToolbarContent);
		this._tableBody = this.querySelector(this.constructor.selectorTableBody);
		this._tableHeaderRow = this.querySelector(this.constructor.selectorRowsWithHeader);
		this._tableExpandedRows = this.querySelectorAll(this.constructor.selectorTableExpandedRows);
		this._tableRows = this.querySelectorAll(this.constructor.selectorTableRow);
		this._downloadButton = this.querySelector(this.constructor.selectorToolbarDownload);
		if (this._downloadButton) this._downloadButton.onclick = this._handleDownload.bind(this);
		this.headerCount = this._tableHeaderRow.children.length;
	}
	updateExpandable() {
		const { selectorTableExpandedRows } = this.constructor;
		this._tableRows.forEach((e, index) => {
			const hasExpandedRow = e.nextElementSibling?.matches(selectorTableExpandedRows);
			e.expandable = this.expandable && hasExpandedRow;
			e.setAttribute("sort-id", index);
		});
		this._tableHeaderRow.expandable = this.expandable;
		this._tableHeaderRow.batchExpansion = this.batchExpansion;
		this.headerCount += this.expandable ? 1 : -1;
	}
	updated(changedProperties) {
		if (changedProperties.has("expandable")) this.updateExpandable();
		if (changedProperties.has("headerCount")) this._tableExpandedRows.forEach((e) => {
			e.setAttribute("colspan", this.headerCount);
		});
		if (changedProperties.has("isSelectable")) {
			if (this.isSelectable) {
				this._tableHeaderRow.setAttribute("selection-name", "header");
				this._tableRows.forEach((e, index) => {
					if (!e.hasAttribute("selection-name")) e.setAttribute("selection-name", index);
				});
			}
			this.headerCount++;
		}
		if (changedProperties.has("locale")) this.collator = new Intl.Collator(this.locale);
		if (changedProperties.has("isSortable")) {
			if (this.isSortable) this._enableSortAction();
		}
		if (changedProperties.has("overflowMenuOnHover") || changedProperties.has("size")) forEach(this.querySelectorAll(this.constructor.selectorTableCellOverflowMenu), (elem) => {
			const cell = elem.parentNode;
			const row = cell.parentNode;
			cell.overflowMenuOnHover = this.overflowMenuOnHover;
			row.overflowMenuOnHover = this.overflowMenuOnHover;
			cell.setAttribute("size", this.size);
			elem.setAttribute("size", this.size);
			elem.setAttribute("data-table", "");
		});
		if (changedProperties.has("radio")) {
			forEach(this.querySelectorAll(this.constructor.selectorTableRow), (elem) => {
				elem.radio = this.radio;
			});
			if (this._tableHeaderRow) this._tableHeaderRow.hideCheckbox = this.radio;
		}
		if (changedProperties.has("size")) {
			forEach(this.querySelectorAll(this.constructor.selectorAllRows), (elem) => {
				elem.setAttribute("size", this.size);
			});
			const normalizedSize = this.normalizeToolbarSize(this.size);
			this._tableToolbar?.setAttribute("size", normalizedSize);
			const batchActions = this.querySelector(this.constructor.selectorTableBatchActions);
			if (batchActions) batchActions.setAttribute("size", normalizedSize);
		}
		if (changedProperties.has("useZebraStyles")) {
			const tableBody = this.querySelector(this.constructor.selectorTableBody);
			tableBody.useZebraStyles = this.useZebraStyles;
		}
		if (this.withRowAILabels) {
			this._tableHeaderRow.setAttribute("rows-with-ai-label", "");
			this._tableRows.forEach((row) => {
				row.setAttribute("rows-with-ai-label", "");
			});
		} else {
			this._tableHeaderRow.removeAttribute("rows-with-ai-label");
			this._tableRows.forEach((row) => {
				row.removeAttribute("rows-with-ai-label");
			});
		}
		const headersWithAILabel = [];
		Array.prototype.slice.call(this._tableHeaderRow.children).forEach((headerCell, index) => {
			if (headerCell.querySelector(`cds-custom-ai-label`) || headerCell.querySelector(`cds-custom-slug`)) {
				headerCell.setAttribute("ai-label", "");
				headersWithAILabel.push(index);
			} else headerCell.removeAttribute("ai-label");
		});
		this._tableRows.forEach((row) => {
			Array.prototype.slice.call(row.children).forEach((cell, index) => {
				if (headersWithAILabel.includes(index)) cell.setAttribute("ai-label-in-header", "");
				else cell.removeAttribute("ai-label-in-header");
			});
		});
	}
	render() {
		return html` <div class="${"cds-custom"}--data-table-header-container">
        <div ?hidden="${!this.withHeader}" class="${"cds-custom"}--data-table-header">
          <slot @slotchange="${this._handleSlotChange}" name="title"></slot>
          <slot
            @slotchange="${this._handleSlotChange}"
            name="description"></slot>
        </div>
        <slot name="toolbar"></slot>
      </div>

      <div part="inner-container" class="${"cds-custom"}--data-table_inner-container">
        <div part="content" class="${"cds-custom"}--data-table-content">
          <slot
            @cds-custom-table-body-content-change="${this._handleTableBodyChange}"></slot>
        </div>
      </div>`;
	}
	/**
	* Adds isSortable value for table header cells.
	*/
	_enableSortAction() {
		this.querySelectorAll(this.constructor.selectorHeaderCell).forEach((e) => {
			e.isSortable = this.isSortable;
			e.isSelectable = this.isSelectable;
			e.isExpandable = this.expandable;
		});
		const columns = [...this._tableHeaderRow.children];
		let sortDirection;
		let columnIndex = 0;
		columns.forEach((column, index) => {
			if (column.hasAttribute("sort-direction") && column.getAttribute("sort-direction") !== "none") {
				sortDirection = column.getAttribute("sort-direction");
				columnIndex = index;
			}
		});
		columns.forEach((e, index) => {
			if (index !== columnIndex && this.isSortable) e.setAttribute("sort-direction", "none");
			else if (e.hasAttribute("is-sortable")) e.setAttribute("sort-direction", "none");
		});
		this._handleSortAction(columnIndex, sortDirection);
	}
	/**
	* The name of the custom event fired before a new sort direction is set upon a user gesture.
	* Cancellation of this event stops the user-initiated change in sort direction.
	*/
	static get eventBeforeSort() {
		return `cds-custom-table-header-cell-sort`;
	}
	/**
	* The name of the custom event fired during search bar input
	*/
	static get eventSearchInput() {
		return `cds-custom-search-input`;
	}
	/**
	* The name of the custom event fired before header row is selected/unselected upon a user gesture.
	*/
	static get eventBeforeChangeSelectionAll() {
		return `cds-custom-table-change-selection-all`;
	}
	/**
	* The name of the custom event fired before a row is selected/unselected upon a user gesture.
	*/
	static get eventBeforeChangeSelection() {
		return `cds-custom-table-row-change-selection`;
	}
	/**
	* The name of the custom event fired after the Cancel button is clicked.
	*/
	static get eventClickCancel() {
		return `cds-custom-table-batch-actions-cancel-clicked`;
	}
	/**
	* The name of the custom event fired after the expanded state a row is toggled upon a user gesture.
	*/
	static get eventExpandoToggle() {
		return `cds-custom-table-row-expando-toggled`;
	}
	/**
	* The name of the custom event fired after a row has been selected
	*/
	static get eventTableRowSelect() {
		return `cds-custom-table-row-selected`;
	}
	/**
	* The name of the custom event fired after all rows have been selected
	*/
	static get eventTableRowSelectAll() {
		return `cds-custom-table-row-all-selected`;
	}
	/**
	* The name of the custom event fired after the table has been sorted
	*/
	static get eventTableSorted() {
		return `cds-custom-table-sorted`;
	}
	/**
	* The name of the custom event fired after the table has been filtered containing remaining rows.
	*/
	static get eventTableFiltered() {
		return `cds-custom-table-filtered`;
	}
	/**
	* The CSS selector to find the overflow menu on the table cell
	*/
	static get selectorTableCellOverflowMenu() {
		return `cds-custom-table-cell cds-custom-overflow-menu`;
	}
	/**
	* The CSS selector to find the download button
	*/
	static get selectorToolbarDownload() {
		return `cds-custom-button[download]`;
	}
	/**
	* The CSS selector to find the table batch actions
	*/
	static get selectorTableBatchActions() {
		return `cds-custom-table-batch-actions`;
	}
	/**
	* The CSS selector to find the table toolbar
	*/
	static get selectorTableToolbar() {
		return `cds-custom-table-toolbar`;
	}
	/**
	* The CSS selector to find the table toolbar content
	*/
	static get selectorTableToolbarContent() {
		return `cds-custom-table-toolbar-content`;
	}
	/**
	* The CSS selector to find the table toolbar search
	*/
	static get selectorTableToolbarSearch() {
		return `cds-custom-table-toolbar-search`;
	}
	/**
	* The CSS selector to find the table head
	*/
	static get selectorTableHead() {
		return `cds-custom-table-head`;
	}
	/**
	* The CSS selector to find the table body
	*/
	static get selectorTableBody() {
		return `cds-custom-table-body`;
	}
	/**
	* The CSS selector to find the table expanded rows
	*/
	static get selectorTableExpandedRows() {
		return `cds-custom-table-expanded-row`;
	}
	/**
	* The CSS selector to find the table rows
	*/
	static get selectorTableRow() {
		return `cds-custom-table-row`;
	}
	/**
	* The CSS selector to find the rows cells.
	*/
	static get selectorTableRowCells() {
		return `cds-custom-table-cell`;
	}
	/**
	* The CSS selector to find the rows cells, including header cells.
	*/
	static get selectorTableCells() {
		return `cds-custom-table-cell, cds-custom-table-header-cell`;
	}
	/**
	* The CSS selector to find the header cell
	*/
	static get selectorHeaderCell() {
		return `cds-custom-table-header-cell`;
	}
	/**
	* The CSS selector to find the rows, including header rows.
	*/
	static get selectorRowsWithHeader() {
		return `cds-custom-table-header-row,cds-custom-table-row`;
	}
	/**
	* The CSS selector to find all rows
	*/
	static get selectorAllRows() {
		return `cds-custom-table-header-row,cds-custom-table-row,cds-custom-table-expanded-row`;
	}
	static {
		this.styles = data_table_default;
	}
};
__decorate([state()], CDSTable.prototype, "_downloadButton", void 0);
__decorate([state()], CDSTable.prototype, "_searchValue", void 0);
__decorate([state()], CDSTable.prototype, "_tableHeaderRow", void 0);
__decorate([state()], CDSTable.prototype, "_tableBody", void 0);
__decorate([state()], CDSTable.prototype, "_tableExpandedRows", void 0);
__decorate([state()], CDSTable.prototype, "_tableRows", void 0);
__decorate([state()], CDSTable.prototype, "_tableBatchActions", void 0);
__decorate([state()], CDSTable.prototype, "_tableToolbar", void 0);
__decorate([state()], CDSTable.prototype, "_tableToolbarContent", void 0);
__decorate([state()], CDSTable.prototype, "_selectedRows", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "batch-expansion"
})], CDSTable.prototype, "batchExpansion", void 0);
__decorate([property({ attribute: false })], CDSTable.prototype, "collator", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTable.prototype, "expandable", void 0);
__decorate([property()], CDSTable.prototype, "filterRows", void 0);
__decorate([property()], CDSTable.prototype, "headerCount", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-selectable"
})], CDSTable.prototype, "isSelectable", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-sortable"
})], CDSTable.prototype, "isSortable", void 0);
__decorate([property({ reflect: true })], CDSTable.prototype, "locale", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "overflow-menu-on-hover"
})], CDSTable.prototype, "overflowMenuOnHover", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTable.prototype, "radio", void 0);
__decorate([property({ reflect: true })], CDSTable.prototype, "size", void 0);
__decorate([property({
	type: Boolean,
	attribute: "use-static-width",
	reflect: true
})], CDSTable.prototype, "useStaticWidth", void 0);
__decorate([property({
	type: Boolean,
	attribute: "use-zebra-styles",
	reflect: true
})], CDSTable.prototype, "useZebraStyles", void 0);
__decorate([property({
	type: Boolean,
	attribute: "with-header",
	reflect: true
})], CDSTable.prototype, "withHeader", void 0);
__decorate([property({
	type: Boolean,
	attribute: "with-row-ai-labels"
})], CDSTable.prototype, "withRowAILabels", void 0);
__decorate([property({
	type: Boolean,
	attribute: "with-row-slugs"
})], CDSTable.prototype, "withRowSlugs", void 0);
__decorate([HostListener("eventExpandoToggle")], CDSTable.prototype, "_handleBatchExpansion", void 0);
__decorate([HostListener("eventBeforeSort")], CDSTable.prototype, "_handleSort", void 0);
__decorate([HostListener("eventSearchInput")], CDSTable.prototype, "_handleSearchInput", void 0);
__decorate([HostListener("eventBeforeChangeSelection")], CDSTable.prototype, "_handleRowSelect", void 0);
__decorate([HostListener("eventBeforeChangeSelectionAll")], CDSTable.prototype, "_handleAllRowsSelect", void 0);
__decorate([HostListener("eventClickCancel")], CDSTable.prototype, "_handleCancelSelection", void 0);
//#endregion
export { TABLE_SIZE, CDSTable as default };

//# sourceMappingURL=table.js.map