/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html } from "lit";
//#region src/components/data-table/table-header-title.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Data table header title
*
* @element cds-custom-table-header-title
*/
var CDSTableHeader = class extends LitElement {
	static {
		this.is = `cds-custom-table-header-title`;
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = data_table_default;
	}
};
//#endregion
export { CDSTableHeader as default };

//# sourceMappingURL=table-header-title.js.map