/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html, nothing } from "lit";
import { property, query } from "lit/decorators.js";
//#region src/components/data-table/table-batch-actions.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Table batch actions.
*
* @element cds-custom-table-batch-actions
* @fires cds-custom-table-batch-actions-cancel-clicked - The custom event fired after the Cancel button is clicked.
* @fires cds-custom-table-batch-actions-select-all-clicked - The custom event fired after the Select all button is clicked.
*/
var CDSTableBatchActions = class CDSTableBatchActions extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.active = false;
		this.formatSelectedItemsCount = ({ count }) => `${count} item${count <= 1 ? "" : "s"} selected`;
		this.selectedRowsCount = 0;
		this.totalRowsCount = 0;
		this.size = "lg";
	}
	static {
		this.is = `cds-custom-table-batch-actions`;
	}
	/**
	* Handles `click` event on the Cancel button.
	*/
	_handleCancel() {
		const { eventClickCancel } = this.constructor;
		this.dispatchEvent(new CustomEvent(eventClickCancel, {
			bubbles: true,
			composed: true
		}));
	}
	/**
	* Handles `click` event on the Select all button.
	*/
	_handleSelectAll() {
		this.dispatchEvent(new CustomEvent(CDSTableBatchActions.eventClickSelectAll, {
			bubbles: true,
			composed: true
		}));
	}
	firstUpdated() {
		this._updateButtons();
		this._setupHoverListeners();
	}
	_setupHoverListeners() {
		if (this._slotElement && this._cancelButton) {
			const setupListeners = () => {
				const buttons = this._slotElement?.assignedElements();
				if (!buttons) return;
				const lastButton = buttons[buttons.length - 1];
				if (lastButton) {
					const handleEnter = () => {
						this._cancelButton?.style.setProperty("--divider-opacity", "0");
					};
					const handleLeave = () => {
						this._cancelButton?.style.setProperty("--divider-opacity", "1");
					};
					lastButton.removeEventListener("mouseenter", handleEnter);
					lastButton.removeEventListener("mouseleave", handleLeave);
					lastButton.addEventListener("mouseenter", handleEnter);
					lastButton.addEventListener("mouseleave", handleLeave);
				}
			};
			setupListeners();
			this._slotElement.addEventListener("slotchange", setupListeners);
		}
	}
	updated(changedProperties) {
		if (changedProperties.has("active")) this.setAttribute("tabindex", `${this.active ? "" : "-1"}`);
		if (changedProperties.has("size")) this._updateButtons();
	}
	_updateButtons() {
		this.querySelectorAll(this.constructor.selectorButtons).forEach((button) => {
			button.setAttribute("batch-action", "");
			button.setAttribute("size", this.size);
		});
	}
	render() {
		const { formatSelectedItemsCount, selectedRowsCount, totalRowsCount, _handleCancel: handleCancel, _handleSelectAll: handleSelectAll, size } = this;
		return html`
      <div class="${"cds-custom"}--batch-summary">
        <p class="${"cds-custom"}--batch-summary__para">
          ${formatSelectedItemsCount({ count: selectedRowsCount })}
        </p>
        ${totalRowsCount > 0 ? html`
              <span class="${"cds-custom"}--batch-summary__divider">|</span>
              <button
                class="${"cds-custom"}--btn ${"cds-custom"}--btn--primary ${"cds-custom"}--batch-summary__select-all"
                @click=${handleSelectAll}>
                <slot name="select-all-button-content"
                  >Select all (${totalRowsCount})</slot
                >
              </button>
            ` : nothing}
      </div>

      <div class="${"cds-custom"}--action-list">
        <slot></slot>
        <cds-custom-button
          kind="primary"
          size="${size}"
          class="${"cds-custom"}--batch-summary__cancel"
          batch-action
          @click=${handleCancel}>
          <slot name="cancel-button-content">Cancel</slot>
        </cds-custom-button>
      </div>
    `;
	}
	/**
	* The CSS selector to find the action buttons.
	*/
	static get selectorButtons() {
		return `cds-custom-button`;
	}
	/**
	* The name of the custom event fired after the Cancel button is clicked.
	*/
	static get eventClickCancel() {
		return `cds-custom-table-batch-actions-cancel-clicked`;
	}
	/**
	* The name of the custom event fired after the Select all button is clicked.
	*/
	static get eventClickSelectAll() {
		return `cds-custom-table-batch-actions-select-all-clicked`;
	}
	static {
		this.styles = data_table_default;
	}
};
__decorate([query("slot")], CDSTableBatchActions.prototype, "_slotElement", void 0);
__decorate([query(`cds-custom-button.cds-custom--batch-summary__cancel`)], CDSTableBatchActions.prototype, "_cancelButton", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableBatchActions.prototype, "active", void 0);
__decorate([property({ attribute: false })], CDSTableBatchActions.prototype, "formatSelectedItemsCount", void 0);
__decorate([property({
	type: Number,
	attribute: "selected-rows-count"
})], CDSTableBatchActions.prototype, "selectedRowsCount", void 0);
__decorate([property({
	type: Number,
	attribute: "total-rows-count"
})], CDSTableBatchActions.prototype, "totalRowsCount", void 0);
__decorate([property({ reflect: true })], CDSTableBatchActions.prototype, "size", void 0);
//#endregion
export { CDSTableBatchActions as default };

//# sourceMappingURL=table-batch-actions.js.map