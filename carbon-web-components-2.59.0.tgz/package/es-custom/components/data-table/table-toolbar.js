/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/data-table/table-toolbar.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Table toolbar.
*
* @element cds-custom-table-toolbar
*/
var CDSTableToolbar = class extends LitElement {
	static {
		this.is = `cds-custom-table-toolbar`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "toolbar");
		super.connectedCallback();
	}
	updated(changedProperties) {
		if (changedProperties.has("size")) {
			const toolbarContent = this.querySelector(this.constructor.selectorToolbarContent);
			const batchActions = this.querySelector(this.constructor.selectorBatchActions);
			if (toolbarContent) toolbarContent.setAttribute("size", this.size);
			if (batchActions) batchActions.setAttribute("size", this.size);
		}
	}
	render() {
		return html` <slot></slot> `;
	}
	/**
	* The CSS selector to find the toolbar contents
	*/
	static get selectorToolbarContent() {
		return `cds-custom-table-toolbar-content`;
	}
	/**
	* The CSS selector to find the batch actions
	*/
	static get selectorBatchActions() {
		return `cds-custom-table-batch-actions`;
	}
	static {
		this.styles = data_table_default;
	}
};
__decorate([property({ reflect: true })], CDSTableToolbar.prototype, "size", void 0);
//#endregion
export { CDSTableToolbar as default };

//# sourceMappingURL=table-toolbar.js.map