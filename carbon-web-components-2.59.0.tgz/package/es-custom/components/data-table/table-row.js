/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import FocusMixin from "../../globals/mixins/focus.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../checkbox/index.js";
import data_table_default from "./data-table.scss.js";
import "../radio-button/index.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import ChevronRight16 from "@carbon/icons/es/chevron--right/16.js";
//#region src/components/data-table/table-row.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Data table row.
*
* @element cds-custom-table-row
* @csspart selection-container The container of the checkbox.
* @csspart selection The checkbox.
* @fires cds-custom-table-row-change-selection
*   The custom event fired before this row is selected/unselected upon a user gesture.
*   Cancellation of this event stops the user-initiated change in selection.
* @fires cds-custom-radio-button-changed
*   The name of the custom event fired after this radio button changes its checked state.
* @fires cds-custom-checkbox-changed
*   The name of the custom event fired after this checkbox changes its checked state.
* @fires cds-custom-table-row-expando-beingtoggled
*   The name of the custom event fired before the expanded state of this row is being toggled upon a user gesture.
*   Cancellation of this event stops the user-initiated action of toggling the expanded state.
* @fires cds-custom-table-row-expando-toggled
*   The name of the custom event fired after the expanded state of this row is toggled upon a user gesture.
*/
var CDSTableRow = class extends HostListenerMixin(FocusMixin(LitElement)) {
	constructor(..._args) {
		super(..._args);
		this._hasAILabel = false;
		this.batchExpansion = false;
		this.disabled = false;
		this.even = false;
		this.expandable = false;
		this.expanded = false;
		this.filtered = false;
		this.hideCheckbox = false;
		this.highlighted = false;
		this.odd = false;
		this.overflowMenuOnHover = false;
		this.radio = false;
		this.selected = false;
		this.selectionLabel = "Select row";
		this.selectionName = "";
		this.selectionValue = "";
	}
	static {
		this.is = `cds-custom-table-row`;
	}
	/**
	* Handles `click` event on the radio button.
	*
	* @param event The event.
	*/
	_handleClickSelectionRadio(event) {
		const { detail } = event;
		const selected = detail.checked;
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { selected }
		};
		const constructor = this.constructor;
		if (this.dispatchEvent(new CustomEvent(constructor.eventBeforeChangeSelection, init))) {
			this.selected = selected;
			const { selectorExpandedRow } = this.constructor;
			if (this.nextElementSibling?.matches(selectorExpandedRow)) this.nextElementSibling.selected = selected;
		}
	}
	/**
	* Handles `click` event on the check box.
	*
	* @param event The event.
	*/
	_handleClickSelectionCheckbox(event) {
		const { detail } = event;
		const selected = detail.checked;
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { selected }
		};
		const constructor = this.constructor;
		if (this.dispatchEvent(new CustomEvent(constructor.eventBeforeChangeSelection, init))) {
			this.selected = selected;
			const { selectorExpandedRow } = this.constructor;
			if (this.nextElementSibling?.matches(selectorExpandedRow)) this.nextElementSibling.selected = selected;
		}
	}
	/**
	* Handles `click` event on the expando button.
	*/
	_handleClickExpando() {
		this._handleUserInitiatedToggleExpando();
	}
	/**
	* Handles `mouseover`/`mouseout` event handler on this element.
	*
	* @param event The event.
	*/
	_handleMouseOverOut(event) {
		const { selectorExpandedRow, selectorTableCellOverflowMenu } = this.constructor;
		const { nextElementSibling } = this;
		if (nextElementSibling?.matches(selectorExpandedRow)) nextElementSibling.highlighted = event.type === "mouseover";
		if (this.overflowMenuOnHover) {
			const parentCell = this.querySelector(selectorTableCellOverflowMenu)?.parentElement;
			if (event.type === "mouseout") parentCell.overflowMenuOnHover = true;
			else parentCell.overflowMenuOnHover = false;
		}
	}
	/**
	* Handles user-initiated toggle request of the expando button in this table row.
	*
	* @param expanded The new expanded state.
	*/
	_handleUserInitiatedToggleExpando(expanded = !this.expanded) {
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { expanded }
		};
		if (this.dispatchEvent(new CustomEvent(this.constructor.eventBeforeExpandoToggle, init))) {
			this.expanded = expanded;
			this.dispatchEvent(new CustomEvent(this.constructor.eventExpandoToggle, init));
		}
	}
	_renderExpandButton() {
		const { _handleClickExpando: handleClickExpando } = this;
		return html`
      <div class="${"cds-custom"}--table-expand">
        <div>
          <slot name="ai-label" @slotchange="${this._handleSlotChange}"></slot>
          <slot name="slug" @slotchange="${this._handleSlotChange}"></slot>
          ${this.expandable ? html`<button
                class="${"cds-custom"}--table-expand__button"
                @click="${handleClickExpando}">
                ${iconLoader(ChevronRight16, { class: `cds-custom--table-expand__svg` })}
              </button>` : html`&nbsp;`}
          <!-- Add non-breaking space for proper styling -->
        </div>
      </div>
    `;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		const hasContent = target.assignedNodes().filter((elem) => elem.matches !== void 0 ? elem.matches(this.constructor.aiLabelItem) || elem.matches(this.constructor.slugItem) : false);
		if (hasContent.length > 0) {
			this._hasAILabel = Boolean(hasContent);
			hasContent[0].setAttribute("size", "mini");
		}
		this.requestUpdate();
	}
	/**
	* @returns The first set of table cells.
	*/
	_renderFirstCells() {
		const { disabled, hideCheckbox, radio, selected, selectionLabel, selectionName, selectionValue } = this;
		return !selectionName ? void 0 : html`
          <div class="${"cds-custom"}--table-column-checkbox">
            <div>
              <slot
                name="ai-label"
                @slotchange="${this._handleSlotChange}"></slot>
              <slot name="slug" @slotchange="${this._handleSlotChange}"></slot>
              ${radio ? html`<cds-custom-radio-button data-table></cds-custom-radio-button>` : html`<cds-custom-checkbox
                    hide-label
                    ?hide-checkbox="${hideCheckbox}"
                    label-text="${selectionLabel}"
                    name=${selectionName}
                    data-table
                    ?disabled=${disabled}
                    ?checked=${selected}
                    value=${selectionValue}></cds-custom-checkbox> `}
            </div>
          </div>
        `;
	}
	/**
	* TODO: Uncomment when Carbon fully implements sticky header
	* Specify whether the header should be sticky.
	* Still experimental: may not work with every combination of table props
	*/
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "row");
		super.connectedCallback();
	}
	updated(changedProperties) {
		if (changedProperties.has("expanded")) {
			const { selectorExpandedRow } = this.constructor;
			const { expanded, nextElementSibling } = this;
			if (nextElementSibling?.matches(selectorExpandedRow)) nextElementSibling.expanded = expanded;
		}
		if (changedProperties.has("highlighted")) {
			const { selectorExpandedRow } = this.constructor;
			const { highlighted, nextElementSibling } = this;
			if (nextElementSibling?.matches(selectorExpandedRow)) nextElementSibling.highlighted = highlighted;
		}
		if (this._hasAILabel) this.setAttribute("ai-label", "");
		else this.removeAttribute("ai-label");
	}
	render() {
		if (this.selectionName) this.closest(this.constructor.selectorTable)?.setAttribute("is-selectable", "");
		return html`
      ${this.closest(this.constructor.selectorTable)?.hasAttribute("expandable") ? this._renderExpandButton() : ""}
      ${this._renderFirstCells()}
      <slot></slot>
    `;
	}
	/**
	* The name of the custom event fired after this radio button changes its checked state.
	*/
	static get eventRadioChange() {
		return `cds-custom-radio-button-changed`;
	}
	/**
	* The name of the custom event fired after this radio button changes its checked state.
	*/
	static get eventCheckboxChange() {
		return `cds-custom-checkbox-changed`;
	}
	/**
	* The name of the custom event fired before this row is selected/unselected upon a user gesture.
	* Cancellation of this event stops the user-initiated change in selection.
	*/
	static get eventBeforeChangeSelection() {
		return `cds-custom-table-row-change-selection`;
	}
	/**
	* A selector that will return the parent table
	*/
	static get selectorTable() {
		return `cds-custom-table`;
	}
	/**
	* The CSS selector to find the overflow menu on the table cell
	*/
	static get selectorTableCellOverflowMenu() {
		return `cds-custom-table-cell cds-custom-overflow-menu`;
	}
	/**
	* A selector that will return the corresponding expanded row.
	*/
	static get selectorExpandedRow() {
		return `cds-custom-table-expanded-row`;
	}
	/**
	* A selector that will return the slug item.
	*
	* remove in v12
	*/
	static get slugItem() {
		return `cds-custom-slug`;
	}
	/**
	* A selector that will return the AI Label item.
	*/
	static get aiLabelItem() {
		return `cds-custom-ai-label`;
	}
	/**
	* The name of the custom event fired before the expanded state this row is being toggled upon a user gesture.
	* Cancellation of this event stops the user-initiated action of toggling the expanded state.
	*/
	static get eventBeforeExpandoToggle() {
		return `cds-custom-table-row-expando-beingtoggled`;
	}
	/**
	* The name of the custom event fired after the expanded state this row is toggled upon a user gesture.
	*/
	static get eventExpandoToggle() {
		return `cds-custom-table-row-expando-toggled`;
	}
	static {
		this.styles = data_table_default;
	}
};
__decorate([HostListener("eventRadioChange")], CDSTableRow.prototype, "_handleClickSelectionRadio", null);
__decorate([HostListener("eventCheckboxChange")], CDSTableRow.prototype, "_handleClickSelectionCheckbox", null);
__decorate([HostListener("mouseover"), HostListener("mouseout")], CDSTableRow.prototype, "_handleMouseOverOut", null);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "batch-expansion"
})], CDSTableRow.prototype, "batchExpansion", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableRow.prototype, "disabled", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableRow.prototype, "even", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableRow.prototype, "expandable", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableRow.prototype, "expanded", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableRow.prototype, "filtered", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-checkbox"
})], CDSTableRow.prototype, "hideCheckbox", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableRow.prototype, "highlighted", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableRow.prototype, "odd", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "overflow-menu-on-hover"
})], CDSTableRow.prototype, "overflowMenuOnHover", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableRow.prototype, "radio", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableRow.prototype, "selected", void 0);
__decorate([property({ attribute: "selection-label" })], CDSTableRow.prototype, "selectionLabel", void 0);
__decorate([property({ attribute: "selection-name" })], CDSTableRow.prototype, "selectionName", void 0);
__decorate([property({ attribute: "selection-value" })], CDSTableRow.prototype, "selectionValue", void 0);
//#endregion
export { CDSTableRow as default };

//# sourceMappingURL=table-row.js.map