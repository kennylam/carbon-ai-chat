/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/data-table/table-cell.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Data table cell.
*
* @element cds-custom-table-cell
*/
var CDSTableCell = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.overflowMenuOnHover = false;
	}
	static {
		this.is = `cds-custom-table-cell`;
	}
	/**
	* TODO: Uncomment when Carbon fully implements sticky header
	* Specify whether the header should be sticky.
	* Still experimental: may not work with every combination of table props
	*/
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "cell");
		super.connectedCallback();
	}
	render() {
		return html`<slot></slot>`;
	}
	static {
		this.styles = data_table_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "overflow-menu-on-hover"
})], CDSTableCell.prototype, "overflowMenuOnHover", void 0);
__decorate([property({ reflect: true })], CDSTableCell.prototype, "size", void 0);
//#endregion
export { CDSTableCell as default };

//# sourceMappingURL=table-cell.js.map