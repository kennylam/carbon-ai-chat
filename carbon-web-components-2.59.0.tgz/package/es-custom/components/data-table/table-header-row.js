/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSTableRow from "./table-row.js";
//#region src/components/data-table/table-header-row.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Data table header row.
*
* @element cds-custom-table-header-row
* @fires cds-custom-table-change-selection-all
*   The name of the custom event fired before this row is selected/unselected upon a user gesture.
*   Cancellation of this event stops the user-initiated change in selection.
*/
var CDSTableHeaderRow = class extends CDSTableRow {
	static {
		this.is = `cds-custom-table-header-row`;
	}
	/**
	* The name of the custom event fired before this row is selected/unselected upon a user gesture.
	* Cancellation of this event stops the user-initiated change in selection.
	*/
	static get eventBeforeChangeSelection() {
		return `cds-custom-table-change-selection-all`;
	}
};
//#endregion
export { CDSTableHeaderRow as default };

//# sourceMappingURL=table-header-row.js.map