/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html } from "lit";
//#region src/components/data-table/table-head.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Data table header.
*
* @element cds-custom-table-head
*/
var CDSTableHead = class extends LitElement {
	static {
		this.is = `cds-custom-table-head`;
	}
	/**
	* TODO: Uncomment when Carbon fully implements sticky header
	* Specify whether the header should be sticky.
	* Still experimental: may not work with every combination of table props
	*/
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "rowgroup");
		super.connectedCallback();
	}
	render() {
		return html` <slot></slot> `;
	}
	static {
		this.styles = data_table_default;
	}
};
//#endregion
export { CDSTableHead as default };

//# sourceMappingURL=table-head.js.map