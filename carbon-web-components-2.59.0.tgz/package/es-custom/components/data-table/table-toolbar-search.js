/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../search/defs.js";
import CDSSearch from "../search/search.js";
import data_table_default from "./data-table.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/data-table/table-toolbar-search.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Table toolbar search.
*
* @element cds-custom-table-toolbar-search
* @fires cds-custom-search-input - The custom event fired after the search content is changed upon a user gesture.
*/
var CDSTableToolbarSearch = class extends HostListenerMixin(CDSSearch) {
	constructor(..._args) {
		super(..._args);
		this.expanded = false;
		this.persistent = false;
		this.size = "lg";
	}
	static {
		this.is = `cds-custom-table-toolbar-search`;
	}
	/**
	* Handles user-initiated gestures for expanding the search box.
	*/
	async _handleUserInitiatedExpand() {
		this.expanded = true;
		await this.updateComplete;
		const { _inputNode: inputNode } = this;
		inputNode?.focus();
	}
	/**
	* Handles `focus` event handler on this element.
	*/
	_handleFocusIn() {
		this._handleUserInitiatedExpand();
	}
	/**
	* Handles `blur` event handler on this element.
	*
	* @param event The event.
	*/
	_handleFocusOut(event) {
		if (!this.contains(event.relatedTarget) && !this.value && !this.persistent) this.expanded = false;
	}
	/**
	* Handles `click` event handler on the search box.
	*/
	_handleSearchClick() {
		this._handleUserInitiatedExpand();
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "search");
		super.connectedCallback();
	}
	render() {
		const result = super.render();
		const { persistent, expanded, size, _handleSearchClick: handleSearchClick } = this;
		const classes = classMap({
			[`cds-custom--search`]: true,
			[`cds-custom--search--${size}`]: size
		});
		if (persistent) this.expanded = true;
		return html`
      <div
        class="${classes}"
        tabindex="${expanded ? "-1" : "0"}"
        @click="${handleSearchClick}">
        ${result}
      </div>
    `;
	}
	/**
	* The name of the custom event fired after the search content is changed upon a user gesture.
	*/
	static get eventInput() {
		return `cds-custom-search-input`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = data_table_default;
	}
};
__decorate([query("input")], CDSTableToolbarSearch.prototype, "_inputNode", void 0);
__decorate([HostListener("focusin")], CDSTableToolbarSearch.prototype, "_handleFocusIn", null);
__decorate([HostListener("focusout")], CDSTableToolbarSearch.prototype, "_handleFocusOut", null);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableToolbarSearch.prototype, "expanded", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTableToolbarSearch.prototype, "persistent", void 0);
__decorate([property({ reflect: true })], CDSTableToolbarSearch.prototype, "size", void 0);
//#endregion
export { CDSTableToolbarSearch as default };

//# sourceMappingURL=table-toolbar-search.js.map