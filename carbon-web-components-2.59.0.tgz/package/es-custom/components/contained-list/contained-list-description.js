/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import contained_list_default from "./contained-list.scss.js";
import { LitElement, html } from "lit";
//#region src/components/contained-list/contained-list-description.ts
/**
* Copyright IBM Corp. 2022, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Contained list description text.
*
* @element cds-custom-contained-list-description
* @slot - The description text content
*/
var CDSContainedListDescription = class extends LitElement {
	static {
		this.is = `cds-custom-contained-list-description`;
	}
	render() {
		return html`<slot></slot>`;
	}
	static {
		this.styles = contained_list_default;
	}
};
//#endregion
export { CDSContainedListDescription as default };

//# sourceMappingURL=contained-list-description.js.map