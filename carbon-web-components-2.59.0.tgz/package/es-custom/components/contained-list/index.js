/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSContainedList from "./contained-list.js";
import CDSContainedListItem from "./contained-list-item.js";
import CDSContainedListDescription from "./contained-list-description.js";
//#region src/components/contained-list/index.ts
/**
* Copyright IBM Corp. 2022, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSContainedList);
defineCustomElement(CDSContainedListItem);
defineCustomElement(CDSContainedListDescription);
//#endregion
export { CDSContainedList, CDSContainedListDescription, CDSContainedListItem };

//# sourceMappingURL=index.js.map