/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import contained_list_default from "./contained-list.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/contained-list/contained-list.ts
/**
* Copyright IBM Corp. 2022, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Contained list.
*
* @element cds-custom-contained-list
* @slot - The list items (cds-custom-contained-list-item elements)
* @slot action - The action slot for interactive elements in header
* @slot label - The label text
*/
var CDSContainedList = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.isInset = false;
		this.kind = "on-page";
		this.label = "";
	}
	static {
		this.is = `cds-custom-contained-list`;
	}
	render() {
		const { isInset, kind, label, size } = this;
		const classes = classMap({
			[`cds-custom--contained-list`]: true,
			[`cds-custom--contained-list--${kind}`]: true,
			[`cds-custom--contained-list--inset-rulers`]: isInset,
			[`cds-custom--layout--size-${size}`]: !!size
		});
		const hasLabelSlot = this.querySelector("[slot=\"label\"]") !== null;
		return html`
      <div class="${classes}">
        ${label || hasLabelSlot ? html`
              <div class="${"cds-custom"}--contained-list__header">
                <div class="${"cds-custom"}--contained-list__label">
                  ${hasLabelSlot ? html`<slot name="label"></slot>` : label}
                </div>
                <div class="${"cds-custom"}--contained-list__action">
                  <slot name="action"></slot>
                </div>
              </div>
            ` : ""}
        <ul role="list">
          <slot></slot>
        </ul>
      </div>
    `;
	}
	static {
		this.styles = contained_list_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-inset"
})], CDSContainedList.prototype, "isInset", void 0);
__decorate([property({ reflect: true })], CDSContainedList.prototype, "kind", void 0);
__decorate([property({ reflect: true })], CDSContainedList.prototype, "label", void 0);
__decorate([property({ reflect: true })], CDSContainedList.prototype, "size", void 0);
//#endregion
export { CDSContainedList as default };

//# sourceMappingURL=contained-list.js.map