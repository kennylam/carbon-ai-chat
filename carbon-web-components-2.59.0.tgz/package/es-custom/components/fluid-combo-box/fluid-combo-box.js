/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import CDSComboBox from "../combo-box/combo-box.js";
import fluid_combo_box_default from "./fluid-combo-box.scss.js";
import { property } from "lit/decorators.js";
//#region src/components/fluid-combo-box/fluid-combo-box.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid combo box.
*
* @element cds-custom-fluid-combo-box
*/
var CDSFluidComboBox = class extends CDSComboBox {
	constructor(..._args) {
		super(..._args);
		this.isCondensed = false;
	}
	static {
		this.is = `cds-custom-fluid-combo-box`;
	}
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		if (changedProperties.has("invalid") || changedProperties.has("disabled") || changedProperties.has("readOnly") || changedProperties.has("warn") || changedProperties.has("isCondensed")) this.requestUpdate();
	}
	static {
		this.styles = [CDSComboBox.styles, fluid_combo_box_default];
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-condensed"
})], CDSFluidComboBox.prototype, "isCondensed", void 0);
//#endregion
export { CDSFluidComboBox as default };

//# sourceMappingURL=fluid-combo-box.js.map