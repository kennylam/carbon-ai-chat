/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import fluid_combo_box_default from "./fluid-combo-box.scss.js";
import { LitElement, html } from "lit";
//#region src/components/fluid-combo-box/fluid-combo-box-skeleton.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid combo box skeleton.
*
* @element cds-custom-fluid-combo-box-skeleton
*/
var CDSFluidComboBoxSkeleton = class extends LitElement {
	static {
		this.is = `cds-custom-fluid-combo-box-skeleton`;
	}
	render() {
		return html`
      <div class="${"cds-custom"}--list-box__wrapper--fluid">
        <div class="${"cds-custom"}--skeleton ${"cds-custom"}--list-box">
          <span class="${"cds-custom"}--list-box__label"></span>
          <div class="${"cds-custom"}--list-box__field"></div>
        </div>
      </div>
    `;
	}
	static {
		this.styles = fluid_combo_box_default;
	}
};
//#endregion
export { CDSFluidComboBoxSkeleton as default };

//# sourceMappingURL=fluid-combo-box-skeleton.js.map