/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../toggle-tip/index.js";
import "../ai-label/index.js";
import "../dropdown/index.js";
import "../combo-box/index.js";
import CDSFluidComboBox from "./fluid-combo-box.js";
import CDSFluidComboBoxSkeleton from "./fluid-combo-box-skeleton.js";
//#region src/components/fluid-combo-box/index.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFluidComboBox);
defineCustomElement(CDSFluidComboBoxSkeleton);
//#endregion
export { CDSFluidComboBox, CDSFluidComboBoxSkeleton };

//# sourceMappingURL=index.js.map