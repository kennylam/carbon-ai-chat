/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSTooltip from "./tooltip.js";
import CDSTooltipContent from "./tooltip-content.js";
import CDSDefinitionTooltip from "./definition-tooltip.js";
//#region src/components/tooltip/index.ts
/**
* Copyright IBM Corp. 2021, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSTooltip);
defineCustomElement(CDSTooltipContent);
defineCustomElement(CDSDefinitionTooltip);
//#endregion
export { CDSDefinitionTooltip, CDSTooltip, CDSTooltipContent };

//# sourceMappingURL=index.js.map