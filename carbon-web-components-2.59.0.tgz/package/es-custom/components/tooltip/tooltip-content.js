/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import popover_default from "../popover/popover.scss.js";
import CDSPopoverContent from "../popover/popover-content.js";
import tooltip_default from "./tooltip.scss.js";
import { adoptStyles } from "lit";
//#region src/components/tooltip/tooltip-content.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Tooltip content.
*
* @element cds-custom-tooltip-content
*/
var CDSTooltipContent = class extends CDSPopoverContent {
	static {
		this.is = `cds-custom-tooltip-content`;
	}
	connectedCallback() {
		if (!this.hasAttribute("aria-hidden")) this.setAttribute("aria-hidden", "true");
		if (!this.hasAttribute("role")) this.setAttribute("role", "tooltip");
		super.connectedCallback();
		adoptStyles(this.renderRoot, [popover_default, tooltip_default]);
	}
	updated() {
		this.shadowRoot?.querySelector(`.cds-custom--popover-content`)?.classList.add(`cds-custom--tooltip-content`);
	}
};
//#endregion
export { CDSTooltipContent as default };

//# sourceMappingURL=tooltip-content.js.map