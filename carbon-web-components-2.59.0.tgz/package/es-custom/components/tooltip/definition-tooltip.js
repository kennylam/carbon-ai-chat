/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import { POPOVER_ALIGNMENT } from "../popover/defs.js";
import popover_default from "../popover/popover.scss.js";
import tooltip_default from "./tooltip.scss.js";
import "../popover/index.js";
import { LitElement, adoptStyles, html } from "lit";
import { property, state } from "lit/decorators.js";
//#region src/components/tooltip/definition-tooltip.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Definition tooltip.
*
* @element cds-custom-definition-tooltip
*/
var CDSDefinitionTooltip = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.align = "bottom";
		this.autoalign = false;
		this.defaultOpen = false;
		this.openOnHover = false;
		this.open = false;
		this._tooltipId = `cds-custom--definition-tooltip-${Math.random().toString(16).slice(2)}`;
	}
	static {
		this.is = `cds-custom-definition-tooltip`;
	}
	connectedCallback() {
		super.connectedCallback();
		adoptStyles(this.renderRoot, [popover_default, tooltip_default]);
		if (this.hasAttribute("default-open")) this.open = true;
	}
	_handleBlur() {
		this.open = false;
	}
	_handleMouseDown() {
		this.open = !this.open;
	}
	_handleKeyDown(event) {
		const { key } = event;
		if (key === "Esc" || key === "Escape") {
			if (this.open) {
				event.stopPropagation();
				this.open = false;
			}
		} else if (key === " " || key === "Enter") {
			event.preventDefault();
			this.open = !this.open;
		}
	}
	_handleMouseEnter() {
		if (this.openOnHover) this.open = true;
	}
	_handleMouseLeave() {
		this.open = false;
	}
	_handleFocus() {
		this.open = true;
	}
	render() {
		const { align, open, _tooltipId } = this;
		return html`
      <cds-custom-popover
        @mouseenter=${this._handleMouseEnter}
        @mouseleave=${this._handleMouseLeave}
        highContrast
        ?autoalign=${this.autoalign}
        .dropShadow=${false}
        align=${align}
        .open=${open}>
        <button
          @focus=${this._handleFocus}
          @blur=${this._handleBlur}
          @mousedown=${this._handleMouseDown}
          @keydown=${this._handleKeyDown}
          aria-controls=${_tooltipId}
          aria-describedby=${_tooltipId}
          aria-expanded=${open}
          part="definition-term"
          class="${"cds-custom"}--definition-term">
          <slot></slot>
        </button>
        <cds-custom-popover-content id=${_tooltipId}>
          <slot name="definition"></slot>
        </cds-custom-popover-content>
      </cds-custom-popover>
    `;
	}
	static {
		this.styles = tooltip_default;
	}
};
__decorate([property({
	reflect: true,
	type: POPOVER_ALIGNMENT
})], CDSDefinitionTooltip.prototype, "align", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSDefinitionTooltip.prototype, "autoalign", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "default-open"
})], CDSDefinitionTooltip.prototype, "defaultOpen", void 0);
__decorate([property({
	reflect: true,
	type: Boolean,
	attribute: "open-on-hover"
})], CDSDefinitionTooltip.prototype, "openOnHover", void 0);
__decorate([state()], CDSDefinitionTooltip.prototype, "open", void 0);
//#endregion
export { CDSDefinitionTooltip as default };

//# sourceMappingURL=definition-tooltip.js.map