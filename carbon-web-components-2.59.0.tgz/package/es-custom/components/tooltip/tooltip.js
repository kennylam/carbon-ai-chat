/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import popover_default from "../popover/popover.scss.js";
import CDSPopover from "../popover/popover.js";
import tooltip_default from "./tooltip.scss.js";
import { adoptStyles } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/tooltip/tooltip.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Trigger button of tooltip.
*
* @element cds-custom-tooltip
*/
var CDSTooltip = class extends HostListenerMixin(CDSPopover) {
	constructor(..._args) {
		super(..._args);
		this.align = "top";
		this.autoalign = false;
		this.dataTable = false;
		this.closeOnActivation = false;
		this.defaultOpen = false;
		this.enterDelayMs = 100;
		this.leaveDelayMs = 300;
		this.keyboardOnly = false;
		this.size = false;
		this.timeoutId = 0;
		this.toolbarAction = false;
		this.lastInteractionWasKeyboard = false;
		this._showTooltip = async () => {
			window.clearTimeout(this.timeoutId);
			this.timeoutId = window.setTimeout(async () => {
				this.open = true;
				const { open, updateComplete } = this;
				if (open) {
					await updateComplete;
					const { selectorTooltipContent } = this.constructor;
					this.querySelector(selectorTooltipContent)?.focus();
				}
			}, this.enterDelayMs);
		};
		this._handleHover = (event) => {
			if (this.keyboardOnly) {
				if (event instanceof FocusEvent && this.lastInteractionWasKeyboard) this._showTooltip();
			} else this._showTooltip();
		};
		this._handleHoverOut = async () => {
			window.clearTimeout(this.timeoutId);
			this.timeoutId = window.setTimeout(async () => {
				const { open } = this;
				if (open) this.open = false;
			}, this.leaveDelayMs);
		};
		this._handleClick = async () => {
			this.lastInteractionWasKeyboard = false;
			if (this.closeOnActivation) this._handleHoverOut();
		};
		this._handleKeydown = async (event) => {
			if (event.key === "Tab") this.lastInteractionWasKeyboard = true;
			if (event.key === " " || event.key === "Enter" || event.key === "Escape") {
				this.lastInteractionWasKeyboard = true;
				if (this.closeOnActivation) this._handleHoverOut();
			}
		};
	}
	static {
		this.is = `cds-custom-tooltip`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		const component = target.assignedNodes().filter((node) => node.nodeType !== Node.TEXT_NODE || node.textContent.trim());
		if (!component[0]) return;
		component[0].addEventListener("focus", this._handleHover);
		component[0].addEventListener("focusout", this._handleHoverOut);
		if (!this.keyboardOnly) {
			component[0].addEventListener("mouseover", this._handleHover);
			component[0].addEventListener("mouseleave", this._handleHoverOut);
		}
		this.requestUpdate();
	}
	connectedCallback() {
		if (!this.hasAttribute("highContrast")) this.setAttribute("highContrast", "");
		if (!this.shadowRoot) this.attachShadow({ mode: "open" });
		window.addEventListener("keydown", this._handleKeydown, true);
		super.connectedCallback();
		adoptStyles(this.renderRoot, [popover_default, tooltip_default]);
	}
	disconnectedCallback() {
		window.removeEventListener("keydown", this._handleKeydown, true);
		super.disconnectedCallback();
	}
	updated(changedProperties) {
		const { selectorTooltipContent } = this.constructor;
		const toolTipContent = this.querySelector(selectorTooltipContent);
		if (changedProperties.has("defaultOpen")) this.open = this.defaultOpen;
		if (changedProperties.has("open")) if (this.open) toolTipContent?.setAttribute("open", "");
		else toolTipContent?.removeAttribute("open");
		[
			"align",
			"caret",
			"autoalign",
			"dropShadow"
		].forEach((name) => {
			if (changedProperties.has(name)) {
				const { [name]: value } = this;
				toolTipContent[name] = value;
			}
		});
		if (this.hasAttribute("highcontrast")) toolTipContent?.setAttribute("highcontrast", "");
		this.shadowRoot?.querySelector(`.cds-custom--popover-container`)?.classList.add(`cds-custom--tooltip`);
		super.updated(changedProperties);
	}
	/**
	* A selector that will return the CDSTooltipContent.
	*/
	static get selectorTooltipContent() {
		return `cds-custom-tooltip-content`;
	}
};
__decorate([property({
	reflect: true,
	type: String
})], CDSTooltip.prototype, "align", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTooltip.prototype, "autoalign", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "data-table"
})], CDSTooltip.prototype, "dataTable", void 0);
__decorate([property({
	reflect: true,
	type: Boolean
})], CDSTooltip.prototype, "closeOnActivation", void 0);
__decorate([property({
	reflect: true,
	type: Boolean
})], CDSTooltip.prototype, "defaultOpen", void 0);
__decorate([property({
	attribute: "enter-delay-ms",
	type: Number
})], CDSTooltip.prototype, "enterDelayMs", void 0);
__decorate([property({
	attribute: "leave-delay-ms",
	type: Number
})], CDSTooltip.prototype, "leaveDelayMs", void 0);
__decorate([property({
	attribute: "keyboard-only",
	type: Boolean
})], CDSTooltip.prototype, "keyboardOnly", void 0);
__decorate([property({ reflect: true })], CDSTooltip.prototype, "size", void 0);
__decorate([property({ reflect: true })], CDSTooltip.prototype, "timeoutId", void 0);
__decorate([property({
	reflect: true,
	attribute: "toolbar-action",
	type: Boolean
})], CDSTooltip.prototype, "toolbarAction", void 0);
__decorate([HostListener("click")], CDSTooltip.prototype, "_handleClick", void 0);
__decorate([HostListener("keydown")], CDSTooltip.prototype, "_handleKeydown", void 0);
//#endregion
export { CDSTooltip as default };

//# sourceMappingURL=tooltip.js.map