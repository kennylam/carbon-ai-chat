/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/toggle/defs.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Toggle size.
*/
let TOGGLE_SIZE = /* @__PURE__ */ function(TOGGLE_SIZE) {
	/**
	* Regular size.
	*/
	TOGGLE_SIZE["REGULAR"] = "";
	/**
	* Small size.
	*/
	TOGGLE_SIZE["SMALL"] = "sm";
	return TOGGLE_SIZE;
}({});
//#endregion
export { TOGGLE_SIZE };

//# sourceMappingURL=defs.js.map