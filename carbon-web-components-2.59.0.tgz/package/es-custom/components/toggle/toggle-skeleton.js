/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import toggle_default from "./toggle.scss.js";
import { LitElement, html } from "lit";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/toggle/toggle-skeleton.ts
/**
* Copyright IBM Corp. 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @element cds-custom-toggle-skeleton
*
* Skeleton of toggle.
*/
var CDSToggleSkeleton = class extends LitElement {
	static {
		this.is = `cds-custom-toggle-skeleton`;
	}
	render() {
		return html`
      <div class=${classMap({
			[`cds-custom--toggle`]: true,
			[`cds-custom--toggle--skeleton`]: true
		})}>
        <div class="${"cds-custom"}--toggle__skeleton-circle"></div>
        <div class="${"cds-custom"}--toggle__skeleton-rectangle"></div>
      </div>
    `;
	}
	static {
		this.styles = toggle_default;
	}
};
//#endregion
export { CDSToggleSkeleton as default };

//# sourceMappingURL=toggle-skeleton.js.map