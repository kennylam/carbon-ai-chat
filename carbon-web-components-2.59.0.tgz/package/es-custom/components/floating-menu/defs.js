/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/floating-menu/defs.ts
/**
* Copyright IBM Corp. 2020, 2022, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The LTR/RTL direction used for positioning floating menu.
*/
let FLOATING_MENU_POSITION_DIRECTION = /* @__PURE__ */ function(FLOATING_MENU_POSITION_DIRECTION) {
	/**
	* LTR.
	*/
	FLOATING_MENU_POSITION_DIRECTION["LTR"] = "ltr";
	/**
	* RTL.
	*/
	FLOATING_MENU_POSITION_DIRECTION["RTL"] = "rtl";
	return FLOATING_MENU_POSITION_DIRECTION;
}({});
/**
* The direction/positioning/orientation choices of floating menu.
*/
let FLOATING_MENU_DIRECTION = /* @__PURE__ */ function(FLOATING_MENU_DIRECTION) {
	/**
	* Put menu body at the top of its trigger button.
	*/
	FLOATING_MENU_DIRECTION["TOP"] = "top";
	/**
	* Put menu body at the bottom of its trigger button.
	*/
	FLOATING_MENU_DIRECTION["BOTTOM"] = "bottom";
	/**
	* Put menu body to the left of its trigger button.
	*/
	FLOATING_MENU_DIRECTION["LEFT"] = "left";
	/**
	* Put menu body to the right of its trigger button.
	*/
	FLOATING_MENU_DIRECTION["RIGHT"] = "right";
	return FLOATING_MENU_DIRECTION;
}({});
//#endregion
export { FLOATING_MENU_DIRECTION, FLOATING_MENU_POSITION_DIRECTION };

//# sourceMappingURL=defs.js.map