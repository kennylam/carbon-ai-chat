/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import fluid_form_default from "./fluid-form.scss.js";
import { LitElement, html } from "lit";
//#region src/components/fluid-form/fluid-form.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Presentational element for fluid form
*
* @element cds-custom-fluid-form
*/
var CDSFluidForm = class extends LitElement {
	static {
		this.is = `cds-custom-fluid-form`;
	}
	connectedCallback() {
		super.connectedCallback();
		this.toggleAttribute("in-modal", !!this.closest(`cds-custom-modal-body`));
	}
	render() {
		return html`<form class="${"cds-custom"}--form ${"cds-custom"}--form--fluid">
      <slot></slot>
    </form>`;
	}
	static {
		this.styles = fluid_form_default;
	}
};
//#endregion
export { CDSFluidForm as default };

//# sourceMappingURL=fluid-form.js.map