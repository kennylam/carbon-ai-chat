/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import file_uploader_default from "./file-uploader.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/file-uploader/file-uploader.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The file uploader component.
*
* @element cds-custom-file-uploader
*/
var CDSFileUploader = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.disabled = false;
		this.labelDescription = "";
		this.labelTitle = "";
	}
	static {
		this.is = `cds-custom-file-uploader`;
	}
	updated(changedProperties) {
		if (changedProperties.has("disabled")) {
			const { selectorUploaderItem } = this.constructor;
			const uploaderItem = this.querySelector(selectorUploaderItem);
			uploaderItem.disabled = this.disabled;
		}
	}
	render() {
		const { disabled, labelDescription, labelTitle } = this;
		return html`
      <p class="${classMap({
			[`cds-custom--file--label`]: true,
			[`cds-custom--label-description--disabled`]: disabled
		})}">
        <slot name="label-title">${labelTitle}</slot>
      </p>
      <p class="${classMap({
			[`cds-custom--label-description`]: true,
			[`cds-custom--label-description--disabled`]: disabled
		})}">
        <slot name="label-description">${labelDescription}</slot>
      </p>
      <slot name="drop-container"></slot>
      <div class="${"cds-custom"}--file-container">
        <slot></slot>
      </div>
    `;
	}
	/**
	* A selector that will return the `input` to enter starting date.
	*/
	static get selectorUploaderItem() {
		return `cds-custom-file-uploader-button,cds-custom-file-uploader-drop-container`;
	}
	static {
		this.styles = file_uploader_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSFileUploader.prototype, "disabled", void 0);
__decorate([property({ attribute: "label-description" })], CDSFileUploader.prototype, "labelDescription", void 0);
__decorate([property({ attribute: "label-title" })], CDSFileUploader.prototype, "labelTitle", void 0);
//#endregion
export { CDSFileUploader as default };

//# sourceMappingURL=file-uploader.js.map