/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/file-uploader/defs.ts
/**
* Copyright IBM Corp. 2020, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The state of `<cds-custom-file-uploader-item>`.
*/
let FILE_UPLOADER_ITEM_STATE = /* @__PURE__ */ function(FILE_UPLOADER_ITEM_STATE) {
	/**
	* Upload in progress.
	*/
	FILE_UPLOADER_ITEM_STATE["UPLOADING"] = "uploading";
	/**
	* Upload complete.
	*/
	FILE_UPLOADER_ITEM_STATE["COMPLETE"] = "complete";
	/**
	* Editing.
	*/
	FILE_UPLOADER_ITEM_STATE["EDIT"] = "edit";
	return FILE_UPLOADER_ITEM_STATE;
}({});
/**
* File uploader item size.
*/
let FILE_UPLOADER_ITEM_SIZE = /* @__PURE__ */ function(FILE_UPLOADER_ITEM_SIZE) {
	/**
	* Small size.
	*/
	FILE_UPLOADER_ITEM_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	FILE_UPLOADER_ITEM_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	FILE_UPLOADER_ITEM_SIZE["LARGE"] = "lg";
	return FILE_UPLOADER_ITEM_SIZE;
}({});
//#endregion
export { FILE_UPLOADER_ITEM_SIZE, FILE_UPLOADER_ITEM_STATE };

//# sourceMappingURL=defs.js.map