/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "../loading/defs.js";
import file_uploader_default from "./file-uploader.scss.js";
import { FILE_UPLOADER_ITEM_SIZE, FILE_UPLOADER_ITEM_STATE } from "./defs.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import WarningFilled16 from "@carbon/icons/es/warning--filled/16.js";
import Close16 from "@carbon/icons/es/close/16.js";
import CheckmarkFilled16 from "@carbon/icons/es/checkmark--filled/16.js";
//#region src/components/file-uploader/file-uploader-item.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* File uploader item.
*
* @element cds-custom-file-uploader-item
* @slot validity-message The validity message.
* @slot validity-message-supplement The supplemental validity message.
* @fires cds-custom-file-uploader-item-beingdeleted
*   The custom event fired before this file uploader item is being deleted upon a user gesture.
*   Cancellation of this event stops the user-initiated action of deleting this file uploader item.
* @fires cds-custom-file-uploader-item-deleted - The custom event fired after this file uploader item is deleted upon a user gesture.
*/
var CDSFileUploaderItem = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.iconDescription = "Delete this file";
		this.invalid = false;
		this.disabled = false;
		this.size = "md";
		this.state = "uploading";
		this.errorSubject = "";
		this.errorBody = "";
	}
	static {
		this.is = `cds-custom-file-uploader-item`;
	}
	/**
	* Handles `click` event on the delete button.
	*/
	_handleClickDeleteButton() {
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true
		};
		const { eventBeforeDelete, eventDelete } = this.constructor;
		if (this.dispatchEvent(new CustomEvent(eventBeforeDelete, init))) this.dispatchEvent(new CustomEvent(eventDelete, init));
	}
	/**
	* @returns The content showing the editing UI of this file uploader item.
	*/
	_renderEditing() {
		const { iconDescription, invalid, _handleClickDeleteButton: handleClickDeleteButton } = this;
		return html`
      ${!invalid ? void 0 : iconLoader(WarningFilled16, { class: `cds-custom--file-invalid` })}
      <button
        type="button"
        ?disabled=${this.disabled}
        aria-label="${iconDescription}"
        class="${"cds-custom"}--file-close"
        @click="${handleClickDeleteButton}">
        ${iconLoader(Close16)}
      </button>
    `;
	}
	/**
	* @returns The content showing this file uploader's file uploading status as in progress.
	*/
	_renderUploading() {
		const { iconDescription } = this;
		return html`
      <cds-custom-loading
        assistive-text="${iconDescription}"
        type="${"small"}"></cds-custom-loading>
    `;
	}
	/**
	* @returns The content showing this file uploader's file uploading status as complete.
	*/
	_renderUploaded() {
		const { iconDescription } = this;
		return iconLoader(CheckmarkFilled16, {
			class: `cds-custom--file-complete`,
			"aria-label": iconDescription
		});
	}
	/**
	* @returns The content showing this file uploader's status.
	*/
	_renderStatus() {
		const { state } = this;
		switch (state) {
			case "edit": return this._renderEditing();
			case "uploading": return this._renderUploading();
			case "complete": return this._renderUploaded();
			default: return;
		}
	}
	render() {
		const { invalid, errorSubject, errorBody } = this;
		return html` <p class="${"cds-custom"}--file-filename"><slot></slot></p>
      <span class="${"cds-custom"}--file__state-container"
        >${this._renderStatus()}</span
      >
      <div
        class="${"cds-custom"}--form-requirement"
        ?hidden="${!invalid && !errorSubject}">
        <div class="${"cds-custom"}--form-requirement__title">${errorSubject}</div>
        <p
          class="${"cds-custom"}--form-requirement__supplement"
          ?hidden="${!errorBody}">
          ${errorBody}
        </p>
      </div>`;
	}
	/**
	* The name of the custom event fired before this file uplodaer item is being deleted upon a user gesture.
	* Cancellation of this event stops the user-initiated action of deleting this file uploader item.
	*/
	static get eventBeforeDelete() {
		return `cds-custom-file-uploader-item-beingdeleted`;
	}
	/**
	* The name of the custom event fired after this file uplodaer item is deleted upon a user gesture.
	*/
	static get eventDelete() {
		return `cds-custom-file-uploader-item-deleted`;
	}
	static {
		this.styles = file_uploader_default;
	}
};
__decorate([property({ attribute: "icon-description" })], CDSFileUploaderItem.prototype, "iconDescription", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSFileUploaderItem.prototype, "invalid", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSFileUploaderItem.prototype, "disabled", void 0);
__decorate([property({ reflect: true })], CDSFileUploaderItem.prototype, "size", void 0);
__decorate([property({ reflect: true })], CDSFileUploaderItem.prototype, "state", void 0);
__decorate([property({ attribute: "error-subject" })], CDSFileUploaderItem.prototype, "errorSubject", void 0);
__decorate([property({ attribute: "error-body" })], CDSFileUploaderItem.prototype, "errorBody", void 0);
//#endregion
export { FILE_UPLOADER_ITEM_SIZE, FILE_UPLOADER_ITEM_STATE, CDSFileUploaderItem as default };

//# sourceMappingURL=file-uploader-item.js.map