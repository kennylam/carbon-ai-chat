/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../skeleton-text/index.js";
import "../button/index.js";
import "../loading/index.js";
import CDSFileUploader from "./file-uploader.js";
import CDSFileUploaderItem from "./file-uploader-item.js";
import CDSFileUploaderDropContainer from "./file-uploader-drop-container.js";
import CDSFileUploaderButton from "./file-uploader-button.js";
import CDSFileUploaderSkeleton from "./file-uploader-skeleton.js";
//#region src/components/file-uploader/index.ts
/**
* Copyright IBM Corp. 2021, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFileUploader);
defineCustomElement(CDSFileUploaderItem);
defineCustomElement(CDSFileUploaderDropContainer);
defineCustomElement(CDSFileUploaderButton);
defineCustomElement(CDSFileUploaderSkeleton);
//#endregion
export { CDSFileUploader, CDSFileUploaderButton, CDSFileUploaderDropContainer, CDSFileUploaderItem, CDSFileUploaderSkeleton };

//# sourceMappingURL=index.js.map