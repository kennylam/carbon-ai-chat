/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import "../skeleton-text/defs.js";
import { LitElement, html } from "lit";
//#region src/components/file-uploader/file-uploader-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The File uploader skeleton.
*
* @element cds-custom-file-uploader-skeleton
*/
var CDSFileUploaderSkeleton = class extends LitElement {
	static {
		this.is = `cds-custom-file-uploader-skeleton`;
	}
	render() {
		return html`
      <cds-custom-skeleton-text
        type="${"heading"}"
        width="100px"></cds-custom-skeleton-text>
      <cds-custom-skeleton-text width="225px"></cds-custom-skeleton-text>
      <cds-custom-button-skeleton></cds-custom-button-skeleton>
    `;
	}
};
//#endregion
export { CDSFileUploaderSkeleton as default };

//# sourceMappingURL=file-uploader-skeleton.js.map