/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../button/defs.js";
import { FORM_ELEMENT_COLOR_SCHEME } from "../../globals/shared-enums.js";
import if_non_empty_default from "../../globals/directives/if-non-empty.js";
import file_uploader_default from "./file-uploader.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/file-uploader/file-uploader-button.ts
/**
* Copyright IBM Corp. 2020, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const selectorInput = `.cds-custom--file-input`;
/**
* File uploader button .
*
* @element cds-custom-file-uploader-button
* @fires cds-custom-file-uploader-button-changed The custom event fired when there is a user gesture to select files to upload.
*/
var CDSFileUploaderButton = class extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.buttonKind = "primary";
		this.size = "md";
		this.accept = "";
		this.disabled = false;
		this.multiple = false;
		this.name = "";
		this.slot = "drop-container";
	}
	static {
		this.is = `cds-custom-file-uploader-button`;
	}
	/**
	* Handles `click` event on the button.
	*/
	_handleClick(event) {
		event.target.value = null;
		this._fileInput.setAttribute("value", "");
		this._fileInput.click();
	}
	/**
	* Handles `keydown` event on the button.
	*/
	_handleKeyDown(event) {
		if (event.key === "Enter" || event.key === "Space") {
			this._fileInput.setAttribute("value", "");
			this._fileInput.click();
		}
	}
	/**
	* Handles user gesture to select files to upload.
	*
	* @param event The event.
	*/
	_handleChange(event) {
		const addedFiles = this._getFiles(event);
		const { eventChange } = this.constructor;
		this.dispatchEvent(new CustomEvent(eventChange, {
			bubbles: true,
			composed: true,
			detail: { addedFiles }
		}));
		this._fileInput.value = "";
	}
	/**
	* @param event The event.
	* @returns The list of files user chose to upload.
	*/
	_getFiles(event) {
		const { files } = (event.type === "drop" ? event.dataTransfer : event.target) ?? {};
		const { accept } = this;
		if (!accept || !/^(change|drop)$/.test(event.type)) return Array.from(files ?? []);
		const acceptedTypes = new Set(accept.split(/[\s,]+/).filter(Boolean));
		return Array.prototype.filter.call(files, ({ name, type: mimeType = "" }) => {
			const fileExtensionRegExp = /\.[^.]+$/;
			const [fileExtension] = !fileExtensionRegExp.test(name) ? [void 0] : fileExtensionRegExp.exec(name) ?? [];
			return acceptedTypes.has(mimeType) || fileExtension && acceptedTypes.has(fileExtension);
		});
	}
	render() {
		const { accept, disabled, multiple, name, buttonKind, size, _handleChange: handleChange } = this;
		const acceptForInput = accept ? accept.split(/[\s,]+/).filter(Boolean).join(",") : "";
		const labelClasses = classMap({
			[`cds-custom--file-browse-btn`]: true,
			[`cds-custom--file-browse-btn--disabled`]: disabled
		});
		return html`
      <button
        type="button"
        class="${classMap({
			[`cds-custom--btn`]: true,
			[`cds-custom--btn--${buttonKind}`]: buttonKind,
			[`cds-custom--layout--size-${size}`]: size,
			[`cds-custom--btn--disabled`]: disabled,
			[`cds-custom--btn--${size}`]: size
		})}"
        @click="${this._handleClick}"
        @keydown="${this._handleKeyDown}">
        <slot></slot>
      </button>
      <label class="${labelClasses}" for="file"> </label>
      <input
        id="file"
        type="file"
        class="${"cds-custom"}--file-input"
        tabindex="-1"
        accept="${if_non_empty_default(acceptForInput)}"
        ?disabled="${disabled}"
        ?multiple="${multiple}"
        name="${if_non_empty_default(name)}"
        @change="${handleChange}" />
    `;
	}
	/**
	* The name of the custom event fired when there is a user gesture to select files to upload.
	*/
	static get eventChange() {
		return `cds-custom-file-uploader-button-changed`;
	}
	/**
	* A selector that will return the file `input`.
	*/
	static get selectorInput() {
		return selectorInput;
	}
	static {
		this.styles = file_uploader_default;
	}
};
__decorate([query(selectorInput)], CDSFileUploaderButton.prototype, "_fileInput", void 0);
__decorate([property({
	reflect: true,
	attribute: "button-kind"
})], CDSFileUploaderButton.prototype, "buttonKind", void 0);
__decorate([property({ reflect: true })], CDSFileUploaderButton.prototype, "size", void 0);
__decorate([property()], CDSFileUploaderButton.prototype, "accept", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSFileUploaderButton.prototype, "disabled", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSFileUploaderButton.prototype, "multiple", void 0);
__decorate([property({ reflect: true })], CDSFileUploaderButton.prototype, "name", void 0);
__decorate([property({ reflect: true })], CDSFileUploaderButton.prototype, "slot", void 0);
//#endregion
export { FORM_ELEMENT_COLOR_SCHEME as TILE_COLOR_SCHEME, CDSFileUploaderButton as default };

//# sourceMappingURL=file-uploader-button.js.map