/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import FocusMixin from "../../globals/mixins/focus.js";
import content_switcher_default from "./content-switcher.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
//#region src/components/content-switcher/content-switcher-item.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Content switcher button.
*
* @element cds-custom-content-switcher-item
*/
var CDSContentSwitcherItem = class extends FocusMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this.disabled = false;
		this.hideDivider = false;
		this.selected = false;
		this.value = "";
		this.icon = false;
		this.align = "top";
		this.closeOnActivation = true;
		this.enterDelayMs = 100;
		this.leaveDelayMs = 100;
	}
	static {
		this.is = `cds-custom-content-switcher-item`;
	}
	updated(changedProperties) {
		if (changedProperties) this._tooltip?.classList.add(`cds-custom--icon-tooltip`);
		if (this.disabled && changedProperties.has("disabled") && !this.parentElement?.hasAttribute("disabled")) this.parentElement?.setAttribute("disabled", "");
	}
	_renderTooltipContent() {
		return html`
      <cds-custom-tooltip-content>
        <slot name="tooltip-content"></slot>
      </cds-custom-tooltip-content>
    `;
	}
	shouldUpdate(changedProperties) {
		if (changedProperties.has("selected") || changedProperties.has("target")) {
			const { selected, target } = this;
			if (target) (this.getRootNode()?.getElementById(target))?.toggleAttribute("hidden", !selected);
		}
		return true;
	}
	render() {
		const { disabled, selected, target } = this;
		const switcherItem = html`<button
      type="button"
      role="tab"
      class="${classMap({
			[`cds-custom--content-switcher-btn`]: true,
			[`cds-custom--content-switcher--selected`]: selected
		})}"
      ?disabled="${disabled}"
      tabindex="${selected ? "0" : "-1"}"
      aria-controls="${ifDefined(target)}"
      aria-selected="${selected}">
      <span class="${"cds-custom"}--content-switcher__label"><slot></slot></span>
    </button>`;
		if (this.icon) {
			const { align, closeOnActivation, enterDelayMs, leaveDelayMs } = this;
			return html`<cds-custom-tooltip
        align=${align}
        close-on-activation="${closeOnActivation}"
        enter-delay-ms=${enterDelayMs}
        leave-delay-ms=${leaveDelayMs}>
        ${switcherItem} ${this._renderTooltipContent()}
      </cds-custom-tooltip>`;
		}
		return switcherItem;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
	static {
		this.styles = content_switcher_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSContentSwitcherItem.prototype, "disabled", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-divider"
})], CDSContentSwitcherItem.prototype, "hideDivider", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSContentSwitcherItem.prototype, "selected", void 0);
__decorate([property()], CDSContentSwitcherItem.prototype, "target", void 0);
__decorate([property()], CDSContentSwitcherItem.prototype, "value", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSContentSwitcherItem.prototype, "icon", void 0);
__decorate([query(`cds-custom-tooltip`)], CDSContentSwitcherItem.prototype, "_tooltip", void 0);
__decorate([property({
	reflect: true,
	type: String
})], CDSContentSwitcherItem.prototype, "align", void 0);
__decorate([property({
	attribute: "close-on-activation",
	reflect: true,
	type: Boolean
})], CDSContentSwitcherItem.prototype, "closeOnActivation", void 0);
//#endregion
export { CDSContentSwitcherItem as default };

//# sourceMappingURL=content-switcher-item.js.map