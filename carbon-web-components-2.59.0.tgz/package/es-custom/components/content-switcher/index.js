/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../tooltip/index.js";
import CDSContentSwitcher from "./content-switcher.js";
import CDSContentSwitcherItem from "./content-switcher-item.js";
//#region src/components/content-switcher/index.ts
/**
* Copyright IBM Corp. 2021, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSContentSwitcher);
defineCustomElement(CDSContentSwitcherItem);
//#endregion
export { CDSContentSwitcher, CDSContentSwitcherItem };

//# sourceMappingURL=index.js.map