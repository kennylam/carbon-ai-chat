/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/content-switcher/defs.ts
/**
* Copyright IBM Corp. 2020, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Navigation direction, associated with key symbols.
*/
const NAVIGATION_DIRECTION = {
	Left: -1,
	ArrowLeft: -1,
	Right: 1,
	ArrowRight: 1
};
/**
* Button size.
*/
let CONTENT_SWITCHER_SIZE = /* @__PURE__ */ function(CONTENT_SWITCHER_SIZE) {
	/**
	* Regular size.
	*/
	CONTENT_SWITCHER_SIZE["REGULAR"] = "";
	/**
	* Small size.
	*/
	CONTENT_SWITCHER_SIZE["SMALL"] = "sm";
	/**
	* Large size.
	*/
	CONTENT_SWITCHER_SIZE["LARGE"] = "lg";
	/**
	* @deprecated
	* X-Large size.
	*/
	CONTENT_SWITCHER_SIZE["EXTRA_LARGE"] = "xl";
	return CONTENT_SWITCHER_SIZE;
}({});
//#endregion
export { CONTENT_SWITCHER_SIZE, NAVIGATION_DIRECTION };

//# sourceMappingURL=defs.js.map