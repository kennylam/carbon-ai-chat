/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import CDSLink from "../link/link.js";
import { isFeatureFlagEnabled } from "../feature-flags/index.js";
import "../../globals/shared-enums.js";
import tile_default from "./tile.scss.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import AILabel24 from "@carbon/icons/es/ai-label/24.js";
import ArrowRight16 from "@carbon/icons/es/arrow--right/16.js";
import Error16 from "@carbon/icons/es/error/16.js";
//#region src/components/tile/clickable-tile.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Clickable tile.
*
* @element cds-custom-clickable-tile
*/
var CDSClickableTile = class extends CDSLink {
	constructor(..._args) {
		super(..._args);
		this.colorScheme = "";
		this.linkRole = "button";
		this.hasRoundedCorners = false;
		this.aiLabel = false;
		this.slug = false;
	}
	static {
		this.is = `cds-custom-clickable-tile`;
	}
	get _classes() {
		const { colorScheme, disabled, hasRoundedCorners, aiLabel, slug } = this;
		return classMap({
			[`cds-custom--link`]: true,
			[`cds-custom--link--disabled`]: disabled,
			[`cds-custom--tile`]: true,
			[`cds-custom--tile--clickable`]: true,
			[`cds-custom--tile--${colorScheme}`]: colorScheme,
			[`cds-custom--tile--slug-rounded`]: (aiLabel || slug) && hasRoundedCorners
		});
	}
	/**
	* If using `slug`, set `ai-label` attribute to true so
	* the styles are applied for slug as well
	*
	* remove in v12
	*/
	connectedCallback() {
		if (this.slug) {
			this.setAttribute("ai-Label", "");
			this.aiLabel = true;
		}
		super.connectedCallback();
	}
	/**
	* @returns The inner content.
	*/
	_renderInner() {
		const defaultIcon = isFeatureFlagEnabled("enable-v12-tile-default-icons", this) && !this._hasIcon ? this.disabled ? iconLoader(Error16, { class: `cds-custom--tile--disabled-icon` }) : iconLoader(ArrowRight16, { class: `cds-custom--tile--icon` }) : "";
		return html`
      ${super._renderInner()}
      ${this.aiLabel || this.slug ? iconLoader(AILabel24, { class: `cds-custom--tile--ai-label-icon` }) : ""}
      <slot name="decorator"></slot>
      ${defaultIcon}
    `;
	}
	/**
	* A selector that will return the slug item.
	*
	* remove in v12
	*/
	static get slugItem() {
		return `cds-custom-slug`;
	}
	/**
	* A selector that will return the AI Label item.
	*/
	static get aiLabelItem() {
		return `cds-custom-ai-label`;
	}
	static {
		this.styles = tile_default;
	}
};
__decorate([property({
	attribute: "color-scheme",
	reflect: true
})], CDSClickableTile.prototype, "colorScheme", void 0);
__decorate([property({ attribute: "link-role" })], CDSClickableTile.prototype, "linkRole", void 0);
__decorate([property({
	type: Boolean,
	attribute: "has-rounded-corners"
})], CDSClickableTile.prototype, "hasRoundedCorners", void 0);
__decorate([property({
	type: Boolean,
	attribute: "ai-label"
})], CDSClickableTile.prototype, "aiLabel", void 0);
__decorate([property({ type: Boolean })], CDSClickableTile.prototype, "slug", void 0);
//#endregion
export { CDSClickableTile as default };

//# sourceMappingURL=clickable-tile.js.map