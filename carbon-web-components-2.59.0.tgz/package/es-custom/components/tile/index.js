/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../link/index.js";
import CDSClickableTile from "./clickable-tile.js";
import CDSExpandableTile from "./expandable-tile.js";
import CDSSelectableTile from "./selectable-tile.js";
import CDSRadioTile from "./radio-tile.js";
import CDSTile from "./tile.js";
import CDSTileGroup from "./tile-group.js";
//#region src/components/tile/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSClickableTile);
defineCustomElement(CDSExpandableTile);
defineCustomElement(CDSRadioTile);
defineCustomElement(CDSSelectableTile);
defineCustomElement(CDSTile);
defineCustomElement(CDSTileGroup);
//#endregion
export { CDSClickableTile, CDSExpandableTile, CDSRadioTile, CDSSelectableTile, CDSTile, CDSTileGroup };

//# sourceMappingURL=index.js.map