/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import { FORM_ELEMENT_COLOR_SCHEME } from "../../globals/shared-enums.js";
import tile_default from "./tile.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/tile/tile.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Basic tile.
*
* @element cds-custom-tile
*/
var CDSTile = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._hasAILabel = false;
		this.colorScheme = "";
		this.hasRoundedCorners = false;
	}
	static {
		this.is = `cds-custom-tile`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		const hasContent = target.assignedNodes().filter((elem) => elem.matches !== void 0 ? elem.matches(this.constructor.aiLabelItem) || elem.matches(this.constructor.slugItem) : false);
		if (hasContent.length > 0) {
			this._hasAILabel = Boolean(hasContent);
			hasContent[0].setAttribute("size", "xs");
		}
		this.requestUpdate();
	}
	updated() {
		if (this._hasAILabel) this.setAttribute("ai-label", "");
		else this.removeAttribute("ai-label");
	}
	render() {
		return html` <slot></slot
      ><slot name="decorator" @slotchange="${this._handleSlotChange}"></slot>
      <slot name="ai-label" @slotchange="${this._handleSlotChange}"></slot
      ><slot name="slug" @slotchange="${this._handleSlotChange}"></slot>`;
	}
	/**
	* A selector that will return the slug item.
	*
	* TODO: remove in v12
	*/
	static get slugItem() {
		return `cds-custom-slug`;
	}
	/**
	* A selector that will return the AI Label item.
	*/
	static get aiLabelItem() {
		return `cds-custom-ai-label`;
	}
	static {
		this.styles = tile_default;
	}
};
__decorate([property({
	attribute: "color-scheme",
	reflect: true
})], CDSTile.prototype, "colorScheme", void 0);
__decorate([property({
	type: Boolean,
	attribute: "has-rounded-corners"
})], CDSTile.prototype, "hasRoundedCorners", void 0);
//#endregion
export { FORM_ELEMENT_COLOR_SCHEME as TILE_COLOR_SCHEME, CDSTile as default };

//# sourceMappingURL=tile.js.map