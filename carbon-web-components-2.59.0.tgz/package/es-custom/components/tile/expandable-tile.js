/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import FocusMixin from "../../globals/mixins/focus.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../../globals/shared-enums.js";
import tile_default from "./tile.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
import ChevronDown16 from "@carbon/icons/es/chevron--down/16.js";
//#region src/components/tile/expandable-tile.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Expandable tile.
*
* @element cds-custom-expandable-tile
* @fires cds-custom-expandable-tile-beingtoggled
*   The custom event fired before the expanded state is changed upon a user gesture.
*   Cancellation of this event stops changing the user-initiated change in expanded state.
* @fires cds-custom-expandable-tile-toggled - The custom event fired after a the expanded state is changed upon a user gesture.
*/
var CDSExpandableTile = class extends HostListenerMixin(FocusMixin(LitElement)) {
	constructor(..._args) {
		super(..._args);
		this._belowTheContentHeight = 0;
		this._hasAILabel = false;
		this._handleClick = () => {
			if (!this.withInteractive) this._handleExpand();
		};
		this.colorScheme = "";
		this.expanded = false;
		this.hasRoundedCorners = false;
		this.withInteractive = false;
	}
	static {
		this.is = `cds-custom-expandable-tile`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		const hasContent = target.assignedNodes().filter((elem) => elem.matches !== void 0 ? elem.matches(this.constructor?.aiLabelItem) || elem.matches(this.constructor?.slugItem) : false);
		if (hasContent.length > 0) {
			this._hasAILabel = Boolean(hasContent);
			hasContent[0].setAttribute("size", "xs");
		}
		this.requestUpdate();
	}
	/**
	* Handles `slotchange` event on the below-the-fold content.
	*
	* @param event The event.
	*/
	_handleSlotChangeBelowTheFoldContent(event) {
		this._belowTheContentHeight = event.target.assignedNodes().reduce((acc, item) => acc + (item.offsetHeight ?? 0), 0);
		if (!this._belowTheContentHeight) {
			const element = getComputedStyle(this.querySelector("cds-custom-tile-below-the-fold-content"));
			this._belowTheContentHeight = parseInt(element.height, 10);
		}
		this.requestUpdate();
	}
	_handleExpand() {
		const expanded = !this.expanded;
		this.focus();
		const init = {
			bubbles: true,
			composed: true,
			detail: { expanded }
		};
		const constructor = this.constructor;
		const beforeChangeEvent = new CustomEvent(constructor.eventBeforeToggle, {
			...init,
			cancelable: true
		});
		if (this.dispatchEvent(beforeChangeEvent)) {
			this.expanded = expanded;
			const afterChangeEvent = new CustomEvent(constructor.eventToggle, init);
			this.dispatchEvent(afterChangeEvent);
		}
	}
	updated() {
		if (this._hasAILabel) this.setAttribute("ai-label", "");
		else this.removeAttribute("ai-label");
	}
	render() {
		const { expanded, withInteractive, _belowTheContentHeight: belowTheContentHeight, _handleSlotChangeBelowTheFoldContent: handleSlotChangeBelowTheFoldContent } = this;
		return html`
      <button
        class="${classMap({
			[`cds-custom--tile__chevron`]: true,
			[`cds-custom--tile__chevron--interactive`]: withInteractive
		})}"
        aria-labelledby="above-the-fold-content"
        aria-controls="below-the-fold-content"
        tabindex="0"
        @click="${withInteractive ? this._handleExpand : ""}"
        aria-expanded="${String(expanded)}">
        ${iconLoader(ChevronDown16, { id: "icon" })}
      </button>
      <slot name="ai-label" @slotchange="${this._handleSlotChange}"></slot>
      <slot name="slug" @slotchange="${this._handleSlotChange}"></slot>
      <slot name="decorator"></slot>
      <div id="content" class="${"cds-custom"}--tile-content">
        <div><slot name="above-the-fold-content"></slot></div>
        <div
          class="${"cds-custom"}-ce--expandable-tile--below-the-fold-content"
          style="${ifDefined(!expanded ? void 0 : `max-height: ${belowTheContentHeight}px`)}">
          <slot @slotchange="${handleSlotChangeBelowTheFoldContent}"></slot>
        </div>
      </div>
    `;
	}
	/**
	* A selector that will return the slug item.
	*
	* remove in v12
	*/
	static get slugItem() {
		return `cds-custom-slug`;
	}
	/**
	* A selector that will return the AI Label item.
	*/
	static get aiLabelItem() {
		return `cds-custom-ai-label`;
	}
	/**
	* The name of the custom event fired before the expanded state is changed upon a user gesture.
	* Cancellation of this event stops changing the user-initiated change in expanded state.
	*/
	static get eventBeforeToggle() {
		return `cds-custom-expandable-tile-beingtoggled`;
	}
	/**
	* The name of the custom event fired after a the expanded state is changed upon a user gesture.
	*/
	static get eventToggle() {
		return `cds-custom-expandable-tile-toggled`;
	}
	static {
		this.styles = tile_default;
	}
};
__decorate([HostListener("click")], CDSExpandableTile.prototype, "_handleClick", void 0);
__decorate([property({
	attribute: "color-scheme",
	reflect: true
})], CDSExpandableTile.prototype, "colorScheme", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSExpandableTile.prototype, "expanded", void 0);
__decorate([property({
	type: Boolean,
	attribute: "has-rounded-corners"
})], CDSExpandableTile.prototype, "hasRoundedCorners", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "with-interactive"
})], CDSExpandableTile.prototype, "withInteractive", void 0);
//#endregion
export { CDSExpandableTile as default };

//# sourceMappingURL=expandable-tile.js.map