/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import "../password-input/index.js";
import CDSFluidPasswordInput from "./fluid-password-input.js";
//#region src/components/fluid-password-input/index.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFluidPasswordInput);
//#endregion
export { CDSFluidPasswordInput };

//# sourceMappingURL=index.js.map