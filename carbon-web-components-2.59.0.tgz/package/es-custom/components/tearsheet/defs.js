/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/tearsheet/defs.ts
/**
* Copyright IBM Corp. 2023, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
let TEARSHEET_INFLUENCER_PLACEMENT = /* @__PURE__ */ function(TEARSHEET_INFLUENCER_PLACEMENT) {
	/** right / default */
	TEARSHEET_INFLUENCER_PLACEMENT["RIGHT"] = "right";
	/** left  */
	TEARSHEET_INFLUENCER_PLACEMENT["LEFT"] = "left";
	return TEARSHEET_INFLUENCER_PLACEMENT;
}({});
let TEARSHEET_INFLUENCER_WIDTH = /* @__PURE__ */ function(TEARSHEET_INFLUENCER_WIDTH) {
	/** narrow /default */
	TEARSHEET_INFLUENCER_WIDTH["NARROW"] = "narrow";
	/** wide  */
	TEARSHEET_INFLUENCER_WIDTH["WIDE"] = "wide";
	return TEARSHEET_INFLUENCER_WIDTH;
}({});
let TEARSHEET_WIDTH = /* @__PURE__ */ function(TEARSHEET_WIDTH) {
	/** narrow  */
	TEARSHEET_WIDTH["NARROW"] = "narrow";
	/** wide  */
	TEARSHEET_WIDTH["WIDE"] = "wide";
	return TEARSHEET_WIDTH;
}({});
//#endregion
export { TEARSHEET_INFLUENCER_PLACEMENT, TEARSHEET_INFLUENCER_WIDTH, TEARSHEET_WIDTH };

//# sourceMappingURL=defs.js.map