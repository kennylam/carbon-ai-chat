/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { forEach } from "../../globals/internal/collection-helpers.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import progress_indicator_default from "./progress-indicator.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/progress-indicator/progress-indicator-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of progress indicator.
*/
var CDSProgressIndicatorSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.vertical = false;
	}
	static {
		this.is = `cds-custom-progress-indicator-skeleton`;
	}
	updated(changedProperties) {
		if (changedProperties.has("vertical")) forEach(this.querySelectorAll(this.constructor.selectorStep), (item) => {
			item.vertical = this.vertical;
		});
	}
	render() {
		return html`<slot></slot>`;
	}
	/**
	* A selector that will return progress steps.
	*/
	static get selectorStep() {
		return `cds-custom-progress-step-skeleton`;
	}
	static {
		this.styles = progress_indicator_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSProgressIndicatorSkeleton.prototype, "vertical", void 0);
//#endregion
export { CDSProgressIndicatorSkeleton as default };

//# sourceMappingURL=progress-indicator-skeleton.js.map