/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSProgressIndicator from "./progress-indicator.js";
import CDSProgressIndicatorSkeleton from "./progress-indicator-skeleton.js";
import CDSProgressStep from "./progress-step.js";
import CDSProgressStepSkeleton from "./progress-step-skeleton.js";
//#region src/components/progress-indicator/index.ts
/**
* Copyright IBM Corp. 2021, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSProgressIndicator);
defineCustomElement(CDSProgressIndicatorSkeleton);
defineCustomElement(CDSProgressStep);
defineCustomElement(CDSProgressStepSkeleton);
//#endregion
export { CDSProgressIndicator, CDSProgressIndicatorSkeleton, CDSProgressStep, CDSProgressStepSkeleton };

//# sourceMappingURL=index.js.map