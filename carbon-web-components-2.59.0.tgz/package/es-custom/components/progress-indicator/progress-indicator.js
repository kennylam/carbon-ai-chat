/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { forEach } from "../../globals/internal/collection-helpers.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import progress_indicator_default from "./progress-indicator.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/progress-indicator/progress-indicator.ts
/**
* Copyright IBM Corp. 2019, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Progress indicator.
*
* @element cds-custom-progress-indicator
*/
var CDSProgressIndicator = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.vertical = false;
		this.spaceEqually = false;
		this.currentIndex = 0;
		this._handleStepClick = (evt) => {
			if (!(typeof this.onChange === "function")) return;
			const steps = Array.from(this.querySelectorAll(this.constructor.selectorStep));
			const targetStep = (evt.composedPath ? evt.composedPath()[0] : evt.target)?.closest(this.constructor.selectorStep);
			if (!targetStep) return;
			const index = steps.indexOf(targetStep);
			if (index < 0) return;
			const detail = { index };
			const changeEvt = new CustomEvent("change", {
				bubbles: true,
				composed: true,
				detail
			});
			this.dispatchEvent(changeEvt);
			this.dispatchEvent(new CustomEvent("onChange", {
				bubbles: true,
				composed: true,
				detail
			}));
			if (typeof this.onChange === "function") this.onChange(changeEvt);
		};
	}
	static {
		this.is = `cds-custom-progress-indicator`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "list");
		super.connectedCallback();
		this.addEventListener(`cds-custom-progress-step-click`, this._handleStepClick);
	}
	disconnectedCallback() {
		this.removeEventListener(`cds-custom-progress-step-click`, this._handleStepClick);
		super.disconnectedCallback();
	}
	updated(changedProperties) {
		const spacingValue = this.vertical ? false : this.spaceEqually;
		const clickable = typeof this.onChange === "function";
		const steps = this.querySelectorAll(this.constructor.selectorStep);
		if (changedProperties.has("vertical")) forEach(steps, (item) => {
			item.vertical = this.vertical;
			item.spaceEqually = spacingValue;
			item.clickable = clickable;
		});
		if (changedProperties.has("spaceEqually")) forEach(steps, (item) => {
			item.spaceEqually = spacingValue;
		});
		if (changedProperties.has("onChange")) forEach(steps, (item) => {
			item.clickable = clickable;
		});
		if (changedProperties.has("currentIndex")) steps.forEach((step, index) => {
			const progressStep = step;
			if (progressStep.hasExplicitState) return;
			progressStep.complete = false;
			progressStep.current = false;
			if (index < this.currentIndex) progressStep.complete = true;
			else if (index === this.currentIndex) progressStep.current = true;
		});
	}
	render() {
		return html`<slot></slot>`;
	}
	/**
	* A selector that will return progress steps.
	*/
	static get selectorStep() {
		return `cds-custom-progress-step`;
	}
	static {
		this.styles = progress_indicator_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSProgressIndicator.prototype, "vertical", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "space-equally"
})], CDSProgressIndicator.prototype, "spaceEqually", void 0);
__decorate([property({
	type: Number,
	attribute: "current-index"
})], CDSProgressIndicator.prototype, "currentIndex", void 0);
__decorate([property({ attribute: false })], CDSProgressIndicator.prototype, "onChange", void 0);
//#endregion
export { CDSProgressIndicator as default };

//# sourceMappingURL=progress-indicator.js.map