/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/progress-indicator/defs.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* State of progress step.
*/
let PROGRESS_STEP_STAT = /* @__PURE__ */ function(PROGRESS_STEP_STAT) {
	/**
	* Complete one.
	*/
	PROGRESS_STEP_STAT["COMPLETE"] = "complete";
	/**
	* One that is being executed now.
	*/
	PROGRESS_STEP_STAT["CURRENT"] = "current";
	/**
	* One for future execution.
	*/
	PROGRESS_STEP_STAT["INCOMPLETE"] = "incomplete";
	/**
	* Invalid one.
	*/
	PROGRESS_STEP_STAT["INVALID"] = "invalid";
	return PROGRESS_STEP_STAT;
}({});
//#endregion
export { PROGRESS_STEP_STAT };

//# sourceMappingURL=defs.js.map