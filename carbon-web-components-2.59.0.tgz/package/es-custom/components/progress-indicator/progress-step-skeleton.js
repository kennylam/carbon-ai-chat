/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "../skeleton-text/index.js";
import progress_indicator_default from "./progress-indicator.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import CircleDash16 from "@carbon/icons/es/circle-dash/16.js";
//#region src/components/progress-indicator/progress-step-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of progress step.
*/
var CDSProgressStepSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.vertical = false;
	}
	static {
		this.is = `cds-custom-progress-step-skeleton`;
	}
	render() {
		return html`
      <div
        class="${"cds-custom"}--progress-step-button ${"cds-custom"}--progress-step-button--unclickable">
        ${iconLoader(CircleDash16)}
        <p class="${"cds-custom"}--progress-label">
          <cds-custom-skeleton-text width="40px" linecount="1"></cds-custom-skeleton-text>
        </p>
        <span class="${"cds-custom"}--progress-line"></span>
      </div>
    `;
	}
	static {
		this.styles = progress_indicator_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSProgressStepSkeleton.prototype, "vertical", void 0);
//#endregion
export { CDSProgressStepSkeleton as default };

//# sourceMappingURL=progress-step-skeleton.js.map