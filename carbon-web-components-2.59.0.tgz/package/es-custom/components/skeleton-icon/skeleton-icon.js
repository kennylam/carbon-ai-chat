/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import skeleton_icon_default from "./skeleton-icon.scss.js";
import { LitElement } from "lit";
//#region src/components/skeleton-icon/skeleton-icon.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton icon.
*
* @element cds-custom-skeleton-icon
*/
var CDSSkeletonIcon = class extends LitElement {
	static {
		this.is = `cds-custom-skeleton-icon`;
	}
	static {
		this.styles = skeleton_icon_default;
	}
};
//#endregion
export { CDSSkeletonIcon as default };

//# sourceMappingURL=skeleton-icon.js.map