/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSSkeletonIcon from "./skeleton-icon.js";
//#region src/components/skeleton-icon/index.ts
/**
* Copyright IBM Corp. 2021, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSSkeletonIcon);
//#endregion
export { CDSSkeletonIcon };

//# sourceMappingURL=index.js.map