/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import tabs_default from "./tabs.scss.js";
import { LitElement, html } from "lit";
//#region src/components/tabs/tab-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of tab.
*
* @element cds-custom-tab-skeleton
*/
var CDSTabSkeleton = class extends LitElement {
	static {
		this.is = `cds-custom-tab-skeleton`;
	}
	render() {
		return html`
      <div class="${"cds-custom"}--tabs__nav-link">
        <span></span>
      </div>
    `;
	}
	static {
		this.styles = tabs_default;
	}
};
//#endregion
export { CDSTabSkeleton as default };

//# sourceMappingURL=tab-skeleton.js.map