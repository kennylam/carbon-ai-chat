/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import tabs_default from "./tabs.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/tabs/tabs-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of tabs.
*
* @element cds-custom-tabs-skeleton
*/
var CDSTabsSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.contained = false;
	}
	static {
		this.is = `cds-custom-tabs-skeleton`;
	}
	render() {
		return html`
      <ul class="${"cds-custom"}--tabs__nav">
        <slot></slot>
      </ul>
    `;
	}
	static {
		this.styles = tabs_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTabsSkeleton.prototype, "contained", void 0);
//#endregion
export { CDSTabsSkeleton as default };

//# sourceMappingURL=tabs-skeleton.js.map