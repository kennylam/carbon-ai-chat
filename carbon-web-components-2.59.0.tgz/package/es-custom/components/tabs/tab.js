/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import CDSContentSwitcherItem from "../content-switcher/content-switcher-item.js";
import "./defs.js";
import tabs_default from "./tabs.scss.js";
import { html } from "lit";
import { property, query, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
import Close16 from "@carbon/icons/es/close/16.js";
//#region src/components/tabs/tab.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Basic tab.
*
* @element cds-custom-tab
* @fires cds-custom-tab-beingclosed
*   The custom event fired before a tab is closed upon a user gesture.
*   Cancellation of this event stops changing the user-initiated action.
* @fires cds-custom-tab-closed - The custom event fired after a a tab is closed upon a user gesture.
*/
var CDSTab = class extends HostListenerMixin(CDSContentSwitcherItem) {
	constructor(..._args) {
		super(..._args);
		this.highlighted = false;
		this.type = "";
		this.vertical = false;
		this.iconOnly = false;
		this.badgeIndicator = false;
		this.truncated = false;
		this._dismissable = false;
		this._index = -1;
	}
	static {
		this.is = `cds-custom-tab`;
	}
	/**
	* Checks if the text overflow ellipsis is currently applied to the label.
	* This is useful for determining if a tooltip should be shown.
	*
	* @returns `true` if text is truncated/clamped, `false` otherwise or if not in vertical mode
	*/
	isTextTruncated() {
		if (!this.vertical || !this._labelElement) return false;
		return this._labelElement.scrollHeight > this._labelElement.clientHeight;
	}
	/**
	* Updates the truncated state after the component has rendered.
	*/
	updated(changedProperties) {
		super.updated(changedProperties);
		if (this.vertical && this._labelElement) {
			const isTruncated = this.isTextTruncated();
			if (this.truncated !== isTruncated) this.truncated = isTruncated;
		}
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		const textContent = target.assignedNodes()[0]?.textContent;
		this.tabTitle = textContent?.trim().replace(/\s+/g, " ") || void 0;
	}
	/**
	* Handles `keydown` event on the tab.
	* Triggers tab close when Delete key is pressed on a dismissable tab.
	*/
	_handleKeydown(event) {
		const { key } = event;
		if (this._dismissable && !this.disabled && (key === "Delete" || key === "Backspace")) {
			event.preventDefault();
			this._handleClose(event);
		}
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "listitem");
		super.connectedCallback();
	}
	render() {
		const navLinkClasses = classMap({
			[`cds-custom--tabs__nav-link`]: true,
			[`cds-custom--tabs__nav-link--dismissable`]: this._dismissable
		});
		const closeButtonClasses = classMap({
			[`cds-custom--tabs__nav-item--close`]: this._dismissable,
			[`cds-custom--tabs__nav-item--close--hidden`]: !this._dismissable
		});
		const { badgeIndicator, disabled, secondaryLabel, selected, tabTitle, vertical, truncated, _handleSlotChange: handleSlotChange, _handleClick: handleClick } = this;
		const iconButton = html`
      <cds-custom-button
        title="${this.textContent?.trim() ? `Remove ${this.textContent.trim()} tab` : "Remove tab"}"
        class="${closeButtonClasses}"
        kind="ghost"
        size="xs"
        @click="${handleClick}"
        tab-index="${-1}"
        aria-hidden="${this.selected && this._dismissable ? "false" : "true"}"
        ?disabled="${disabled}">
        ${iconLoader(Close16, {
			"aria-label": "close",
			slot: "icon"
		})}
      </cds-custom-button>
    `;
		const accessibleLabel = tabTitle || this.getAttribute("aria-label");
		const isIconOnly = this.iconOnly || this.classList.contains(`cds-custom--tabs__nav-item--icon-only`);
		const tabLink = html`
      <a
        class="${navLinkClasses}"
        role="tab"
        aria-label="${ifDefined(accessibleLabel || void 0)}"
        tabindex="${selected ? 0 : -1}"
        ?disabled="${disabled}"
        aria-selected="${selected}">
        ${vertical ? html`<span
              class="${"cds-custom"}--tabs__nav-item-label"
              title="${truncated ? tabTitle.trim() : ""}">
              <slot @slotchange="${handleSlotChange}"></slot>
            </span>` : html`
              <span class="${"cds-custom"}--tabs__nav-item-label-wrapper">
                <slot @slotchange="${handleSlotChange}"></slot>
              </span>
            `}
        ${secondaryLabel ? html`<span
              class="${"cds-custom"}--tabs__nav-item-secondary-label"
              title="${secondaryLabel}"
              >${secondaryLabel}</span
            >` : ""}
        ${!disabled && badgeIndicator ? html`<cds-custom-badge-indicator></cds-custom-badge-indicator>` : ""}
      </a>
      ${iconButton}
    `;
		if (isIconOnly && accessibleLabel && !disabled) return html`
        <cds-custom-tooltip align="bottom" class="${"cds-custom"}--icon-tooltip">
          ${tabLink}
          <cds-custom-tooltip-content>${accessibleLabel}</cds-custom-tooltip-content>
        </cds-custom-tooltip>
      `;
		return tabLink;
	}
	/**
	* Handles the close action for the tab.
	* Dispatches before-close and close events.
	*/
	_handleClose(event) {
		event.stopPropagation();
		const init = {
			bubbles: true,
			cancelable: true,
			composed: true,
			detail: { index: this._index }
		};
		if (this.dispatchEvent(new CustomEvent(this.constructor.eventBeforeClose, init))) this.dispatchEvent(new CustomEvent(this.constructor.eventClose, init));
	}
	/**
	* Handles click event on the close button.
	*/
	_handleClick(event) {
		this._handleClose(event);
	}
	/**
	* The name of the custom event fired before a tab is closed upon a user gesture.
	* Cancellation of this event stops changing the user-initiated action.
	*/
	static get eventBeforeClose() {
		return `cds-custom-tab-beingclosed`;
	}
	/**
	* The name of the custom event fired after a a tab is closed upon a user gesture.
	*/
	static get eventClose() {
		return `cds-custom-tab-closed`;
	}
	static {
		this.styles = tabs_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTab.prototype, "highlighted", void 0);
__decorate([property({ reflect: true })], CDSTab.prototype, "type", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSTab.prototype, "vertical", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "icon-only"
})], CDSTab.prototype, "iconOnly", void 0);
__decorate([property({
	attribute: "icon-size",
	reflect: true
})], CDSTab.prototype, "iconSize", void 0);
__decorate([property()], CDSTab.prototype, "tabTitle", void 0);
__decorate([property({
	attribute: "secondary-label",
	reflect: true
})], CDSTab.prototype, "secondaryLabel", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "badge-indicator"
})], CDSTab.prototype, "badgeIndicator", void 0);
__decorate([state()], CDSTab.prototype, "truncated", void 0);
__decorate([state()], CDSTab.prototype, "_dismissable", void 0);
__decorate([state()], CDSTab.prototype, "_index", void 0);
__decorate([query(`.cds-custom--tabs__nav-item-label`)], CDSTab.prototype, "_labelElement", void 0);
__decorate([HostListener("keydown")], CDSTab.prototype, "_handleKeydown", null);
//#endregion
export { CDSTab as default };

//# sourceMappingURL=tab.js.map