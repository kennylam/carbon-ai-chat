/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../tooltip/index.js";
import "../button/index.js";
import "../badge-indicator/index.js";
import "../content-switcher/index.js";
import CDSTabs from "./tabs.js";
import CDSTab from "./tab.js";
import CDSTabSkeleton from "./tab-skeleton.js";
import CDSTabsSkeleton from "./tabs-skeleton.js";
import CDSTabsVertical from "./tabs-vertical.js";
//#region src/components/tabs/index.ts
/**
* Copyright IBM Corp. 2021, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSTabs);
defineCustomElement(CDSTab);
defineCustomElement(CDSTabSkeleton);
defineCustomElement(CDSTabsSkeleton);
defineCustomElement(CDSTabsVertical);
//#endregion
export { CDSTab, CDSTabSkeleton, CDSTabs, CDSTabsSkeleton, CDSTabsVertical };

//# sourceMappingURL=index.js.map