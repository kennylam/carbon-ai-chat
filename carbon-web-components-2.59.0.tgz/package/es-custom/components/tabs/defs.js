/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/tabs/defs.ts
/**
* Copyright IBM Corp. 2020, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* The keyboard action categories for dropdown.
*/
let TABS_KEYBOARD_ACTION = /* @__PURE__ */ function(TABS_KEYBOARD_ACTION) {
	/**
	* Not doing any action.
	*/
	TABS_KEYBOARD_ACTION["NONE"] = "none";
	/**
	* Keyboard action to navigate back/forward.
	*/
	TABS_KEYBOARD_ACTION["NAVIGATING"] = "navigating";
	/**
	* Keyboard action to Enter/Space.
	*/
	TABS_KEYBOARD_ACTION["ACTIVATING"] = "activating";
	/**
	* Keyboard action to navigate to first tab using home key
	*/
	TABS_KEYBOARD_ACTION["HOME"] = "home";
	/**
	* Keyboard action to navigate to last tab using end key
	*/
	TABS_KEYBOARD_ACTION["END"] = "end";
	return TABS_KEYBOARD_ACTION;
}({});
/**
* Tabs types.
*/
let TABS_TYPE = /* @__PURE__ */ function(TABS_TYPE) {
	/**
	* Regular tabs.
	*/
	TABS_TYPE["REGULAR"] = "";
	/**
	* Container type.
	*/
	TABS_TYPE["CONTAINER"] = "container";
	/**
	* Contained type.
	*/
	TABS_TYPE["CONTAINED"] = "contained";
	return TABS_TYPE;
}({});
/**
* Vertical navigation direction, associated with key symbols.
*/
const VERTICAL_NAVIGATION_DIRECTION = {
	Up: -1,
	ArrowUp: -1,
	Down: 1,
	ArrowDown: 1
};
/**
* Tabs icon sizes.
*/
let TABS_ICON_SIZE = /* @__PURE__ */ function(TABS_ICON_SIZE) {
	/**
	* Default icon size.
	*/
	TABS_ICON_SIZE["DEFAULT"] = "default";
	/**
	* Large icon size.
	*/
	TABS_ICON_SIZE["LARGE"] = "lg";
	return TABS_ICON_SIZE;
}({});
/**
* Tabs size.
*/
let TABS_SIZE = /* @__PURE__ */ function(TABS_SIZE) {
	/**
	* Small size.
	*/
	TABS_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	TABS_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	TABS_SIZE["LARGE"] = "lg";
	/**
	* Extra large size.
	*/
	TABS_SIZE["EXTRA_LARGE"] = "xl";
	return TABS_SIZE;
}({});
//#endregion
export { TABS_ICON_SIZE, TABS_KEYBOARD_ACTION, TABS_SIZE, TABS_TYPE, VERTICAL_NAVIGATION_DIRECTION };

//# sourceMappingURL=defs.js.map