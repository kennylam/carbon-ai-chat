/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import tabs_default from "./tabs.scss.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import { breakpoints } from "@carbon/layout";
//#region src/components/tabs/tabs-vertical.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Breakpoint for switching between horizontal and vertical tab layouts.
* Uses Carbon's md breakpoint (42rem/672px) + 0.01rem offset to avoid overlap
* with max-width queries. This mirrors the Sass breakpoint behavior.
* Below this breakpoint, tabs display horizontally.
*/
const VERTICAL_TABS_BREAKPOINT = `(min-width: calc(${breakpoints.md.width} + 0.01rem))`;
/**
* Vertical tabs container component.
*
* @element cds-custom-tabs-vertical
* @slot tabs - The `<cds-custom-tabs>` navigation element.
* @slot panel - One or more `<div role="tabpanel">` elements.
*/
var CDSTabsVertical = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._mediaQueryList = null;
		this._handleViewportChange = (e) => {
			const tabs = this.querySelector(`cds-custom-tabs`);
			if (e.matches) {
				this.classList.add(`cds-custom--css-grid`);
				if (tabs) {
					tabs.setAttribute("vertical", "");
					tabs.removeAttribute("type");
					const size = tabs.getAttribute("size");
					if (size) tabs.setAttribute("size", size);
				}
			} else {
				this.classList.remove(`cds-custom--css-grid`);
				if (tabs) {
					tabs.removeAttribute("vertical");
					tabs.setAttribute("type", "contained");
				}
			}
		};
	}
	static {
		this.is = `cds-custom-tabs-vertical`;
	}
	firstUpdated() {
		this._mediaQueryList = window.matchMedia(VERTICAL_TABS_BREAKPOINT);
		this._handleViewportChange(this._mediaQueryList);
		this._mediaQueryList.addEventListener("change", this._handleViewportChange);
		requestAnimationFrame(() => {
			this._applyHeight();
		});
		this._panelSlot?.addEventListener("slotchange", () => {
			this._applyHeight();
		});
	}
	updated(changedProperties) {
		super.updated?.(changedProperties);
		if (changedProperties.has("customHeight")) this._applyHeight();
	}
	disconnectedCallback() {
		super.disconnectedCallback();
		this._mediaQueryList?.removeEventListener("change", this._handleViewportChange);
		this._mediaQueryList = null;
	}
	_applyHeight() {
		const isVertical = this.classList.contains(`cds-custom--css-grid`);
		if (this.customHeight) {
			this.style.height = this.customHeight;
			return;
		}
		if (!isVertical) {
			this.style.removeProperty("height");
			return;
		}
		const panels = Array.from(this.querySelectorAll("[slot=\"panel\"]"));
		if (panels.length === 0) return;
		const hiddenStates = panels.map((panel) => panel.hidden);
		panels.forEach((panel) => {
			panel.hidden = false;
		});
		const tallestPanel = Math.max(...panels.map((panel) => panel.offsetHeight));
		panels.forEach((panel, index) => {
			panel.hidden = hiddenStates[index];
		});
		const tabsHeight = this.querySelector(`cds-custom-tabs`)?.offsetHeight ?? 0;
		const height = Math.max(tallestPanel, tabsHeight);
		if (height > 0) this.style.height = `${height}px`;
		else this.style.removeProperty("height");
	}
	render() {
		return html`
      <slot name="tabs"></slot>
      <div class="${"cds-custom"}-panel-container">
        <slot name="panel"></slot>
      </div>
    `;
	}
	static {
		this.styles = tabs_default;
	}
};
__decorate([property({ attribute: "custom-height" })], CDSTabsVertical.prototype, "customHeight", void 0);
__decorate([query("slot[name=\"panel\"]")], CDSTabsVertical.prototype, "_panelSlot", void 0);
//#endregion
export { CDSTabsVertical as default };

//# sourceMappingURL=tabs-vertical.js.map