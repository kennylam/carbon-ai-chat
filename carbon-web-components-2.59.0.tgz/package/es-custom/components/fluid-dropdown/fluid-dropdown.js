/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import CDSDropdown from "../dropdown/dropdown.js";
import fluid_dropdown_default from "./fluid-dropdown.scss.js";
import { html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/fluid-dropdown/fluid-dropdown.ts
/**
* Copyright IBM Corp.2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid dropdown.
*
* @element cds-custom-fluid-dropdown
*/
var CDSFluidDropdown = class extends CDSDropdown {
	constructor(..._args) {
		super(..._args);
		this.isCondensed = false;
	}
	static {
		this.is = `cds-custom-fluid-dropdown`;
	}
	connectedCallback() {
		this.setAttribute("isFluid", "true");
		super.connectedCallback();
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		if (changedProperties.has("invalid") || changedProperties.has("disabled") || changedProperties.has("readOnly") || changedProperties.has("warn")) this.requestUpdate();
	}
	render() {
		return html`${super.render()}`;
	}
	static {
		this.styles = [CDSDropdown.styles, fluid_dropdown_default];
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "is-condensed"
})], CDSFluidDropdown.prototype, "isCondensed", void 0);
//#endregion
export { CDSFluidDropdown as default };

//# sourceMappingURL=fluid-dropdown.js.map