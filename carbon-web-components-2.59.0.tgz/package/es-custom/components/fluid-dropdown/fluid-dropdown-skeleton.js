/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSDropdownSkeleton from "../dropdown/dropdown-skeleton.js";
import fluid_dropdown_default from "./fluid-dropdown.scss.js";
import { html } from "lit";
//#region src/components/fluid-dropdown/fluid-dropdown-skeleton.ts
/**
* Copyright IBM Corp.2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Fluid dropdown skeleton.
*
* @element cds-custom-fluid-dropdown-skeleton
*/
var CDSFluidDropdownSkeleton = class extends CDSDropdownSkeleton {
	static {
		this.is = `cds-custom-fluid-dropdown-skeleton`;
	}
	render() {
		return html`
      <div class="${"cds-custom"}--list-box__wrapper--fluid">
        <div class="${"cds-custom"}--skeleton ${"cds-custom"}--list-box">
          <span class="${"cds-custom"}--list-box__label"></span>
          <div class="${"cds-custom"}--list-box__field" />
        </div>
      </div>
    `;
	}
	static {
		this.styles = fluid_dropdown_default;
	}
};
//#endregion
export { CDSFluidDropdownSkeleton as default };

//# sourceMappingURL=fluid-dropdown-skeleton.js.map