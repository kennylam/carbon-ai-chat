/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../toggle-tip/index.js";
import "../ai-label/index.js";
import "../dropdown/index.js";
import CDSFluidDropdown from "./fluid-dropdown.js";
import CDSFluidDropdownSkeleton from "./fluid-dropdown-skeleton.js";
//#region src/components/fluid-dropdown/index.ts
/**
* Copyright IBM Corp. 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSFluidDropdown);
defineCustomElement(CDSFluidDropdownSkeleton);
//#endregion
export { CDSFluidDropdown, CDSFluidDropdownSkeleton };

//# sourceMappingURL=index.js.map