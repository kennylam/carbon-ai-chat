/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../tooltip/index.js";
import CDSIconIndicator from "./icon-indicator.js";
//#region src/components/icon-indicator/index.ts
/**
* Copyright IBM Corp. 2021, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSIconIndicator);
//#endregion
export { CDSIconIndicator };

//# sourceMappingURL=index.js.map