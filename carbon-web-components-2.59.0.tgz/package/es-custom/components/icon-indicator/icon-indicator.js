/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "../popover/defs.js";
import { ICON_INDICATOR_KIND } from "./defs.js";
import icon_indicator_default from "./icon-indicator.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import WarningAltFilled16 from "@carbon/icons/es/warning--alt--filled/16.js";
import CheckmarkFilled16 from "@carbon/icons/es/checkmark--filled/16.js";
import ErrorFilled16 from "@carbon/icons/es/error--filled/16.js";
import ErrorFilled20 from "@carbon/icons/es/error--filled/20.js";
import WarningAltInvertedFilled16 from "@carbon/icons/es/warning--alt-inverted--filled/16.js";
import WarningAltInvertedFilled20 from "@carbon/icons/es/warning--alt-inverted--filled/20.js";
import WarningAltFilled20 from "@carbon/icons/es/warning--alt--filled/20.js";
import UndefinedFilled16 from "@carbon/icons/es/undefined--filled/16.js";
import UndefinedFilled20 from "@carbon/icons/es/undefined--filled/20.js";
import CheckmarkFilled20 from "@carbon/icons/es/checkmark--filled/20.js";
import CheckmarkOutline16 from "@carbon/icons/es/checkmark--outline/16.js";
import CheckmarkOutline20 from "@carbon/icons/es/checkmark--outline/20.js";
import InProgress16 from "@carbon/icons/es/in-progress/16.js";
import InProgress20 from "@carbon/icons/es/in-progress/20.js";
import Incomplete16 from "@carbon/icons/es/incomplete/16.js";
import Incomplete20 from "@carbon/icons/es/incomplete/20.js";
import CircleDash16 from "@carbon/icons/es/circle-dash/16.js";
import CircleDash20 from "@carbon/icons/es/circle-dash/20.js";
import PendingFilled16 from "@carbon/icons/es/pending--filled/16.js";
import PendingFilled20 from "@carbon/icons/es/pending--filled/20.js";
import UnknownFilled16 from "@carbon/icons/es/unknown--filled/16.js";
import UnknownFilled20 from "@carbon/icons/es/unknown--filled/20.js";
import WarningSquareFilled16 from "@carbon/icons/es/warning-square--filled/16.js";
import WarningSquareFilled20 from "@carbon/icons/es/warning-square--filled/20.js";
//#region src/components/icon-indicator/icon-indicator.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
const iconMap = {
	["failed"]: {
		16: ErrorFilled16,
		20: ErrorFilled20
	},
	["caution-major"]: {
		16: WarningAltInvertedFilled16,
		20: WarningAltInvertedFilled20
	},
	["caution-minor"]: {
		16: WarningAltFilled16,
		20: WarningAltFilled20
	},
	["undefined"]: {
		16: UndefinedFilled16,
		20: UndefinedFilled20
	},
	["succeeded"]: {
		16: CheckmarkFilled16,
		20: CheckmarkFilled20
	},
	["normal"]: {
		16: CheckmarkOutline16,
		20: CheckmarkOutline20
	},
	["in-progress"]: {
		16: InProgress16,
		20: InProgress20
	},
	["incomplete"]: {
		16: Incomplete16,
		20: Incomplete20
	},
	["not-started"]: {
		16: CircleDash16,
		20: CircleDash20
	},
	["pending"]: {
		16: PendingFilled16,
		20: PendingFilled20
	},
	["unknown"]: {
		16: UnknownFilled16,
		20: UnknownFilled20
	},
	["informative"]: {
		16: WarningSquareFilled16,
		20: WarningSquareFilled20
	}
};
/**
* Icon Indicator.
*
* @element cds-custom-icon-indicator
*/
var CDSIconIndicator = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.align = "right";
		this.autoalign = false;
		this.compact = false;
		this.size = 16;
	}
	static {
		this.is = `cds-custom-icon-indicator`;
	}
	render() {
		const IconComponent = iconMap[this.kind]?.[this.size];
		const iconElement = iconLoader(IconComponent, { size: this.size });
		if (this.compact) return html`
        <cds-custom-definition-tooltip
          align=${this.align}
          ?autoalign=${this.autoalign}
          open-on-hover>
          ${iconElement}
          <span class="${"cds-custom"}--visually-hidden"
            >${this.iconDescription ?? this.label}</span
          >
          <span slot="definition">${this.label}</span>
        </cds-custom-definition-tooltip>
      `;
		return html`${iconElement}${this.label}`;
	}
	static {
		this.styles = icon_indicator_default;
	}
};
__decorate([property({ reflect: true })], CDSIconIndicator.prototype, "align", void 0);
__decorate([property({
	type: Boolean,
	reflect: false
})], CDSIconIndicator.prototype, "autoalign", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSIconIndicator.prototype, "compact", void 0);
__decorate([property({ attribute: "icon-description" })], CDSIconIndicator.prototype, "iconDescription", void 0);
__decorate([property()], CDSIconIndicator.prototype, "size", void 0);
__decorate([property()], CDSIconIndicator.prototype, "label", void 0);
__decorate([property()], CDSIconIndicator.prototype, "kind", void 0);
//#endregion
export { ICON_INDICATOR_KIND, CDSIconIndicator as default };

//# sourceMappingURL=icon-indicator.js.map