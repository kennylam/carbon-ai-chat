/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import on from "../../globals/mixins/on.js";
import rangePlugin from "../../node_modules/flatpickr/dist/esm/plugins/rangePlugin.js";
//#region src/components/date-picker/range-plugin.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @param config Plugin configuration.
* @returns
*   An extension of Flatpickr `rangePlugin` that does the following:
*
*   Positions the calendar dropdown relative to the `<input>` for the starting date.
*     Workaround for: https://github.com/flatpickr/flatpickr/issues/1944
*   Commits manual range input values on blur for both inputs when `allowInput` is enabled.
*   Ensures that the `<input>` in shadow DOM is treated as part of Flatpickr UI,
*     by ensuring such `<input>` hits `.contains()` search from `fp.config.ignoredFocusElements`.
*     Without that, Flatpickr clears the `<input>` when end date hasn't been selected yet (which we don't want).
*/
var range_plugin_default = (config) => {
	const factory = rangePlugin({
		position: "left",
		...config
	});
	return (fp) => {
		const origRangePlugin = factory(fp);
		const { onReady: origOnReady } = origRangePlugin;
		const getDateStrFromInputs = (dates) => {
			return dates.filter((value) => value).filter((d, i, arr) => fp.config.mode !== "range" || fp.config.enableTime || arr.indexOf(d) === i).join(fp.config.mode !== "range" ? fp.config.conjunction : fp.l10n.rangeSeparator);
		};
		const handleBlur = (event) => {
			event.stopPropagation();
			const firstInput = fp._input;
			const secondInput = config.input;
			const isInput = event.target === firstInput || event.target === secondInput;
			const valueChanged = getDateStrFromInputs([firstInput.value, secondInput.value]) !== fp.getDateStr();
			const relatedTargetIsCalendar = event.relatedTarget && event.relatedTarget instanceof Node && fp.calendarContainer.contains(event.relatedTarget);
			if (isInput && valueChanged && !relatedTargetIsCalendar) fp.setDate([firstInput.value, secondInput.value], true, firstInput === fp.altInput ? fp.config.altFormat : fp.config.dateFormat);
		};
		const release = () => {
			if (fp._hBXCEDatePickerRangePluginOnBlurFrom) fp._hBXCEDatePickerRangePluginOnBlurFrom = fp._hBXCEDatePickerRangePluginOnBlurFrom.release();
			if (fp._hBXCEDatePickerRangePluginOnBlurTo) fp._hBXCEDatePickerRangePluginOnBlurTo = fp._hBXCEDatePickerRangePluginOnBlurTo.release();
		};
		return Object.assign(origRangePlugin, { onReady() {
			origOnReady.call(this);
			const { ignoredFocusElements } = fp.config;
			ignoredFocusElements.push(...ignoredFocusElements.map((elem) => elem.shadowRoot).filter(Boolean));
			release();
			if (fp.config.allowInput) {
				fp._hBXCEDatePickerRangePluginOnBlurFrom = on(fp._input, "blur", handleBlur, { capture: true });
				fp._hBXCEDatePickerRangePluginOnBlurTo = on(config.input, "blur", handleBlur, { capture: true });
			}
		} });
	};
};
//#endregion
export { range_plugin_default as default };

//# sourceMappingURL=range-plugin.js.map