/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import on from "../../globals/mixins/on.js";
//#region src/components/date-picker/fix-events-plugin.ts
/**
* @param config Plugin configuration.
* @returns A Flatpickr plugin to fix Flatpickr's behavior of certain events.
*/
var fix_events_plugin_default = (config) => (fp) => {
	/**
	* Handles `keydown` event.
	*/
	const handleKeydown = (event) => {
		const { inputFrom, inputTo } = config;
		const { key, target } = event;
		if (inputFrom === target || inputTo === target) switch (key) {
			case "Enter":
				fp.setDate([inputFrom.value, inputTo && inputTo.value], true, fp.config.dateFormat);
				event.stopPropagation();
				break;
			default: break;
		}
	};
	/**
	* Releases event listeners used in this Flatpickr plugin.
	*/
	const release = () => {
		if (fp._hCDSCEDatePickerFixEventsPluginKeydownTo) fp._hCDSCEDatePickerFixEventsPluginKeydownTo = fp._hCDSCEDatePickerFixEventsPluginKeydownTo.release();
		if (fp._hCDSCEDatePickerFixEventsPluginKeydownFrom) fp._hCDSCEDatePickerFixEventsPluginKeydownFrom = fp._hCDSCEDatePickerFixEventsPluginKeydownFrom.release();
	};
	/**
	* Sets up event listeners used for this Flatpickr plugin.
	*/
	const init = () => {
		release();
		const { inputFrom, inputTo } = config;
		fp._hCDSCEDatePickerFixEventsPluginKeydownFrom = on(inputFrom, "keydown", handleKeydown, true);
		if (inputTo) fp._hCDSCEDatePickerFixEventsPluginKeydownTo = on(inputTo, "keydown", handleKeydown, true);
	};
	/**
	* Registers this Flatpickr plugin.
	*/
	const register = () => {
		fp.loadedPlugins.push("carbonFlatpickrFixEventsPlugin");
	};
	return {
		onReady: [register, init],
		onDestroy: [release]
	};
};
//#endregion
export { fix_events_plugin_default as default };

//# sourceMappingURL=fix-events-plugin.js.map