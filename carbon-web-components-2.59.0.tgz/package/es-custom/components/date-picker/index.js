/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import CDSDatePickerInput from "./date-picker-input.js";
import CDSDatePicker from "./date-picker.js";
import CDSDatePickerInputSkeleton from "./date-picker-input-skeleton.js";
//#region src/components/date-picker/index.ts
/**
* Copyright IBM Corp. 2021, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSDatePicker);
defineCustomElement(CDSDatePickerInput);
defineCustomElement(CDSDatePickerInputSkeleton);
//#endregion
export { CDSDatePicker, CDSDatePickerInput, CDSDatePickerInputSkeleton };

//# sourceMappingURL=index.js.map