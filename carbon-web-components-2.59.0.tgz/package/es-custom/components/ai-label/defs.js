/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/ai-label/defs.ts
/**
* Copyright IBM Corp. 2020, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* AI Label size.
*/
let AI_LABEL_SIZE = /* @__PURE__ */ function(AI_LABEL_SIZE) {
	/**
	* Mini size.
	*/
	AI_LABEL_SIZE["MINI"] = "mini";
	/**
	* Extra extra small size.
	*/
	AI_LABEL_SIZE["EXTRA_EXTRA_SMALL"] = "2xs";
	/**
	* Extra small size.
	*/
	AI_LABEL_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	AI_LABEL_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	AI_LABEL_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	AI_LABEL_SIZE["LARGE"] = "lg";
	/**
	* Extra large size.
	*/
	AI_LABEL_SIZE["EXTRA_LARGE"] = "xl";
	return AI_LABEL_SIZE;
}({});
/**
* AI Label kind.
*/
let AI_LABEL_KIND = /* @__PURE__ */ function(AI_LABEL_KIND) {
	/**
	* Default kind.
	*/
	AI_LABEL_KIND["DEFAULT"] = "";
	/**
	* Inline kind.
	*/
	AI_LABEL_KIND["INLINE"] = "inline";
	return AI_LABEL_KIND;
}({});
//#endregion
export { AI_LABEL_KIND, AI_LABEL_SIZE };

//# sourceMappingURL=defs.js.map