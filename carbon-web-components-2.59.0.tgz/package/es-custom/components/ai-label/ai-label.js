/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import toggletip_default from "../toggle-tip/toggletip.scss.js";
import popover_default from "../popover/popover.scss.js";
import CDSToggletip from "../toggle-tip/toggletip.js";
import ai_label_default from "./ai-label.scss.js";
import "./defs.js";
import { adoptStyles, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import Undo16 from "@carbon/icons/es/undo/16.js";
//#region src/components/ai-label/ai-label.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Basic AI Label.
*
* @element cds-custom-ai-label
*/
var CDSAILabel = class extends CDSToggletip {
	constructor(..._args) {
		super(..._args);
		this.slot = "ai-label";
		this.aiText = "AI";
		this.aiTextLabel = "";
		this.kind = "";
		this.revertActive = false;
		this.revertLabel = "Revert to AI input";
		this.size = "xs";
		this.buttonLabel = "Show information";
		this._handleClick = () => {
			if (this.revertActive) {
				this.revertActive = false;
				this.removeAttribute("revert-active");
			} else super._handleClick();
		};
		this._renderToggleTipLabel = () => {
			return html``;
		};
		this._renderTooltipButton = () => {
			const { size, kind, aiText, aiTextLabel, buttonLabel } = this;
			const ariaLabel = `${aiText} - ${buttonLabel}`;
			const classes = classMap({
				[`cds-custom--toggletip-button`]: true,
				[`cds-custom--slug__button`]: true,
				[`cds-custom--slug__button--${size}`]: size,
				[`cds-custom--slug__button--${kind}`]: kind,
				[`cds-custom--slug__button--inline-with-content`]: kind === "inline" && aiTextLabel
			});
			return html`
      <button
        aria-controls="${this.id}"
        @click="${this._handleClick}"
        class=${classes}
        aria-label="${ariaLabel}">
        <span class="${"cds-custom"}--slug__text">${aiText}</span>
        ${aiTextLabel && kind === "inline" ? html`
              <span class="${"cds-custom"}--slug__additional-text">
                ${aiTextLabel}
              </span>
            ` : ``}
      </button>
    `;
		};
		this._renderInnerContent = () => {
			const { autoalign, revertActive, revertLabel } = this;
			return html`
      ${revertActive ? html`
            <cds-custom-icon-button
              ?autoalign=${autoalign}
              kind="ghost"
              size="sm"
              @click="${this._handleClick}">
              <span slot="tooltip-content"> ${revertLabel} </span>
              ${iconLoader(Undo16, { slot: "icon" })}
            </cds-custom-icon-button>
          ` : html`
            ${this._renderTooltipButton()} ${this._renderTooltipContent()}
          `}
    `;
		};
	}
	static {
		this.is = `cds-custom-ai-label`;
	}
	connectedCallback() {
		super.connectedCallback();
		adoptStyles(this.renderRoot, [
			popover_default,
			toggletip_default,
			ai_label_default
		]);
	}
	attributeChangedCallback(name, old, newValue) {
		super.attributeChangedCallback(name, old, newValue);
		if (name === "revert-active") this.parentElement?.requestUpdate();
	}
};
__decorate([property({ reflect: true })], CDSAILabel.prototype, "slot", void 0);
__decorate([property({ attribute: "ai-text" })], CDSAILabel.prototype, "aiText", void 0);
__decorate([property({ attribute: "ai-text-label" })], CDSAILabel.prototype, "aiTextLabel", void 0);
__decorate([property({ reflect: true })], CDSAILabel.prototype, "kind", void 0);
__decorate([property({
	type: Boolean,
	attribute: "revert-active"
})], CDSAILabel.prototype, "revertActive", void 0);
__decorate([property({ attribute: "revert-label" })], CDSAILabel.prototype, "revertLabel", void 0);
__decorate([property({ reflect: true })], CDSAILabel.prototype, "size", void 0);
__decorate([property({ attribute: "button-label" })], CDSAILabel.prototype, "buttonLabel", void 0);
__decorate([property()], CDSAILabel.prototype, "previousValue", void 0);
//#endregion
export { CDSAILabel as default };

//# sourceMappingURL=ai-label.js.map