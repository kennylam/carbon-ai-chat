/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import CDSButton from "../button/button.js";
import ai_label_default from "./ai-label.scss.js";
import { property } from "lit/decorators.js";
//#region src/components/ai-label/ai-label-action-button.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* AI Label action button.
*
* @element cds-custom-ai-label-action-button
*/
var CDSAILabelActionButton = class extends CDSButton {
	constructor(..._args) {
		super(..._args);
		this.slot = "actions";
	}
	static {
		this.is = `cds-custom-ai-label-action-button`;
	}
	static {
		this.styles = ai_label_default;
	}
};
__decorate([property({ reflect: true })], CDSAILabelActionButton.prototype, "slot", void 0);
//#endregion
export { CDSAILabelActionButton as default };

//# sourceMappingURL=ai-label-action-button.js.map