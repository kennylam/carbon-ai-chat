/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../toggle-tip/index.js";
import "../icon-button/index.js";
import CDSAILabel from "./ai-label.js";
import CDSAILabelActionButton from "./ai-label-action-button.js";
//#region src/components/ai-label/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSAILabel);
defineCustomElement(CDSAILabelActionButton);
//#endregion
export { CDSAILabel, CDSAILabelActionButton };

//# sourceMappingURL=index.js.map