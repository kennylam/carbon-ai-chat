/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSSkeletonText from "./skeleton-text.js";
//#region src/components/skeleton-text/index.ts
/**
* Copyright IBM Corp. 2021
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSSkeletonText);
//#endregion
export { CDSSkeletonText };

//# sourceMappingURL=index.js.map