/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/skeleton-text/defs.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton text types.
*/
let SKELETON_TEXT_TYPE = /* @__PURE__ */ function(SKELETON_TEXT_TYPE) {
	/**
	* Regular variant.
	*/
	SKELETON_TEXT_TYPE["REGULAR"] = "";
	/**
	* Heading variant.
	*/
	SKELETON_TEXT_TYPE["HEADING"] = "heading";
	return SKELETON_TEXT_TYPE;
}({});
//#endregion
export { SKELETON_TEXT_TYPE };

//# sourceMappingURL=defs.js.map