/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import { SKELETON_TEXT_TYPE } from "./defs.js";
import skeleton_text_default from "./skeleton-text.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/skeleton-text/skeleton-text.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
function getRandomInt(min, max, n) {
	return Math.floor([
		.973051493507435,
		.15334737213558558,
		.5671034553053769
	][n % 3] * (max - min + 1)) + min;
}
/**
* Skeleton text.
*
* @element cds-custom-skeleton-text
*/
var CDSSkeletonText = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.type = "";
		this.heading = false;
		this.width = "100%";
		this.paragraph = false;
		this.lineCount = 3;
	}
	static {
		this.is = `cds-custom-skeleton-text`;
	}
	render() {
		const { optionalClasses, paragraph, lineCount, type, width, heading } = this;
		let defaultClasses = {
			[`cds-custom--skeleton__text`]: true,
			[`cds-custom--skeleton__heading`]: heading || type === "heading"
		};
		if (optionalClasses) {
			const outputObject = {};
			optionalClasses?.split(" ").forEach((element) => {
				outputObject[element] = true;
			});
			defaultClasses = {
				...defaultClasses,
				...outputObject
			};
		}
		const classes = classMap(defaultClasses);
		if (paragraph) {
			const widthNum = parseInt(this.width, 10);
			const widthPx = this.width.includes("px");
			const widthPercent = this.width.includes("%");
			const lines = [];
			for (let i = 0; i < lineCount; i++) {
				const randomWidth = widthPercent && `${getRandomInt(0, 75, i)}px` || widthPx && `${getRandomInt(0, widthNum, i)}px`;
				const style = widthPercent && `width: calc(${width} - ${randomWidth})` || widthPx && `width: ${randomWidth}` || "";
				lines.push(html`<p class="${classes}" style="${style}"></p>`);
			}
			return lines;
		}
		return html`<p class="${classes}" style="width:${width}"></p>`;
	}
	static {
		this.styles = skeleton_text_default;
	}
};
__decorate([property({
	reflect: true,
	attribute: "optional-classes"
})], CDSSkeletonText.prototype, "optionalClasses", void 0);
__decorate([property({ reflect: true })], CDSSkeletonText.prototype, "type", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSSkeletonText.prototype, "heading", void 0);
__decorate([property({ reflect: true })], CDSSkeletonText.prototype, "width", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSSkeletonText.prototype, "paragraph", void 0);
__decorate([property({
	type: Number,
	reflect: true
})], CDSSkeletonText.prototype, "lineCount", void 0);
//#endregion
export { SKELETON_TEXT_TYPE, CDSSkeletonText as default };

//# sourceMappingURL=skeleton-text.js.map