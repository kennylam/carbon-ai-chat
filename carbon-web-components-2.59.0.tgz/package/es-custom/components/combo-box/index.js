/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../toggle-tip/index.js";
import "../ai-label/index.js";
import "../dropdown/index.js";
import CDSComboBox from "./combo-box.js";
import CDSComboBoxItem from "./combo-box-item.js";
//#region src/components/combo-box/index.ts
/**
* Copyright IBM Corp. 2021, 2022
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSComboBox);
defineCustomElement(CDSComboBoxItem);
//#endregion
export { CDSComboBox, CDSComboBoxItem };

//# sourceMappingURL=index.js.map