/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import CDSDropdownItem from "../dropdown/dropdown-item.js";
import combo_box_default from "./combo-box.scss.js";
//#region src/components/combo-box/combo-box-item.ts
/**
* Combo box item.
*
* @element cds-custom-combo-box-item
*/
var CDSComboBoxItem = class extends CDSDropdownItem {
	constructor(..._args) {
		super(..._args);
		this._nextSiblingRefs = {
			"hovered-next-sibling": null,
			"highlighted-next-sibling": null,
			"selected-next-sibling": null
		};
	}
	static {
		this.is = `cds-custom-combo-box-item`;
	}
	connectedCallback() {
		super.connectedCallback();
		this.classList.add(`cds-custom--list-box__menu-item`);
	}
	disconnectedCallback() {
		this._syncNextSibling("highlighted-next-sibling", false);
		this._syncNextSibling("selected-next-sibling", false);
		super.disconnectedCallback();
	}
	_getNextItem() {
		let next = this.nextElementSibling;
		while (next) {
			if (next instanceof HTMLElement && next.tagName.toLowerCase() === `cds-custom-combo-box-item`) return next;
			next = next.nextElementSibling;
		}
		return null;
	}
	_syncNextSibling(attribute, shouldSet) {
		this._nextSiblingRefs[attribute]?.removeAttribute(attribute);
		if (shouldSet) {
			const next = this._getNextItem();
			if (next) {
				next.setAttribute(attribute, "");
				this._nextSiblingRefs[attribute] = next;
				return;
			}
		}
		this._nextSiblingRefs[attribute] = null;
	}
	updated(changedProperties) {
		super.updated(changedProperties);
		if (changedProperties.has("highlighted")) this._syncNextSibling("highlighted-next-sibling", this.highlighted);
		if (changedProperties.has("selected")) this._syncNextSibling("selected-next-sibling", this.selected);
	}
	static {
		this.styles = combo_box_default;
	}
};
//#endregion
export { CDSComboBoxItem as default };

//# sourceMappingURL=combo-box-item.js.map