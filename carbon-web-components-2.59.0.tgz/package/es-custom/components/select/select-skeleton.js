/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import select_default from "./select.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/select/select-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of number input.
*/
var CDSSelectSkeleton = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.hideLabel = false;
	}
	static {
		this.is = `cds-custom-select-skeleton`;
	}
	render() {
		const { hideLabel } = this;
		return html`
      ${!hideLabel && html` <span class="${"cds-custom"}--label ${"cds-custom"}--skeleton"></span> `}
      <div class="${"cds-custom"}--select ${"cds-custom"}--skeleton"></div>
    `;
	}
	static {
		this.styles = select_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "hide-label"
})], CDSSelectSkeleton.prototype, "hideLabel", void 0);
//#endregion
export { CDSSelectSkeleton as default };

//# sourceMappingURL=select-skeleton.js.map