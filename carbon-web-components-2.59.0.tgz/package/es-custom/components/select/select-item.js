/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import { LitElement } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/select/select-item.ts
/**
* Copyright IBM Corp. 2020, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* An option in select box.
*
* @element cds-custom-select-item
*/
var CDSSelectItem = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.disabled = false;
		this.label = "";
		this.selected = false;
		this.value = "";
	}
	static {
		this.is = `cds-custom-select-item`;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSSelectItem.prototype, "disabled", void 0);
__decorate([property({ reflect: true })], CDSSelectItem.prototype, "label", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSSelectItem.prototype, "selected", void 0);
__decorate([property({ reflect: true })], CDSSelectItem.prototype, "value", void 0);
//#endregion
export { CDSSelectItem as default };

//# sourceMappingURL=select-item.js.map