/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../text-input/index.js";
import CDSSelect from "./select.js";
import CDSSelectItem from "./select-item.js";
import CDSSelectItemGroup from "./select-item-group.js";
import CDSSelectSkeleton from "./select-skeleton.js";
//#region src/components/select/index.ts
/**
* Copyright IBM Corp. 2021, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSSelect);
defineCustomElement(CDSSelectItem);
defineCustomElement(CDSSelectItemGroup);
defineCustomElement(CDSSelectSkeleton);
//#endregion
export { CDSSelect, CDSSelectItem, CDSSelectItemGroup, CDSSelectSkeleton };

//# sourceMappingURL=index.js.map