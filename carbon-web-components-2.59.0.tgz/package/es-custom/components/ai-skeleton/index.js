/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../skeleton-text/index.js";
import "../skeleton-icon/index.js";
import "../skeleton-placeholder/index.js";
import CDSAISkeletonIcon from "./ai-skeleton-icon.js";
import CDSAISkeletonPlaceholder from "./ai-skeleton-placeholder.js";
import CDSAISkeletonText from "./ai-skeleton-text.js";
//#region src/components/ai-skeleton/index.ts
/**
* Copyright IBM Corp. 2021, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSAISkeletonIcon);
defineCustomElement(CDSAISkeletonPlaceholder);
defineCustomElement(CDSAISkeletonText);
//#endregion
export { CDSAISkeletonIcon, CDSAISkeletonPlaceholder, CDSAISkeletonText };

//# sourceMappingURL=index.js.map