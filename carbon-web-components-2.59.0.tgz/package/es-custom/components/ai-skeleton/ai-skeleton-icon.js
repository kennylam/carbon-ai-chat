/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import ai_skeleton_default from "./ai-skeleton.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/ai-skeleton/ai-skeleton-icon.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* AI skeleton icon.
*
* @element cds-custom-ai-skeleton-icon
*/
var CDSAISkeletonIcon = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.customStyles = "";
	}
	static {
		this.is = `cds-custom-ai-skeleton-icon`;
	}
	render() {
		return html`<cds-custom-skeleton-icon
      class="${"cds-custom"}--skeleton__icon--ai"
      style="${this.customStyles}"></cds-custom-skeleton-icon>`;
	}
	static {
		this.styles = ai_skeleton_default;
	}
};
__decorate([property({ attribute: "custom-styles" })], CDSAISkeletonIcon.prototype, "customStyles", void 0);
//#endregion
export { CDSAISkeletonIcon as default };

//# sourceMappingURL=ai-skeleton-icon.js.map