/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import ai_skeleton_default from "./ai-skeleton.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/ai-skeleton/ai-skeleton-text.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* AI skeleton text.
*
* @element cds-custom-ai-skeleton-text
*/
var CDSAISkeletonText = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.heading = false;
		this.width = "100%";
		this.paragraph = false;
		this.lineCount = 3;
	}
	static {
		this.is = `cds-custom-ai-skeleton-text`;
	}
	render() {
		const { heading, width, lineCount, paragraph } = this;
		return html`<cds-custom-skeleton-text
      type="${heading ? "heading" : ""}"
      width="${width}"
      linecount="${lineCount}"
      ?paragraph="${paragraph}"
      optional-classes="${"cds-custom"}--skeleton__text--ai"></cds-custom-skeleton-text>`;
	}
	static {
		this.styles = ai_skeleton_default;
	}
};
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAISkeletonText.prototype, "heading", void 0);
__decorate([property({ reflect: true })], CDSAISkeletonText.prototype, "width", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAISkeletonText.prototype, "paragraph", void 0);
__decorate([property({
	type: Number,
	reflect: true
})], CDSAISkeletonText.prototype, "lineCount", void 0);
//#endregion
export { CDSAISkeletonText as default };

//# sourceMappingURL=ai-skeleton-text.js.map