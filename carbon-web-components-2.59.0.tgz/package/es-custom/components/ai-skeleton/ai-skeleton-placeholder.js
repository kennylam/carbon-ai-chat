/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import ai_skeleton_default from "./ai-skeleton.scss.js";
import { LitElement, html } from "lit";
//#region src/components/ai-skeleton/ai-skeleton-placeholder.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* AI skeleton placeholder.
*
* @element cds-custom-ai-skeleton-placeholder
*/
var CDSAISkeletonPlaceholder = class extends LitElement {
	static {
		this.is = `cds-custom-ai-skeleton-placeholder`;
	}
	render() {
		return html`<cds-custom-skeleton-placeholder
      exportparts="placeholder:skeleton-placeholder"
      optional-classes="${"cds-custom"}--skeleton__placeholder--ai"></cds-custom-skeleton-placeholder>`;
	}
	static {
		this.styles = ai_skeleton_default;
	}
};
//#endregion
export { CDSAISkeletonPlaceholder as default };

//# sourceMappingURL=ai-skeleton-placeholder.js.map