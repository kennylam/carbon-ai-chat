/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import page_header_default from "./page-header.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/page-header/page-header-breadcrumb.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @deprecated PageHeader has moved to Carbon for IBM Products.
* See https://github.com/carbon-design-system/carbon/issues/21926
*/
/**
* Page header Breadcrumb Bar.
* @deprecated This component has moved to Carbon for IBM Products and is now maintained in
*   `@carbon/ibm-products-web-components`.
*   See https://github.com/carbon-design-system/carbon/issues/21926
* @element cds-custom-page-header-breadcrumb
*/
var CDSPageHeaderBreadcrumb = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.border = true;
		this.withinGrid = false;
		this.pageActionsFlush = false;
		this.contentActionsFlush = false;
	}
	static {
		this.is = `cds-custom-page-header-breadcrumb`;
	}
	render() {
		const { withinGrid } = this;
		return html`
      <div class="${"cds-custom"}--page-header__breadcrumb-bar">
        <div class="${classMap({
			[`cds-custom--css-grid`]: !withinGrid,
			[`cds-custom--subgrid cds-custom--subgrid--wide`]: withinGrid
		})}">
          <div
            class="${"cds-custom"}--sm:col-span-4 ${"cds-custom"}--md:col-span-8 ${"cds-custom"}--lg:col-span-16 ${"cds-custom"}--css-grid-column">
            <div class="${"cds-custom"}--page-header__breadcrumb-container">
              <div class="${"cds-custom"}--page-header__breadcrumb-wrapper">
                <slot name="icon"></slot>
                <slot></slot>
              </div>
              <div class="${"cds-custom"}--page-header__breadcrumb__actions">
                <slot name="content-actions"></slot>
                <slot name="page-actions"></slot>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
	}
	static {
		this.styles = page_header_default;
	}
};
__decorate([property({ reflect: true })], CDSPageHeaderBreadcrumb.prototype, "border", void 0);
__decorate([property({
	attribute: "within-grid",
	type: Boolean
})], CDSPageHeaderBreadcrumb.prototype, "withinGrid", void 0);
__decorate([property({
	attribute: "page-actions-flush",
	type: Boolean
})], CDSPageHeaderBreadcrumb.prototype, "pageActionsFlush", void 0);
__decorate([property({
	attribute: "content-actions-flush",
	type: Boolean
})], CDSPageHeaderBreadcrumb.prototype, "contentActionsFlush", void 0);
//#endregion
export { CDSPageHeaderBreadcrumb as default };

//# sourceMappingURL=page-header-breadcrumb.js.map