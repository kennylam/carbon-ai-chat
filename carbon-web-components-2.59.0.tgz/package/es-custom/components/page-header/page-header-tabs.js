/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import page_header_default from "./page-header.scss.js";
import { LitElement, html } from "lit";
//#region src/components/page-header/page-header-tabs.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @deprecated PageHeader has moved to Carbon for IBM Products.
* See https://github.com/carbon-design-system/carbon/issues/21926
*/
/**
* Page header Tabs Bar.
* @deprecated This component has moved to Carbon for IBM Products and is now maintained in
*   `@carbon/ibm-products-web-components`.
*   See https://github.com/carbon-design-system/carbon/issues/21926
* @element cds-custom-page-header-tabs
*/
var CDSPageHeaderTabs = class extends LitElement {
	static {
		this.is = `cds-custom-page-header-tabs`;
	}
	render() {
		const {} = this;
		return html` <div class="${"cds-custom"}--css-grid">
      <div
        class="${"cds-custom"}--sm:col-span-4 ${"cds-custom"}--md:col-span-8 ${"cds-custom"}--lg:col-span-16 ${"cds-custom"}--css-grid-column">
        <div class="${"cds-custom"}--page-header__tab-bar--tablist">
          <slot></slot>
          <slot name="tags"></slot>
        </div>
      </div>
    </div>`;
	}
	static {
		this.styles = page_header_default;
	}
};
//#endregion
export { CDSPageHeaderTabs as default };

//# sourceMappingURL=page-header-tabs.js.map