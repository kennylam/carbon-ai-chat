/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import page_header_default from "./page-header.scss.js";
import { LitElement, html } from "lit";
//#region src/components/page-header/page-header.ts
/**
* Copyright IBM Corp. 2019, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @deprecated PageHeader has moved to Carbon for IBM Products.
* See https://github.com/carbon-design-system/carbon/issues/21926
*/
/**
* Page header.
* @deprecated This component has moved to Carbon for IBM Products and is now maintained in
*   `@carbon/ibm-products-web-components`.
*   See https://github.com/carbon-design-system/carbon/issues/21926
* @element cds-custom-page-header
*/
var CDSPageHeader = class extends LitElement {
	static {
		this.is = `cds-custom-page-header`;
	}
	render() {
		const {} = this;
		return html` <slot></slot>`;
	}
	static {
		this.styles = page_header_default;
	}
};
//#endregion
export { CDSPageHeader as default };

//# sourceMappingURL=page-header.js.map