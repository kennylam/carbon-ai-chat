/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import page_header_default from "./page-header.scss.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/page-header/page-header-content-text.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @deprecated PageHeader has moved to Carbon for IBM Products.
* See https://github.com/carbon-design-system/carbon/issues/21926
*/
/**
* Page header Content Text.
* @deprecated This component has moved to Carbon for IBM Products and is now maintained in
*   `@carbon/ibm-products-web-components`.
*   See https://github.com/carbon-design-system/carbon/issues/21926
* @element cds-custom-page-header-content-text
*/
var CDSPageHeaderContentText = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.subtitle = "";
	}
	static {
		this.is = `cds-custom-page-header-content-text`;
	}
	render() {
		const { subtitle } = this;
		return html`
      ${subtitle && html`<h3 class="${"cds-custom"}--page-header__content__subtitle">
        ${subtitle}
      </h3>`}
      <slot></slot>
    `;
	}
	static {
		this.styles = page_header_default;
	}
};
__decorate([property()], CDSPageHeaderContentText.prototype, "subtitle", void 0);
//#endregion
export { CDSPageHeaderContentText as default };

//# sourceMappingURL=page-header-content-text.js.map