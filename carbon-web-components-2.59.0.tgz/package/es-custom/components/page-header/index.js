/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../tooltip/index.js";
import CDSPageHeader from "./page-header.js";
import CDSPageHeaderBreadcrumb from "./page-header-breadcrumb.js";
import CDSPageHeaderContent from "./page-header-content.js";
import CDSPageHeaderContentText from "./page-header-content-text.js";
import CDSPageHeaderHeroImage from "./page-header-hero-image.js";
import CDSPageHeaderTabs from "./page-header-tabs.js";
//#region src/components/page-header/index.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSPageHeader);
defineCustomElement(CDSPageHeaderBreadcrumb);
defineCustomElement(CDSPageHeaderContent);
defineCustomElement(CDSPageHeaderContentText);
defineCustomElement(CDSPageHeaderHeroImage);
defineCustomElement(CDSPageHeaderTabs);
//#endregion
export { CDSPageHeader, CDSPageHeaderBreadcrumb, CDSPageHeaderContent, CDSPageHeaderContentText, CDSPageHeaderHeroImage, CDSPageHeaderTabs };

//# sourceMappingURL=index.js.map