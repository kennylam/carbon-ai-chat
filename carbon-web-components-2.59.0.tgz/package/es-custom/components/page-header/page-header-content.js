/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import page_header_default from "./page-header.scss.js";
import { LitElement, html } from "lit";
import { property, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
//#region src/components/page-header/page-header-content.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* @deprecated PageHeader has moved to Carbon for IBM Products.
* See https://github.com/carbon-design-system/carbon/issues/21926
*/
/**
* Page header content.
* @deprecated This component has moved to Carbon for IBM Products and is now maintained in
*   `@carbon/ibm-products-web-components`.
*   See https://github.com/carbon-design-system/carbon/issues/21926
* @element cds-custom-page-header-content
*/
var CDSPageHeaderContent = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this._hasContextualActions = false;
		this.title = "";
		this._hasEllipsisApplied = false;
		this.withinGrid = false;
	}
	static {
		this.is = `cds-custom-page-header-content`;
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleSlotChange({ target }) {
		this._hasContextualActions = Boolean(target.assignedNodes());
		if (this._hasContextualActions) this.setAttribute("contextual-actions", "true");
		else this.removeAttribute("contextual-actions");
		this.requestUpdate();
	}
	updated() {
		const textContainer = this.shadowRoot?.querySelector(`.cds-custom--page-header__content__title`);
		if (!textContainer || this._hasEllipsisApplied === true) return;
		this._hasEllipsisApplied = textContainer.scrollHeight > textContainer.clientHeight;
	}
	render() {
		const { title, withinGrid, _hasEllipsisApplied: hasEllipsisApplied, _handleSlotChange: handleSlotChange } = this;
		return html` <div class="${classMap({
			[`cds-custom--css-grid`]: !withinGrid,
			[`cds-custom--subgrid cds-custom--subgrid--wide`]: withinGrid
		})}">
      <div
        class="${"cds-custom"}--sm:col-span-4 ${"cds-custom"}--md:col-span-8 ${"cds-custom"}--lg:col-span-16 ${"cds-custom"}--css-grid-column">
        <div class="${"cds-custom"}--page-header__content__title-wrapper">
          <div class="${"cds-custom"}--page-header__content__start">
            <div class="${"cds-custom"}--page-header__content__title-container">
              <slot name="icon"></slot>
              ${hasEllipsisApplied ? html`
                    <cds-custom-definition-tooltip>
                      <span slot="definition">${title}</span>
                      <h4 class="${"cds-custom"}--page-header__content__title">
                        ${title}
                      </h4>
                    </cds-custom-definition-tooltip>
                  ` : html`
                    <h4 class="${"cds-custom"}--page-header__content__title">
                      ${title}
                    </h4>
                  `}
            </div>
            <slot
              name="contextual-actions"
              @slotchange=${handleSlotChange}></slot>
          </div>
          <div class="${"cds-custom"}--page-header__content__page-actions">
            <slot name="page-actions"></slot>
          </div>
        </div>
        <slot></slot>
      </div>
    </div>`;
	}
	static {
		this.styles = page_header_default;
	}
};
__decorate([property()], CDSPageHeaderContent.prototype, "title", void 0);
__decorate([state()], CDSPageHeaderContent.prototype, "_hasEllipsisApplied", void 0);
__decorate([property({
	attribute: "within-grid",
	type: Boolean
})], CDSPageHeaderContent.prototype, "withinGrid", void 0);
//#endregion
export { CDSPageHeaderContent as default };

//# sourceMappingURL=page-header-content.js.map