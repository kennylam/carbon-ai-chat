/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../popover/defs.js";
import FloatingController from "../../globals/controllers/floating-controller.js";
import "../button/index.js";
import "../menu/defs.js";
import "../menu/index.js";
import menu_button_default from "./menu-button.scss.js";
import { MENU_BUTTON_KIND, MENU_BUTTON_SIZE } from "./defs.js";
import { LitElement, html } from "lit";
import { property, query } from "lit/decorators.js";
import ChevronDown16 from "@carbon/icons/es/chevron--down/16.js";
//#region src/components/menu-button/menu-button.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Menu button.
* @element cds-custom-menu-button
*/
var CDSMenuButton = class extends HostListenerMixin(LitElement) {
	constructor(..._args) {
		super(..._args);
		this._menuController = new FloatingController(this);
		this._open = false;
		this.kind = "primary";
		this.menuAlignment = "bottom";
		this.menuBorder = false;
		this.menuBackgroundToken = "layer";
		this.size = "lg";
		this.tabIndex = 0;
		this._handleClick = (event) => {
			const { _triggerNode: trigger } = this;
			if (!trigger) return;
			if (event.composedPath().includes(trigger)) if (this._open) this._closeMenu({ restoreFocus: true });
			else this._open = true;
		};
		this._handleMousedown = (event) => {
			const { _triggerNode: trigger } = this;
			if (!trigger) return;
			if (event.composedPath().includes(trigger)) event.preventDefault();
		};
		this._handleBlur = ({ relatedTarget }) => {
			if (!this.contains(relatedTarget)) this._closeMenu();
		};
		this._handleKeydown = (event) => {
			if (!this._open || event.key !== "Escape") return;
			const { _triggerNode: trigger } = this;
			if (!trigger) return;
			if (event.composedPath().includes(trigger)) {
				event.stopPropagation();
				event.preventDefault();
				this._closeMenu({ restoreFocus: true });
			}
		};
		this._handleMenuClosed = (event) => {
			const menu = this.querySelector(`cds-custom-menu`);
			if (!menu || event.target !== menu || !this._open) return;
			const shouldRestoreFocus = event.detail?.triggerEventType !== "focusout";
			this._closeMenu({ restoreFocus: shouldRestoreFocus });
		};
	}
	static {
		this.is = `cds-custom-menu-button`;
	}
	updated(changedProperties) {
		const menu = this.querySelector(`cds-custom-menu`);
		if (changedProperties.has("_open") || changedProperties.has("menuAlignment")) this.updateComplete.then(() => {
			const styleElement = menu.shadowRoot?.querySelector(`.cds-custom--menu`);
			menu.open = this._open;
			this._menuController.setPlacement({
				trigger: this._triggerNode,
				target: menu,
				alignment: this.menuAlignment,
				styleElement,
				matchWidth: true,
				open: this._open
			});
		});
		if (changedProperties.has("size")) menu.setAttribute("size", this.size);
		if (changedProperties.has("menuBorder")) menu.toggleAttribute("border", this.menuBorder);
		if (changedProperties.has("menuBackgroundToken")) menu.backgroundToken = this.menuBackgroundToken;
	}
	render() {
		const { kind, size, disabled, tabIndex, label } = this;
		return html`
      <cds-custom-button
        kind=${kind}
        size=${size}
        ?disabled=${disabled}
        tab-index=${tabIndex}>
        ${label} ${iconLoader(ChevronDown16, { slot: "icon" })}
      </cds-custom-button>
      <slot></slot>
    `;
	}
	static {
		this.styles = menu_button_default;
	}
	_closeMenu({ restoreFocus = false } = {}) {
		if (!this._open) return;
		this._open = false;
		if (restoreFocus) this._focusTrigger();
	}
	_focusTrigger() {
		if (!this._triggerNode || typeof this._triggerNode.focus !== "function") return;
		this._triggerNode.focus();
	}
};
__decorate([query(`cds-custom-button`)], CDSMenuButton.prototype, "_triggerNode", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSMenuButton.prototype, "_open", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSMenuButton.prototype, "disabled", void 0);
__decorate([property({
	type: MENU_BUTTON_KIND,
	reflect: true
})], CDSMenuButton.prototype, "kind", void 0);
__decorate([property({ type: String })], CDSMenuButton.prototype, "label", void 0);
__decorate([property({
	reflect: true,
	type: String,
	attribute: "menu-alignment"
})], CDSMenuButton.prototype, "menuAlignment", void 0);
__decorate([property({
	type: Boolean,
	reflect: true,
	attribute: "menu-border"
})], CDSMenuButton.prototype, "menuBorder", void 0);
__decorate([property({
	type: String,
	reflect: true,
	attribute: "menu-background-token"
})], CDSMenuButton.prototype, "menuBackgroundToken", void 0);
__decorate([property({
	type: MENU_BUTTON_SIZE,
	reflect: true
})], CDSMenuButton.prototype, "size", void 0);
__decorate([property({
	type: Number,
	attribute: "tab-index",
	reflect: true
})], CDSMenuButton.prototype, "tabIndex", void 0);
__decorate([HostListener("click")], CDSMenuButton.prototype, "_handleClick", void 0);
__decorate([HostListener("mousedown")], CDSMenuButton.prototype, "_handleMousedown", void 0);
__decorate([HostListener("focusout")], CDSMenuButton.prototype, "_handleBlur", void 0);
__decorate([HostListener("keydown")], CDSMenuButton.prototype, "_handleKeydown", void 0);
__decorate([HostListener(`cds-custom-menu-closed`)], CDSMenuButton.prototype, "_handleMenuClosed", void 0);
//#endregion
export { MENU_BUTTON_KIND, MENU_BUTTON_SIZE, CDSMenuButton as default };

//# sourceMappingURL=menu-button.js.map