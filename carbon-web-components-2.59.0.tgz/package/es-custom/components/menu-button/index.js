/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import "../button/index.js";
import "../menu/index.js";
import CDSMenuButton from "./menu-button.js";
//#region src/components/menu-button/index.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSMenuButton);
//#endregion
export { CDSMenuButton };

//# sourceMappingURL=index.js.map