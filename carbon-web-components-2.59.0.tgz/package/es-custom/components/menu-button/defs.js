/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/menu-button/defs.ts
/**
* Copyright IBM Corp. 2025, 2025
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Menu button size.
*/
let MENU_BUTTON_SIZE = /* @__PURE__ */ function(MENU_BUTTON_SIZE) {
	/**
	* Extra Small size
	*/
	MENU_BUTTON_SIZE["EXTRA_SMALL"] = "xs";
	/**
	* Small size.
	*/
	MENU_BUTTON_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	MENU_BUTTON_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	MENU_BUTTON_SIZE["LARGE"] = "lg";
	return MENU_BUTTON_SIZE;
}({});
/**
* menu button kind
*/
let MENU_BUTTON_KIND = /* @__PURE__ */ function(MENU_BUTTON_KIND) {
	/**
	* primary kind
	*/
	MENU_BUTTON_KIND["PRIMARY"] = "primary";
	/**
	* tertiary kind
	*/
	MENU_BUTTON_KIND["TERTIARY"] = "tertiary";
	/**
	* ghost kind
	*/
	MENU_BUTTON_KIND["GHOST"] = "ghost";
	return MENU_BUTTON_KIND;
}({});
//#endregion
export { MENU_BUTTON_KIND, MENU_BUTTON_SIZE };

//# sourceMappingURL=defs.js.map