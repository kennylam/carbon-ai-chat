/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { forEach } from "../../globals/internal/collection-helpers.js";
import { ACCORDION_ALIGNMENT, ACCORDION_SIZE } from "./defs.js";
import accordion_default from "./accordion.scss.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import { LitElement, html } from "lit";
import { property } from "lit/decorators.js";
//#region src/components/accordion/accordion.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Accordion container.
*
* @element cds-custom-accordion
*/
var CDSAccordion = class extends LitElement {
	constructor(..._args) {
		super(..._args);
		this.size = "md";
		this.alignment = "END";
		this.isFlush = false;
		this.disabled = false;
	}
	static {
		this.is = `cds-custom-accordion`;
	}
	connectedCallback() {
		if (!this.hasAttribute("role")) this.setAttribute("role", "list");
		super.connectedCallback();
	}
	updated(changedProperties) {
		if (changedProperties.has("size")) forEach(this.querySelectorAll(this.constructor.selectorAccordionItems), (elem) => {
			elem.setAttribute("size", this.size);
		});
		if (changedProperties.has("alignment")) forEach(this.querySelectorAll(this.constructor.selectorAccordionItems), (elem) => {
			elem.setAttribute("alignment", this.alignment);
		});
		if (changedProperties.has("isFlush") || changedProperties.has("alignment")) forEach(this.querySelectorAll(this.constructor.selectorAccordionItems), (elem) => {
			if (this.isFlush && this.alignment !== "start") elem.setAttribute("isFlush", "");
			else elem.removeAttribute("isFlush");
		});
		if (changedProperties.has("disabled")) forEach(this.querySelectorAll(this.constructor.selectorAccordionItems), (elem) => {
			if (this.disabled) elem.setAttribute("disabled", "");
			else elem.removeAttribute("disabled");
		});
		const items = Array.from(this.querySelectorAll(this.constructor.selectorAccordionItems));
		items.forEach((item) => item.removeAttribute("data-last-item"));
		items.reverse().find((item) => !item.hidden)?.setAttribute("data-last-item", "");
	}
	render() {
		return html` <slot></slot> `;
	}
	static get selectorAccordionItems() {
		return `cds-custom-accordion-item`;
	}
	static {
		this.styles = accordion_default;
	}
};
__decorate([property({ reflect: true })], CDSAccordion.prototype, "size", void 0);
__decorate([property({ reflect: true })], CDSAccordion.prototype, "alignment", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAccordion.prototype, "isFlush", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSAccordion.prototype, "disabled", void 0);
//#endregion
export { ACCORDION_ALIGNMENT, ACCORDION_SIZE, CDSAccordion as default };

//# sourceMappingURL=accordion.js.map