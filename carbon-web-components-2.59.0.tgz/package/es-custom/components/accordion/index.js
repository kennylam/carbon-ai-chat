/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import defineCustomElement from "../../globals/register.js";
import CDSAccordion from "./accordion.js";
import CDSAccordionItem from "./accordion-item.js";
import CDSAccordionItemSkeleton from "./accordion-item-skeleton.js";
import CDSAccordionSkeleton from "./accordion-skeleton.js";
//#region src/components/accordion/index.ts
/**
* Copyright IBM Corp. 2021, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
defineCustomElement(CDSAccordion);
defineCustomElement(CDSAccordionItem);
defineCustomElement(CDSAccordionItemSkeleton);
defineCustomElement(CDSAccordionSkeleton);
//#endregion
export { CDSAccordion, CDSAccordionItem, CDSAccordionItemSkeleton, CDSAccordionSkeleton };

//# sourceMappingURL=index.js.map