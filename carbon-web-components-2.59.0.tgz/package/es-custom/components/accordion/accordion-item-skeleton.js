/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import accordion_default from "./accordion.scss.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import "../skeleton-text/index.js";
import { LitElement, html } from "lit";
import ChevronRight16 from "@carbon/icons/es/chevron--right/16.js";
//#region src/components/accordion/accordion-item-skeleton.ts
/**
* Copyright IBM Corp. 2019, 2024
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Skeleton of accordion item.
*/
var CDSAccordionItemSkeleton = class extends LitElement {
	static {
		this.is = `cds-custom-accordion-item-skeleton`;
	}
	render() {
		return html`
      <span class="${"cds-custom"}--accordion__heading">
        ${iconLoader(ChevronRight16, {
			part: "expando-icon",
			class: `cds-custom--accordion__arrow`
		})}
        <cds-custom-skeleton-text
          class="${"cds-custom"}--accordion__title"></cds-custom-skeleton-text>
      </span>
    `;
	}
	static {
		this.styles = accordion_default;
	}
};
//#endregion
export { CDSAccordionItemSkeleton as default };

//# sourceMappingURL=accordion-item-skeleton.js.map