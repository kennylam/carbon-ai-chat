/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

//#region src/components/accordion/defs.ts
/**
* Copyright IBM Corp. 2020, 2022, 2023
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Breakpoints for accordion items. It's different from one in `@carbon/layout` library.
*/
let ACCORDION_ITEM_BREAKPOINT = /* @__PURE__ */ function(ACCORDION_ITEM_BREAKPOINT) {
	/**
	* Small breakpoint.
	*/
	ACCORDION_ITEM_BREAKPOINT["SMALL"] = "sm";
	/**
	* Medium breakpoint.
	*/
	ACCORDION_ITEM_BREAKPOINT["MEDIUM"] = "md";
	return ACCORDION_ITEM_BREAKPOINT;
}({});
/**
* Accordion size.
*/
let ACCORDION_SIZE = /* @__PURE__ */ function(ACCORDION_SIZE) {
	/**
	* Small size.
	*/
	ACCORDION_SIZE["SMALL"] = "sm";
	/**
	* Medium size.
	*/
	ACCORDION_SIZE["MEDIUM"] = "md";
	/**
	* Large size.
	*/
	ACCORDION_SIZE["LARGE"] = "lg";
	return ACCORDION_SIZE;
}({});
/**
* Specify the alignment of the accordion heading title and chevron.
*/
let ACCORDION_ALIGNMENT = /* @__PURE__ */ function(ACCORDION_ALIGNMENT) {
	/**
	* Alignment to the start
	*/
	ACCORDION_ALIGNMENT["START"] = "start";
	/**
	* Alignment to the end
	*/
	ACCORDION_ALIGNMENT["END"] = "END";
	return ACCORDION_ALIGNMENT;
}({});
//#endregion
export { ACCORDION_ALIGNMENT, ACCORDION_ITEM_BREAKPOINT, ACCORDION_SIZE };

//# sourceMappingURL=defs.js.map