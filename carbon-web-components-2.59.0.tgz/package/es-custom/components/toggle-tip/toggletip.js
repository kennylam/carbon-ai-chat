/**
 * Copyright IBM Corp. 2026
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

import "../../globals/settings.js";
import { __decorate } from "../../_virtual/_@oxc-project_runtime@0.135.0/helpers/esm/decorate.js";
import iconLoader from "../../globals/internal/icon-loader.js";
import FocusMixin from "../../globals/mixins/focus.js";
import HostListener from "../../globals/decorators/host-listener.js";
import HostListenerMixin from "../../globals/mixins/host-listener.js";
import "../popover/defs.js";
import FloatingController from "../../globals/controllers/floating-controller.js";
import toggletip_default from "./toggletip.scss.js";
import popover_default from "../popover/popover.scss.js";
import { LitElement, adoptStyles, html } from "lit";
import { property, query } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import Information16 from "@carbon/icons/es/information/16.js";
//#region src/components/toggle-tip/toggletip.ts
/**
* Copyright IBM Corp. 2019, 2026
*
* This source code is licensed under the Apache-2.0 license found in the
* LICENSE file in the root directory of this source tree.
*/
/**
* Definition tooltip.
*
* @element cds-custom-toggletip
*/
var CDSToggletip = class extends HostListenerMixin(FocusMixin(LitElement)) {
	constructor(..._args) {
		super(..._args);
		this.popoverController = new FloatingController(this);
		this.alignment = "top";
		this.alignmentAxisOffset = 0;
		this.autoalign = false;
		this.buttonLabel = "Show information";
		this.open = false;
		this.defaultOpen = false;
		this._handleKeydown = async (event) => {
			if (event.key === "Escape") this.open = false;
		};
		this._renderToggleTipLabel = () => {
			return html`
      <span class="${"cds-custom"}--toggletip-label">
        <slot></slot>
      </span>
    `;
		};
		this._renderTooltipButton = () => {
			return html`
      <button
        aria-controls="${this.id}"
        aria-label="${this.buttonLabel}"
        class="${"cds-custom"}--toggletip-button"
        @click=${this._handleClick}>
        <slot name="trigger"
          >${iconLoader(Information16, { id: "trigger" })}
        </slot>
      </button>
    `;
		};
		this._renderTooltipContent = () => {
			return this.autoalign ? html`
          <span class="${"cds-custom"}--popover-content">
            <div class="${"cds-custom"}--toggletip-content">
              <slot name="body-text"></slot>
              <div class="${"cds-custom"}--toggletip-actions">
                <slot
                  name="actions"
                  @slotchange="${this._handleActionsSlotChange}"></slot>
              </div>
            </div>
            <span class="${"cds-custom"}--popover-caret"></span>
          </span>
        ` : html`
          <span class="${"cds-custom"}--popover">
            <span class="${"cds-custom"}--popover-content">
              <div class="${"cds-custom"}--toggletip-content">
                <slot name="body-text"></slot>
                <div class="${"cds-custom"}--toggletip-actions">
                  <slot
                    name="actions"
                    @slotchange="${this._handleActionsSlotChange}"></slot>
                </div>
              </div>
            </span>
            <span class="${"cds-custom"}--popover-caret"></span>
          </span>
        `;
		};
		this._renderInnerContent = () => {
			return html`
      ${this._renderTooltipButton()} ${this._renderTooltipContent()}
    `;
		};
	}
	static {
		this.is = `cds-custom-toggletip`;
	}
	connectedCallback() {
		super.connectedCallback();
		if (this.defaultOpen && !this.hasAttribute("open")) this.open = true;
		adoptStyles(this.renderRoot, [popover_default, toggletip_default]);
	}
	/**
	* Handles `slotchange` event.
	*/
	_handleActionsSlotChange({ target }) {
		if (target.assignedNodes()) this.setAttribute("has-actions", "");
		else this.removeAttribute("has-actions");
	}
	_handleClick() {
		this.open = !this.open;
	}
	/**
	* Handles `blur` event handler on the document this element is in.
	*
	* @param event The event.
	*/
	_handleFocusOut(event) {
		if (this.contains(event.relatedTarget)) return;
		this.open = false;
	}
	updated() {
		if (this.autoalign) {
			if (this._toggletipButton && this._toggletipContent) {
				this._toggletipButton.scrollIntoView({
					block: "center",
					inline: "center"
				});
				this.popoverController?.setPlacement({
					trigger: this._toggletipButton,
					target: this._toggletipContent,
					arrowElement: this._toggletipCaret,
					caret: true,
					flipArguments: { fallbackAxisSideDirection: "start" },
					alignment: this.alignment,
					open: this.open,
					alignmentAxisOffset: this.alignmentAxisOffset
				});
			}
		}
	}
	render() {
		const { alignment, open } = this;
		const classes = classMap({
			[`cds-custom--popover-container`]: true,
			[`cds-custom--popover--caret`]: true,
			[`cds-custom--popover--high-contrast`]: true,
			[`cds-custom--popover--open`]: open,
			[`cds-custom--popover--${alignment}`]: alignment,
			[`cds-custom--toggletip`]: true,
			[`cds-custom--toggletip--open`]: open
		});
		return html`
      ${this._renderToggleTipLabel()}
      <span class="${classes}"> ${this._renderInnerContent()} </span>
    `;
	}
	/**
	* A selector that will return the toggletip content.
	*/
	static get selectorToggletipContent() {
		return `.cds-custom--popover-content`;
	}
	/**
	* A selector that will return the toggletip caret.
	*/
	static get selectorToggletipCaret() {
		return `.cds-custom--popover-caret`;
	}
	/**
	* A selector that will return the trigger element.
	*/
	static get selectorToggletipButton() {
		return `.cds-custom--toggletip-button`;
	}
	static {
		this.shadowRootOptions = {
			...LitElement.shadowRootOptions,
			delegatesFocus: true
		};
	}
};
__decorate([query(`.cds-custom--toggletip-button`)], CDSToggletip.prototype, "_toggletipButton", void 0);
__decorate([query(`.cds-custom--popover-content`)], CDSToggletip.prototype, "_toggletipContent", void 0);
__decorate([query(`.cds-custom--popover-caret`)], CDSToggletip.prototype, "_toggletipCaret", void 0);
__decorate([property({ reflect: true })], CDSToggletip.prototype, "alignment", void 0);
__decorate([property({
	type: Number,
	attribute: "alignment-axis-offset"
})], CDSToggletip.prototype, "alignmentAxisOffset", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSToggletip.prototype, "autoalign", void 0);
__decorate([property({ attribute: "button-label" })], CDSToggletip.prototype, "buttonLabel", void 0);
__decorate([property({
	type: Boolean,
	reflect: true
})], CDSToggletip.prototype, "open", void 0);
__decorate([property({
	type: Boolean,
	attribute: "default-open"
})], CDSToggletip.prototype, "defaultOpen", void 0);
__decorate([HostListener("keydown")], CDSToggletip.prototype, "_handleKeydown", void 0);
__decorate([HostListener("focusout")], CDSToggletip.prototype, "_handleFocusOut", null);
//#endregion
export { CDSToggletip as default };

//# sourceMappingURL=toggletip.js.map